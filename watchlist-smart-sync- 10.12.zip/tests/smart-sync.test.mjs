/* ==========================================================================
   Automated tests for js/v15/smart-sync.js — รันได้จริงด้วย: node tests/smart-sync.test.mjs
   ไม่ต้องพึ่งเบราว์เซอร์/Firebase จริง เพราะ stub localStorage/navigator/window/document
   ไว้ในหน่วยความจำ เพื่อทดสอบ "ตรรกะล้วน ๆ" ของคิว + CRDT-lite merge เท่านั้น
   (ไม่ได้ทดสอบการยิง Firestore จริง เพราะต้องมี browser + project จริงเท่านั้น)
   ========================================================================== */

import assert from "node:assert/strict";

// ---- stub browser globals ก่อน import โมดูลจริง ----
function makeMemoryStorage() {
  const store = new Map();
  return {
    getItem: (k) => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => { store.set(k, String(v)); },
    removeItem: (k) => { store.delete(k); },
    clear: () => { store.clear(); },
  };
}

global.localStorage = makeMemoryStorage();
if (typeof global.navigator === "object" && global.navigator) {
  try { global.navigator.onLine = true; } catch (_e) { /* ignore */ }
} else {
  Object.defineProperty(global, "navigator", { value: { onLine: true }, configurable: true });
}
global.window = { addEventListener: () => {}, wjbToast: () => {} };
global.document = { addEventListener: () => {} };
// BroadcastChannel ไม่มีใน Node โดย default -> ปล่อยให้โมดูล fallback เป็น bc=null ตามที่ออกแบบไว้

const mod = await import("../js/v15/smart-sync.js");

let passed = 0;
let failed = 0;
async function test(name, fn) {
  try {
    localStorage.clear();
    mod.__resetForTests();
    await fn();
    passed++;
    console.log(`  ✓ ${name}`);
  } catch (e) {
    failed++;
    console.log(`  ✗ ${name}`);
    console.log(`      ${e.message}`);
  }
}

console.log("Smart Sync — automated tests\n");

// ต้อง init ก่อน (newDocId ต้องมี fs.doc/fs.collection) — ทำ fake firestore fn ง่าย ๆ
let idCounter = 0;
const fakeDoc = (...args) => ({ id: "fake-" + (++idCounter), path: args.join("/") });
const fakeCollection = (db, name) => ({ __col: name });
mod.initSmartSync({ db: {}, doc: fakeDoc, collection: fakeCollection, writeBatch: () => ({ set(){}, delete(){}, commit: async () => {} }) });

await test("newDocId สร้าง id ใหม่ทุกครั้งแบบ client-side (ไม่ซ้ำกัน)", () => {
  const a = mod.newDocId("watchItems");
  const b = mod.newDocId("watchItems");
  assert.notEqual(a, b);
});

await test("queueSet เพิ่ม op ใหม่เข้าคิว", () => {
  mod.queueSet("watchItems", "item-1", { title: "A" });
  assert.equal(mod.getPendingCount(), 1);
});

await test("แก้ไข doc เดียวกันซ้ำ ๆ ถูกยุบรวมเป็น op เดียว (ไม่ส่งซ้ำหลายครั้ง)", () => {
  mod.queueSet("watchItems", "item-2", { title: "A", episode: 1 });
  mod.queueUpdate("watchItems", "item-2", { episode: 2 });
  mod.queueUpdate("watchItems", "item-2", { episode: 3 });
  assert.equal(mod.getPendingCount(), 1, "ควรมีแค่ 1 op สำหรับ doc เดียวกัน");
});

await test("ค่าล่าสุดของฟิลด์ที่แก้ซ้ำต้องเป็นค่าสุดท้าย ไม่ใช่ค่ากลาง ๆ", () => {
  mod.queueSet("watchItems", "item-3", { episode: 1, title: "A" });
  mod.queueUpdate("watchItems", "item-3", { episode: 2 });
  mod.queueUpdate("watchItems", "item-3", { episode: 5 });
  const raw = JSON.parse(localStorage.getItem("wjb_smart_sync_queue_v1"));
  const op = raw.find((o) => o.docId === "item-3");
  assert.equal(op.data.episode, 5);
  assert.equal(op.data.title, "A", "ฟิลด์ที่ไม่ได้แก้ซ้ำต้องยังอยู่ครบ (merge ไม่ใช่ overwrite)");
});

await test("delete ที่มาทีหลัง set/update ต้องชนะเสมอ (คำสั่งลบเป็นตัวจบ)", () => {
  mod.queueSet("watchItems", "item-4", { title: "A" });
  mod.queueDelete("watchItems", "item-4");
  const raw = JSON.parse(localStorage.getItem("wjb_smart_sync_queue_v1"));
  const op = raw.find((o) => o.docId === "item-4");
  assert.equal(op.type, "delete");
});

await test("mergeItems: ไม่มีชนกัน (คนละ id) ต้องได้ทั้งคู่", () => {
  const local = [{ id: "a", title: "Local Only", updatedAtMs: 100 }];
  const remote = [{ id: "b", title: "Remote Only", updatedAtMs: 100 }];
  const merged = mod.mergeItems(local, remote);
  const ids = merged.map((i) => i.id).sort();
  assert.deepEqual(ids, ["a", "b"]);
});

await test("mergeItems: id เดียวกัน ฝั่งที่ updatedAtMs ใหม่กว่าต้องชนะ (last-write-wins)", () => {
  const local = [{ id: "x", title: "แก้จากเครื่องนี้", updatedAtMs: 2000 }];
  const remote = [{ id: "x", title: "เก่ากว่าจาก Firestore", updatedAtMs: 1000 }];
  const merged = mod.mergeItems(local, remote);
  assert.equal(merged.find((i) => i.id === "x").title, "แก้จากเครื่องนี้");
});

await test("mergeItems: remote ใหม่กว่า (แก้จากอุปกรณ์อื่น) ต้องชนะ local ที่เก่ากว่า", () => {
  const local = [{ id: "y", title: "เครื่องนี้ (เก่า)", updatedAtMs: 1000 }];
  const remote = [{ id: "y", title: "อุปกรณ์อื่น (ใหม่กว่า)", updatedAtMs: 5000 }];
  const merged = mod.mergeItems(local, remote);
  assert.equal(merged.find((i) => i.id === "y").title, "อุปกรณ์อื่น (ใหม่กว่า)");
});

await test("mergeItems: item ที่กำลังรอลบ (อยู่ในคิว delete) ต้องไม่โผล่กลับมาแม้ remote ยังมีอยู่", () => {
  mod.queueDelete("watchItems", "z");
  const local = [];
  const remote = [{ id: "z", title: "ยังไม่ถูกลบจริงบน Firestore", updatedAtMs: 9999 }];
  const merged = mod.mergeItems(local, remote);
  assert.equal(merged.find((i) => i.id === "z"), undefined);
});

await test("reconcileWithDisk (ผ่าน queueSet): เห็น op ที่ 'แท็บอื่น' เขียนไว้ในดิสก์ก่อนหน้า", () => {
  // จำลองแท็บ B เขียน op ตรงลง localStorage ไปก่อน (แท็บ A ยังไม่รู้เรื่องในหน่วยความจำ)
  localStorage.setItem("wjb_smart_sync_queue_v1", JSON.stringify([
    { opKey: "watchItems/other-doc", collection: "watchItems", docId: "other-doc", type: "set", data: { title: "จากแท็บ B" }, queuedAt: Date.now(), attempts: 0 }
  ]));
  // แท็บ A เพิ่ม op ของตัวเอง -> ต้อง reconcile ดูดของแท็บ B เข้ามารวมด้วย ไม่ใช่เขียนทับหาย
  mod.queueSet("watchItems", "my-doc", { title: "จากแท็บ A" });
  const raw = JSON.parse(localStorage.getItem("wjb_smart_sync_queue_v1"));
  const ids = raw.map((o) => o.docId).sort();
  assert.deepEqual(ids, ["my-doc", "other-doc"], "ต้องมี op ของทั้งสองแท็บอยู่ครบ ไม่มีใครถูกเขียนทับหาย");
});

await test("เพิ่ม field undefined เข้าคิว ต้องถูกตัดออกก่อนส่ง Firestore (กัน error แน่นอนจาก SDK)", () => {
  mod.queueSet("watchItems", "item-5", { title: "A", note: undefined, score: 8 });
  const raw = JSON.parse(localStorage.getItem("wjb_smart_sync_queue_v1"));
  const op = raw.find((o) => o.docId === "item-5");
  assert.equal("note" in op.data, false, "ฟิลด์ที่เป็น undefined ต้องไม่ถูกส่งไปเลย");
  assert.equal(op.data.score, 8);
});

await test("poison pill: op ที่พังถาวรต้องไม่บล็อกตัวอื่นในคิวตลอดไป (แยกไปลองทีละตัว + เข้า dead-letter)", async () => {
  // จำลอง writeBatch ที่ commit ล้มเหลวเสมอถ้ามี doc "bad-item" อยู่ในแบทช์ แต่ผ่านได้ถ้า
  // ไม่มี (จำลองสถานการณ์ security rule ปฏิเสธเฉพาะ doc นั้น)
  let commitCalls = 0;
  const fakeWriteBatch = () => {
    const ops = [];
    return {
      set(ref, data) { ops.push({ id: ref.id, data }); },
      delete(ref) { ops.push({ id: ref.id, deleted: true }); },
      commit: async () => {
        commitCalls++;
        if (ops.some((o) => o.id === "bad-item")) {
          throw new Error("permission-denied (จำลอง)");
        }
      },
    };
  };
  mod.initSmartSync({ db: {}, doc: (_db, _col, id) => ({ id }), collection: (_db, name) => ({ __col: name }), writeBatch: fakeWriteBatch });

  mod.queueSet("watchItems", "bad-item", { title: "จะพังตลอด" });
  mod.queueSet("watchItems", "good-item", { title: "ปกติดี" });

  // ยิง flush ซ้ำจนกว่า bad-item จะถูก isolate ออก (ต้องเกิน MAX_ATTEMPTS_BEFORE_ISOLATION ครั้ง)
  for (let i = 0; i < 6; i++) {
    await mod.flush();
  }

  assert.equal(mod.getPendingCount(), 0, "คิวหลักต้องว่างในที่สุด (good-item สำเร็จ, bad-item ถูกย้ายออกไปแล้ว)");
  const dead = mod.getDeadLetterOps();
  assert.equal(dead.length, 1);
  assert.equal(dead[0].docId, "bad-item");
});

console.log(`\n${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
process.exit(0);
