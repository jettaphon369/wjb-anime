/* ==========================================================================
   Stress test (v2, ทำให้ถูกต้องจริง) — จำลอง 100 "อุปกรณ์" ด้วย worker_threads จริง
   แต่ละ worker คือ V8 context แยกกันจริง (localStorage/global แยกกันจริง ไม่ใช่ variable
   ที่เขียนทับกันในโปรเซสเดียวแบบเวอร์ชันแรกที่มีบั๊ก) คุยกับ Firestore จำลองที่อยู่ใน
   main thread ผ่าน message passing เท่านั้น (เหมือนอุปกรณ์จริงคุยกับ cloud ตัวเดียวกัน)

   รันด้วย: node tests/stress-100-devices.test.mjs
   ========================================================================== */

import { Worker } from "node:worker_threads";
import assert from "node:assert/strict";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DEVICE_COUNT = 100;
const SHARED_ITEM_IDS = Array.from({ length: 20 }, (_, i) => `shared-item-${i}`);
const CURSED_ID = "cursed-item";

const fakeServer = new Map(); // key: "collection/docId" -> data  (ตัวแทน Firestore จริง 1 ตัวที่ทุกอุปกรณ์เขียนร่วมกัน)
let totalCommits = 0;
let totalCommittedOps = 0;

function runDevice(deviceIndex) {
  return new Promise((resolve, reject) => {
    const worker = new Worker(path.join(__dirname, "_stress-worker.mjs"), {
      workerData: { deviceIndex, sharedIds: SHARED_ITEM_IDS, cursedId: CURSED_ID },
    });

    worker.on("message", (msg) => {
      if (msg.type === "commit") {
        totalCommits++;
        const ops = msg.ops;
        if (ops.some((o) => o.key.endsWith("/" + CURSED_ID))) {
          worker.postMessage({ type: "commit-result", requestId: msg.requestId, ok: false, error: "simulated permission-denied on cursed item" });
          return;
        }
        for (const op of ops) {
          if (op.type === "delete") fakeServer.delete(op.key);
          else fakeServer.set(op.key, { ...(fakeServer.get(op.key) || {}), ...op.data });
        }
        totalCommittedOps += ops.length;
        worker.postMessage({ type: "commit-result", requestId: msg.requestId, ok: true });
      } else if (msg.type === "done") {
        resolve(msg);
      }
    });
    worker.on("error", reject);
  });
}

async function run() {
  console.log(`Stress test v2 (worker_threads จริง): จำลอง ${DEVICE_COUNT} อุปกรณ์แยกกันจริงบน ${SHARED_ITEM_IDS.length} รายการร่วม + 1 cursed item\n`);

  const t0 = Date.now();
  const results = await Promise.all(
    Array.from({ length: DEVICE_COUNT }, (_, i) => runDevice(i))
  );
  const t1 = Date.now();

  console.log(`ทุกอุปกรณ์ (thread จริงแยกกัน) ทำ action + flush เสร็จ ใช้เวลารวม ${t1 - t0}ms`);
  console.log(`writeBatch.commit() ถูกเรียกจริงทั้งหมด ${totalCommits} ครั้ง, ops ที่ commit สำเร็จรวม ${totalCommittedOps}\n`);

  let passed = 0, failed = 0;
  function check(name, fn) {
    try { fn(); passed++; console.log(`  ✓ ${name}`); }
    catch (e) { failed++; console.log(`  ✗ ${name}\n      ${e.message}`); }
  }

  check("cursed item ต้องไม่ถูกเขียนขึ้นเซิร์ฟเวอร์เลย (isolate ออกจริง ไม่หลุดรอดแม้มี 100 อุปกรณ์แยกกันจริงแตะพร้อมกัน)", () => {
    assert.equal(fakeServer.get(`watchItems/${CURSED_ID}`), undefined);
  });

  check("cursed item ต้องไปโผล่ใน dead-letter ของอย่างน้อย 1 อุปกรณ์ที่แตะมัน", () => {
    const anyDeviceHasDeadLetter = results.some((r) => r.deadLetter.some((o) => o.docId === CURSED_ID));
    assert.ok(anyDeviceHasDeadLetter);
  });

  check("ทุกอุปกรณ์ต้องมีคิวว่างในที่สุด ไม่มีเครื่องไหนค้าง (นี่คือเทสที่เคยพังในเวอร์ชันแรกเพราะบั๊ก test harness เอง)", () => {
    const stuck = results.filter((r) => r.pendingCount > 0);
    if (stuck.length) console.log("  [debug] อุปกรณ์ที่ยังค้าง:", stuck.map((s) => s.deviceIndex));
    assert.equal(stuck.length, 0);
  });

  check(`เวลารวมต้องอยู่ในระดับใช้งานได้จริง (< 20 วินาที สำหรับ ${DEVICE_COUNT} thread จริง)`, () => {
    assert.ok(t1 - t0 < 20000, `ใช้เวลา ${t1 - t0}ms`);
  });

  console.log(`\n${passed} passed, ${failed} failed`);
  process.exit(failed > 0 ? 1 : 0);
}

run();
