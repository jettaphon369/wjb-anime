import { parentPort, workerData } from "node:worker_threads";

function makeMemoryStorage() {
  const store = new Map();
  return {
    getItem: (k) => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => { store.set(k, String(v)); },
    removeItem: (k) => { store.delete(k); },
    clear: () => { store.clear(); },
  };
}

// worker_threads ให้ V8 context/global object แยกกันจริงต่อ thread อยู่แล้ว (ไม่ใช่แค่
// ตัวแปรที่เขียนทับกัน) จึงเป็นการจำลอง "อุปกรณ์แยกกัน" ที่ถูกต้องจริง ไม่ใช่ hack
global.localStorage = makeMemoryStorage();
global.window = { addEventListener: () => {}, wjbToast: () => {} };
global.document = { addEventListener: () => {} };
Object.defineProperty(global, "navigator", { value: { onLine: true }, configurable: true });

let reqCounter = 0;
const pending = new Map(); // requestId -> {resolve, reject}

parentPort.on("message", (msg) => {
  if (msg.type === "commit-result") {
    const p = pending.get(msg.requestId);
    if (!p) return;
    pending.delete(msg.requestId);
    if (msg.ok) p.resolve();
    else p.reject(new Error(msg.error || "commit failed"));
  }
});

function sendCommit(ops) {
  const requestId = `${workerData.deviceIndex}-${++reqCounter}`;
  return new Promise((resolve, reject) => {
    pending.set(requestId, { resolve, reject });
    parentPort.postMessage({ type: "commit", requestId, ops });
  });
}

const mod = await import("../js/v15/smart-sync.js");

mod.initSmartSync({
  db: {},
  doc: (_db, col, id) => ({ id: id ?? Math.random().toString(36).slice(2), __col: col }),
  collection: (_db, name) => ({ __col: name }),
  writeBatch: () => {
    const ops = [];
    return {
      set(ref, data) { ops.push({ key: `${ref.__col || "watchItems"}/${ref.id}`, type: "set", data }); },
      delete(ref) { ops.push({ key: `${ref.__col || "watchItems"}/${ref.id}`, type: "delete" }); },
      commit: () => sendCommit(ops),
    };
  },
});

const { deviceIndex, sharedIds, cursedId } = workerData;

for (let a = 0; a < 3; a++) {
  const now = Date.now() + Math.random();
  const useCursed = Math.random() < 0.03;
  const id = useCursed ? cursedId : sharedIds[Math.floor(Math.random() * sharedIds.length)];
  const isDelete = !useCursed && Math.random() < 0.15;

  if (isDelete) {
    mod.queueDelete("watchItems", id);
  } else {
    mod.queueSet("watchItems", id, { title: `แก้โดยอุปกรณ์ #${deviceIndex}`, updatedAtMs: now, note: `pass ${a}` });
  }
}

for (let round = 0; round < 8; round++) {
  await mod.flush();
}

parentPort.postMessage({
  type: "done",
  deviceIndex,
  pendingCount: mod.getPendingCount(),
  deadLetter: mod.getDeadLetterOps(),
});
