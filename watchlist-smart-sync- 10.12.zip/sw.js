const WJB_VERSION = 'premium-ui-v15-4-sync-dashboard';
const WJB_CACHE = 'watchjettaphon-' + WJB_VERSION;
const APP_SHELL = [
  './index.html',
  './style.css?v=' + WJB_VERSION,
  './script.js?v=' + WJB_VERSION,
  './js/legacy-app.js?v=' + WJB_VERSION,
  './js/v12/index.js?v=' + WJB_VERSION,
  './js/v12/utils.js?v=' + WJB_VERSION,
  './js/v12/error-log.js?v=' + WJB_VERSION,
  './js/v12/navigation.js?v=' + WJB_VERSION,
  './js/v12/health.js?v=' + WJB_VERSION,
  './js/v12/dev-mode.js?v=' + WJB_VERSION,
  './js/v12/qa-center.js?v=' + WJB_VERSION,
  './js/v12/scroll-debug.js?v=' + WJB_VERSION,
  './js/v12/modal-stability.js?v=' + WJB_VERSION,
  './js/v13/favorites.js?v=' + WJB_VERSION,
  './js/v13/menu-drawer-stability.js?v=' + WJB_VERSION,
  './js/v13/smart-target-scroll.js?v=' + WJB_VERSION,
  './js/v13/long-press-bulk-select.js?v=' + WJB_VERSION,
  './js/v14/pro-ui.js?v=' + WJB_VERSION,
  './js/v15/smart-sync.js?v=' + WJB_VERSION,
  './js/v15/sync-dashboard.js?v=' + WJB_VERSION,
  './manifest.webmanifest',
  './favicon.png',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png'
];

self.addEventListener('install', (event) => {
  self.skipWaiting();
  event.waitUntil(caches.open(WJB_CACHE).then((cache) => cache.addAll(APP_SHELL).catch(() => null)));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.filter((key) => key !== WJB_CACHE && key.includes('watchjettaphon')).map((key) => caches.delete(key))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;

  if (req.mode === 'navigate' || req.destination === 'document' || url.pathname.endsWith('/index.html') || url.pathname === '/') {
    event.respondWith(
      fetch(req, { cache: 'no-store' }).then((res) => {
        const copy = res.clone();
        caches.open(WJB_CACHE).then((cache) => cache.put('./index.html', copy)).catch(() => null);
        return res;
      }).catch(() => caches.match('./index.html'))
    );
    return;
  }

  event.respondWith(
    fetch(req).then((res) => {
      const copy = res.clone();
      caches.open(WJB_CACHE).then((cache) => cache.put(req, copy)).catch(() => null);
      return res;
    }).catch(() => caches.match(req))
  );
});
