// WJB v14 — Pro UI system: themed Toast, Confirm Modal, Prompt Modal, loading-button helper
// Replaces browser alert()/confirm()/prompt() with in-app themed equivalents.
(function(){

  // ---------- Toast ----------
  function ensureToastHost(){
    let el = document.getElementById('wjbFavoriteToast');
    if(!el){
      el = document.createElement('div');
      el.id = 'wjbFavoriteToast';
      el.className = 'wjb-favorite-toast';
      document.body.appendChild(el);
    }
    return el;
  }

  function guessToastType(message){
    const msg = String(message || '');
    if(/(ไม่สำเร็จ|ผิดพลาด|ไม่พบ|ไม่ถูกต้อง|เฉพาะ|ต้องล็อกอิน|เข้าสู่ระบบก่อน)/.test(msg)) return 'error';
    if(/(สำเร็จ|เรียบร้อย|เสร็จ|บันทึกแล้ว|เพิ่มแล้ว|ลบแล้ว|ปกติดี)/.test(msg)) return 'success';
    return 'info';
  }

  window.wjbToast = function(message, type){
    const el = ensureToastHost();
    const finalType = type || guessToastType(message);
    el.textContent = message || 'อัปเดตแล้ว';
    el.classList.remove('wjb-toast-success', 'wjb-toast-error', 'wjb-toast-info');
    el.classList.add('wjb-toast-' + finalType);
    el.classList.add('show');
    clearTimeout(window.__wjbFavToastTimer);
    window.__wjbFavToastTimer = setTimeout(() => el.classList.remove('show'), 2600);
  };

  // Keep old name working for existing call sites
  if(typeof window.wjbFavoriteToast !== 'function'){
    window.wjbFavoriteToast = function(message){ window.wjbToast(message, 'success'); };
  }

  // ---------- Confirm Modal ----------
  function ensureConfirmHost(){
    let host = document.getElementById('wjbConfirmModal');
    if(host) return host;
    host = document.createElement('div');
    host.id = 'wjbConfirmModal';
    host.className = 'wjb-confirm-modal';
    host.style.display = 'none';
    host.innerHTML = `
      <div class="wjb-confirm-box">
        <p class="wjb-confirm-message" id="wjbConfirmMessage"></p>
        <div class="wjb-confirm-actions">
          <button type="button" class="gray" id="wjbConfirmCancelBtn">ยกเลิก</button>
          <button type="button" id="wjbConfirmOkBtn">ยืนยัน</button>
        </div>
      </div>`;
    document.body.appendChild(host);
    return host;
  }

  window.wjbConfirm = function(message, opts){
    opts = opts || {};
    return new Promise((resolve) => {
      const host = ensureConfirmHost();
      const msgEl = document.getElementById('wjbConfirmMessage');
      const okBtn = document.getElementById('wjbConfirmOkBtn');
      const cancelBtn = document.getElementById('wjbConfirmCancelBtn');

      msgEl.textContent = message || 'ยืนยันการดำเนินการนี้ใช่ไหม?';
      okBtn.textContent = opts.okText || 'ยืนยัน';
      cancelBtn.textContent = opts.cancelText || 'ยกเลิก';
      okBtn.className = opts.danger ? 'danger' : '';

      function cleanup(result){
        host.style.display = 'none';
        okBtn.removeEventListener('click', onOk);
        cancelBtn.removeEventListener('click', onCancel);
        host.removeEventListener('click', onBackdrop);
        document.removeEventListener('keydown', onKey);
        resolve(result);
      }
      function onOk(){ cleanup(true); }
      function onCancel(){ cleanup(false); }
      function onBackdrop(e){ if(e.target === host) cleanup(false); }
      function onKey(e){ if(e.key === 'Escape') cleanup(false); }

      okBtn.addEventListener('click', onOk);
      cancelBtn.addEventListener('click', onCancel);
      host.addEventListener('click', onBackdrop);
      document.addEventListener('keydown', onKey);

      host.style.display = 'flex';
      okBtn.focus();
    });
  };

  // ---------- Prompt Modal (single text/password input) ----------
  function ensurePromptHost(){
    let host = document.getElementById('wjbPromptModal');
    if(host) return host;
    host = document.createElement('div');
    host.id = 'wjbPromptModal';
    host.className = 'wjb-confirm-modal';
    host.style.display = 'none';
    host.innerHTML = `
      <div class="wjb-confirm-box">
        <p class="wjb-confirm-message" id="wjbPromptTitle"></p>
        <p class="hint" id="wjbPromptHint" style="display:none"></p>
        <input type="text" id="wjbPromptInput" class="wjb-prompt-input">
        <div class="wjb-confirm-actions">
          <button type="button" class="gray" id="wjbPromptCancelBtn">ยกเลิก</button>
          <button type="button" id="wjbPromptOkBtn">ตกลง</button>
        </div>
      </div>`;
    document.body.appendChild(host);
    return host;
  }

  window.wjbPromptModal = function(opts){
    opts = opts || {};
    return new Promise((resolve) => {
      const host = ensurePromptHost();
      const titleEl = document.getElementById('wjbPromptTitle');
      const hintEl = document.getElementById('wjbPromptHint');
      const input = document.getElementById('wjbPromptInput');
      const okBtn = document.getElementById('wjbPromptOkBtn');
      const cancelBtn = document.getElementById('wjbPromptCancelBtn');

      titleEl.textContent = opts.title || 'กรอกข้อมูล';
      if(opts.hint){ hintEl.textContent = opts.hint; hintEl.style.display = 'block'; }
      else { hintEl.style.display = 'none'; }
      input.type = opts.inputType || 'text';
      input.placeholder = opts.placeholder || '';
      input.value = opts.value || '';
      okBtn.textContent = opts.okText || 'ตกลง';
      cancelBtn.textContent = opts.cancelText || 'ยกเลิก';

      function cleanup(result){
        host.style.display = 'none';
        okBtn.removeEventListener('click', onOk);
        cancelBtn.removeEventListener('click', onCancel);
        input.removeEventListener('keydown', onKey);
        host.removeEventListener('click', onBackdrop);
        resolve(result);
      }
      function onOk(){ cleanup(input.value); }
      function onCancel(){ cleanup(null); }
      function onKey(e){
        if(e.key === 'Enter'){ e.preventDefault(); onOk(); }
        if(e.key === 'Escape'){ onCancel(); }
      }
      function onBackdrop(e){ if(e.target === host) cleanup(null); }

      okBtn.addEventListener('click', onOk);
      cancelBtn.addEventListener('click', onCancel);
      input.addEventListener('keydown', onKey);
      host.addEventListener('click', onBackdrop);

      host.style.display = 'flex';
      setTimeout(() => input.focus(), 30);
    });
  };

  // ---------- Loading-button helper ----------
  // Usage: const done = wjbBusy(btn, 'กำลังบันทึก...'); try{...}finally{ done(); }
  window.wjbBusy = function(btn, busyText){
    if(!btn) return function(){};
    const originalText = btn.innerText;
    const originalDisabled = btn.disabled;
    btn.disabled = true;
    if(busyText) btn.innerText = busyText;
    btn.classList.add('wjb-btn-busy');
    return function(){
      btn.disabled = originalDisabled;
      btn.innerText = originalText;
      btn.classList.remove('wjb-btn-busy');
    };
  };

  // Wraps an async function so the triggering button auto-disables while it runs.
  // btnRef can be an element, an id string, or an Event (uses event.currentTarget).
  window.withLoadingButton = async function(btnRef, asyncFn, busyText){
    let btn = null;
    if(btnRef && btnRef.currentTarget) btn = btnRef.currentTarget;
    else if(typeof btnRef === 'string') btn = document.getElementById(btnRef);
    else if(btnRef instanceof Element) btn = btnRef;
    const done = window.wjbBusy(btn, busyText);
    try{
      return await asyncFn();
    } finally {
      done();
    }
  };

})();
