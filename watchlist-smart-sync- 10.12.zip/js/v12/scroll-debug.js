import { $, VERSION, escapeText } from './utils.js';

const SCROLL_DEBUG_FILES = [
  './script.js',
  './js/legacy-app.js',
  './js/v12/index.js',
  './js/v12/navigation.js',
  './js/v12/qa-center.js',
  './js/v12/health.js',
  './js/v12/dev-mode.js',
  './style.css'
];

const RISK_PATTERNS = [
  {key:'scrollTo', label:'scrollTo / window.scroll', re:/\b(?:window\.)?(?:scrollTo|scrollBy|scroll)\s*\(/g, severity:'high', note:'อาจบังคับตำแหน่งระหว่างผู้ใช้เลื่อน'},
  {key:'scrollIntoView', label:'scrollIntoView', re:/\.scrollIntoView\s*\(/g, severity:'high', note:'อาจเด้งไปยัง element อัตโนมัติ'},
  {key:'scrollListener', label:'scroll event listener', re:/addEventListener\s*\(\s*['"]scroll['"]/g, severity:'medium', note:'ถ้าทำงานหนักระหว่าง scroll จะกระตุก'},
  {key:'touchmove', label:'touchmove listener', re:/addEventListener\s*\(\s*['"]touchmove['"]/g, severity:'medium', note:'อาจรบกวน momentum scroll บนมือถือ'},
  {key:'resize', label:'resize / visualViewport', re:/(?:addEventListener\s*\(\s*['"]resize['"]|visualViewport)/g, severity:'medium', note:'Safari เปลี่ยน viewport ตอนแถบ URL ย่อ/ขยาย'},
  {key:'overflow', label:'body/html overflow lock', re:/(?:document\.(?:body|documentElement)|body|html)\.style\.overflow|overflow\s*[:=]\s*['"]?(?:hidden|auto|scroll)/g, severity:'medium', note:'ล็อก/ปลดล็อก scroll ผิดจังหวะทำให้จอค้างหรือเด้ง'},
  {key:'heightVh', label:'100vh / 100dvh / innerHeight', re:/(?:100dvh|100vh|innerHeight|clientHeight)/g, severity:'medium', note:'มือถืออาจเปลี่ยนความสูง viewport ระหว่างเลื่อน'},
  {key:'positionFixed', label:'position fixed', re:/position\s*:\s*fixed/g, severity:'low', note:'ใช้ได้ แต่ต้องระวัง overlay โปร่งใสจับ touch'},
  {key:'setInterval', label:'setInterval / timer', re:/\bsetInterval\s*\(/g, severity:'low', note:'ถ้าคอยปรับ UI ระหว่างเลื่อนอาจทำให้กระตุก'},
  {key:'raf', label:'requestAnimationFrame', re:/\brequestAnimationFrame\s*\(/g, severity:'low', note:'ต้องไม่ทำงานหนักทุกเฟรม'}
];

let lastScrollDebugReport = null;
let liveMonitorInstalled = false;
let live = {scrollEvents:0, resizeEvents:0, touchStarts:0, touchEnds:0, lastY:0, maxJump:0, startedAt:Date.now()};

function lineNumberAt(text, index){
  return text.slice(0, index).split('\n').length;
}
function snippetAt(text, index){
  const start = Math.max(0, index - 90);
  const end = Math.min(text.length, index + 140);
  return text.slice(start, end).replace(/\s+/g, ' ').trim();
}
async function fetchText(path){
  const url = path + (path.includes('?') ? '&' : '?') + 'v=' + encodeURIComponent(VERSION) + '&audit=' + Date.now();
  const res = await fetch(url, {cache:'no-store'});
  if(!res.ok) throw new Error(res.status + ' ' + res.statusText);
  return await res.text();
}
async function scanFile(path){
  const text = await fetchText(path);
  const hits = [];
  for(const pattern of RISK_PATTERNS){
    const re = new RegExp(pattern.re.source, pattern.re.flags.includes('g') ? pattern.re.flags : pattern.re.flags + 'g');
    let match;
    while((match = re.exec(text))){
      hits.push({
        file:path,
        key:pattern.key,
        label:pattern.label,
        severity:pattern.severity,
        note:pattern.note,
        line:lineNumberAt(text, match.index),
        snippet:snippetAt(text, match.index)
      });
      if(match.index === re.lastIndex) re.lastIndex++;
    }
  }
  return {path, ok:true, size:text.length, hits};
}
function severityWeight(sev){ return sev === 'high' ? 3 : sev === 'medium' ? 2 : 1; }
function summarize(files){
  const hits = files.flatMap(f=>f.hits || []);
  const scoreRaw = hits.reduce((sum,h)=>sum + severityWeight(h.severity), 0);
  const high = hits.filter(h=>h.severity === 'high').length;
  const medium = hits.filter(h=>h.severity === 'medium').length;
  const low = hits.filter(h=>h.severity === 'low').length;
  const risk = scoreRaw >= 35 || high >= 8 ? 'สูง' : scoreRaw >= 14 || high >= 3 ? 'กลาง' : 'ต่ำ';
  return {hits, high, medium, low, scoreRaw, risk};
}
function renderSummary(summary){
  const tone = summary.risk === 'สูง' ? 'bad' : summary.risk === 'กลาง' ? 'warn' : 'ok';
  return `<div class="qa-score-grid scroll-debug-summary">
    <div class="qa-score-card"><small>Scroll Risk</small><b>${escapeText(summary.risk)}</b><span>${summary.scoreRaw} risk points</span></div>
    <div class="qa-score-card"><small>High</small><b>${summary.high}</b><span>จุดเสี่ยงสูง</span></div>
    <div class="qa-score-card"><small>Medium</small><b>${summary.medium}</b><span>ควรตรวจ</span></div>
    <div class="qa-score-card"><small>Low</small><b>${summary.low}</b><span>ข้อมูลประกอบ</span></div>
  </div><div class="wjb-v12-health-row scroll-debug-risk-${tone}"><b>คำแนะนำ</b><span>${summary.risk === 'สูง' ? 'ควรลด scrollTo/scrollIntoView และ overlay lock ที่ทำงานระหว่างเลื่อน' : summary.risk === 'กลาง' ? 'ควรตรวจเฉพาะจุดที่เกี่ยวกับ scroll/resize' : 'ความเสี่ยงต่ำ แต่ยังควรทดสอบบนเครื่องจริง'}</span></div>`;
}
function renderHits(summary){
  if(!summary.hits.length) return '<div class="wjb-v12-empty">ไม่พบ pattern เสี่ยงที่ตรวจได้</div>';
  const groups = {};
  summary.hits.forEach(h=>{ (groups[h.severity] ||= []).push(h); });
  const order = ['high','medium','low'];
  const title = {high:'🔴 High Risk', medium:'🟡 Medium Risk', low:'🔵 Low / Info'};
  return order.filter(k=>groups[k]).map(k=>`<details class="qa-group scroll-debug-group" ${k !== 'low' ? 'open' : ''}><summary>${title[k]} (${groups[k].length})</summary>${groups[k].map(h=>`<div class="wjb-v12-health-row qa-row scroll-debug-hit"><b>${escapeText(h.label)} <small>${escapeText(h.file)}:${h.line}</small></b><span>${escapeText(h.note)}</span><code>${escapeText(h.snippet)}</code></div>`).join('')}</details>`).join('');
}
function buildTextReport(report){
  const s = report.summary;
  const lines = ['WJB Scroll Debug Audit', 'Version: ' + VERSION, 'Time: ' + new Date().toLocaleString('th-TH'), '', `Risk: ${s.risk} | High ${s.high} | Medium ${s.medium} | Low ${s.low} | Points ${s.scoreRaw}`, ''];
  report.files.forEach(f=>{
    lines.push(`File: ${f.path} (${f.ok ? 'OK' : 'ERROR'})`);
    if(f.error) lines.push('  ' + f.error);
    (f.hits || []).forEach(h=>lines.push(`  [${h.severity.toUpperCase()}] ${h.label} @ line ${h.line} — ${h.note}`));
  });
  lines.push('', 'Live Monitor:', JSON.stringify(live));
  return lines.join('\n');
}
function installLiveMonitor(){
  if(liveMonitorInstalled) return;
  liveMonitorInstalled = true;
  live.startedAt = Date.now();
  let lastY = window.scrollY || document.documentElement.scrollTop || 0;
  live.lastY = lastY;
  window.addEventListener('scroll', ()=>{
    const y = window.scrollY || document.documentElement.scrollTop || 0;
    const jump = Math.abs(y - lastY);
    live.scrollEvents++;
    live.maxJump = Math.max(live.maxJump, Math.round(jump));
    live.lastY = Math.round(y);
    lastY = y;
  }, {passive:true});
  window.addEventListener('resize', ()=>{ live.resizeEvents++; }, {passive:true});
  window.addEventListener('touchstart', ()=>{ live.touchStarts++; }, {passive:true});
  window.addEventListener('touchend', ()=>{ live.touchEnds++; }, {passive:true});
}
function renderLiveMonitor(){
  const seconds = Math.max(1, Math.round((Date.now() - live.startedAt) / 1000));
  return `<h3>📡 Live Scroll Monitor</h3><div class="wjb-v12-health-list">
    <div class="wjb-v12-health-row"><b>Scroll Events</b><span>${live.scrollEvents} ครั้ง / ${seconds}s</span></div>
    <div class="wjb-v12-health-row"><b>Resize Events</b><span>${live.resizeEvents} ครั้ง</span></div>
    <div class="wjb-v12-health-row"><b>Touch</b><span>start ${live.touchStarts} / end ${live.touchEnds}</span></div>
    <div class="wjb-v12-health-row"><b>Max Jump</b><span>${live.maxJump}px</span></div>
  </div><p class="muted">Live Monitor แค่นับเหตุการณ์ ไม่บังคับ scroll และไม่ใช้ API เสียเงิน</p>`;
}
function renderReport(report){
  const box = $('scrollDebugContent') || $('qaCenterContent');
  if(!box) return;
  lastScrollDebugReport = report;
  box.innerHTML = renderSummary(report.summary) + renderLiveMonitor() + '<h3>🔎 Static Code Scan</h3>' + renderHits(report.summary) + '<details class="wjb-v12-details"><summary>ไฟล์ที่ตรวจ</summary>' + report.files.map(f=>`<div class="wjb-v12-health-row"><b>${escapeText(f.path)}</b><span>${f.ok ? `${(f.size/1024).toFixed(1)} KB / ${f.hits.length} hits` : escapeText(f.error)}</span></div>`).join('') + '</details>';
}
export async function runScrollDebugAudit(){
  installLiveMonitor();
  const box = $('scrollDebugContent') || $('qaCenterContent');
  if(box) box.innerHTML = '<div class="wjb-v12-loading">กำลังตรวจ Scroll Debug Audit แบบฟรี 100%...</div>';
  const files = [];
  for(const path of SCROLL_DEBUG_FILES){
    try{ files.push(await scanFile(path)); }
    catch(e){ files.push({path, ok:false, error:e.message || String(e), hits:[]}); }
  }
  const summary = summarize(files);
  const report = {version:VERSION, at:new Date().toISOString(), files, summary, live};
  report.text = buildTextReport(report);
  renderReport(report);
  return report;
}
export function installScrollDebugAudit(){
  installLiveMonitor();
  window.runWJBScrollDebugAudit = runScrollDebugAudit;
  window.copyWJBScrollDebugReport = async function(){
    if(!lastScrollDebugReport) await runScrollDebugAudit();
    const text = lastScrollDebugReport?.text || 'ยังไม่มีรายงาน Scroll Debug';
    try{ await navigator.clipboard.writeText(text); alert('คัดลอกรายงาน Scroll Debug แล้ว'); }
    catch(_e){ prompt('คัดลอกรายงาน Scroll Debug:', text); }
  };
}
