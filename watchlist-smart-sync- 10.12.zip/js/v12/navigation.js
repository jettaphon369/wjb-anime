import { SCROLL_KEY, safeJSONParse } from './utils.js';

const MODAL_SELECTORS = '.settings-modal,.modal,.wjb-smart-sheet-backdrop,.wjb-v11-sheet-backdrop,.wjb-detail-sheet,.wjb-v10-detail-sheet,.wjb-sheet-backdrop,.wjb-bottom-sheet-backdrop';
const NAV_FUNCTIONS = ['wjbNavAdd','wjbNavHome','wjbNavTrending','wjbNavExplore','wjbNavViewToggle'];

function isVisible(el){
  if(!el || !el.isConnected) return false;
  const style = getComputedStyle(el);
  const rect = el.getBoundingClientRect();
  return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0' && rect.width > 0 && rect.height > 0;
}

function removeLockClasses(){
  const body = document.body;
  if(!body) return;
  [
    'wjb-modal-open','wjb-real-modal-open','wjb-v84-real-modal-open',
    'wjb-hide-bottom-nav','wjb-force-hide-nav','wjb-subscreen-open',
    'wjb-v123-scroll-locked','wjb-v13-scroll-locked'
  ].forEach(c => body.classList.remove(c));
  body.classList.add('wjb-v13-nav-clean');
}

export function unlockBodyScroll(){
  const body = document.body;
  const html = document.documentElement;
  if(!body || !html) return;
  removeLockClasses();
  ['overflow','overflow-y','touch-action','position','height','top','left','right','width'].forEach(prop => body.style.removeProperty(prop));
  ['overflow','overflow-y','touch-action','height'].forEach(prop => html.style.removeProperty(prop));
  const app = document.querySelector('.app,#mainApp');
  if(app){
    app.style.removeProperty('pointer-events');
    app.style.removeProperty('overflow');
    app.style.removeProperty('touch-action');
  }
}

function neutralizeClosedOverlays(){
  document.querySelectorAll(MODAL_SELECTORS).forEach(el => {
    if(isVisible(el)) return;
    el.classList.remove('show','active','open');
    el.style.pointerEvents = 'none';
    if(el.classList.contains('wjb-smart-sheet-backdrop') || el.classList.contains('wjb-v11-sheet-backdrop') || el.classList.contains('wjb-bottom-sheet-backdrop')){
      try{ el.remove(); }catch(_e){ el.style.setProperty('display','none','important'); }
    }
  });
}

export function closeAllTransientSurfaces(){
  document.querySelectorAll(MODAL_SELECTORS).forEach(el => {
    if(!isVisible(el)){
      el.style.pointerEvents = 'none';
      return;
    }
    const id = el.id || '';
    // Keep core app sections untouched; these selectors should only be overlays.
    if(id === 'mainApp') return;
    el.classList.remove('show','active','open');
    el.style.setProperty('display','none','important');
    el.style.pointerEvents = 'none';
  });
  unlockBodyScroll();
  neutralizeClosedOverlays();
}

function prepareForNavigation(){
  // Close existing overlays before the nav action. Do NOT close again after the action,
  // because some nav actions intentionally open a new panel such as Trending.
  closeAllTransientSurfaces();
  unlockBodyScroll();
}

export function closeVisibleModal(){
  const modals = Array.from(document.querySelectorAll(MODAL_SELECTORS));
  const openModal = modals.reverse().find(isVisible);
  if(!openModal) return false;
  const closeButton = openModal.querySelector('.season-close-btn,.close,[data-close],button[aria-label="ปิด"],button[aria-label="Close"]');
  if(closeButton) closeButton.click();
  else{
    openModal.classList.remove('show','active','open');
    openModal.style.setProperty('display','none','important');
    openModal.style.pointerEvents = 'none';
  }
  unlockBodyScroll();
  neutralizeClosedOverlays();
  return true;
}

export function restoreSavedScrollIfNeeded(){
  const data = safeJSONParse(sessionStorage.getItem(SCROLL_KEY) || '{}', {});
  if(!data.y || Date.now() - data.at > 60000) return;
  requestAnimationFrame(()=>{
    try{ window.scrollTo({top:data.y, behavior:'auto'}); }catch(_e){ window.scrollTo(0, data.y); }
    setTimeout(()=>{ try{ sessionStorage.removeItem(SCROLL_KEY); }catch(_e){} }, 250);
  });
}

function installUserScrollStabilityGuard(){
  let timer = 0;
  const root = document.documentElement;
  const start = () => {
    root.classList.add('wjb-v13-user-scrolling');
    clearTimeout(timer);
  };
  const end = () => {
    clearTimeout(timer);
    timer = setTimeout(() => root.classList.remove('wjb-v13-user-scrolling'), 260);
  };
  window.addEventListener('touchstart', start, {passive:true});
  window.addEventListener('touchend', end, {passive:true});
  window.addEventListener('touchcancel', end, {passive:true});
  window.addEventListener('wheel', () => { start(); end(); }, {passive:true});
}

function wrapBottomNavFunctions(){
  NAV_FUNCTIONS.forEach(name => {
    const original = window[name];
    if(typeof original !== 'function' || original.__wjbV13Wrapped) return;
    const wrapped = function(...args){
      prepareForNavigation();
      const result = original.apply(this, args);
      // Only release stale scroll locks after render; do not close newly opened modals.
      setTimeout(() => { unlockBodyScroll(); neutralizeClosedOverlays(); }, 80);
      return result;
    };
    wrapped.__wjbV13Wrapped = true;
    window[name] = wrapped;
  });
}

function exposeNavDebug(){
  window.WJB_NAV_DEBUG = function(){
    const body = document.body;
    const visible = Array.from(document.querySelectorAll(MODAL_SELECTORS)).filter(isVisible).map(el => el.id || el.className || el.tagName);
    return {
      pageY: window.scrollY || document.documentElement.scrollTop || 0,
      bodyOverflow: body ? getComputedStyle(body).overflow : 'unknown',
      bodyPosition: body ? getComputedStyle(body).position : 'unknown',
      bodyClasses: body ? Array.from(body.classList).filter(c => /modal|lock|nav|subscreen|hide/i.test(c)) : [],
      visibleOverlays: visible,
      hiddenOverlayCount: Array.from(document.querySelectorAll(MODAL_SELECTORS)).filter(el => !isVisible(el)).length
    };
  };
}

export function installNavigationHelpers(){
  if(window.__wjbV13Navigation) return;
  window.__wjbV13Navigation = true;
  document.documentElement.classList.add('wjb-v13-lts');
  installUserScrollStabilityGuard();
  exposeNavDebug();

  window.addEventListener('keydown', (event)=>{ if(event.key === 'Escape' && closeVisibleModal()) event.preventDefault(); });
  window.addEventListener('popstate', ()=>closeVisibleModal());

  document.addEventListener('click', (event)=>{
    const navButton = event.target.closest('.wjb-v60-bottom-nav button');
    if(navButton){
      prepareForNavigation();
      return;
    }
    const editLike = event.target.closest('button,a');
    if(!editLike) return;
    const label = (editLike.textContent || '') + ' ' + (editLike.getAttribute('onclick') || '');
    if(/แก้ไข|edit|ยกเลิก|cancel|บันทึก|save/i.test(label)){
      try{ sessionStorage.setItem(SCROLL_KEY, JSON.stringify({y:window.scrollY || document.documentElement.scrollTop || 0, at:Date.now()})); }catch(_e){}
    }
  }, true);

  wrapBottomNavFunctions();
  setTimeout(wrapBottomNavFunctions, 300);
  setTimeout(wrapBottomNavFunctions, 1200);
  setTimeout(() => { unlockBodyScroll(); neutralizeClosedOverlays(); }, 600);

  window.WJB_V12 = Object.assign(window.WJB_V12 || {}, {
    restoreSavedScrollIfNeeded,
    closeVisibleModal,
    closeAllTransientSurfaces,
    unlockBodyScroll,
    prepareForNavigation,
    navigationVersion: 'v13-lts-navigation-core'
  });
}
