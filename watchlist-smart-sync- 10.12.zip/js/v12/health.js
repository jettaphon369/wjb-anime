import { $, VERSION, escapeText, formatBytes, statusPill } from './utils.js';
import { getErrors, clearErrors } from './error-log.js';
async function getCacheStatus(){
  if(!('caches' in window)) return {ok:false, text:'ไม่รองรับ Cache API'};
  try{
    const keys = await caches.keys();
    const current = keys.find((key)=>key.includes('v12') || key.includes('watchjettaphon'));
    return {ok:!!current, text:current || (keys.length ? keys.join(', ') : 'ยังไม่มี cache')};
  }catch(e){ return {ok:false, text:e.message}; }
}
async function ping(url, label){
  const start = performance.now();
  try{
    const res = await fetch(url, {cache:'no-store'});
    return {label, ok:res.ok, ms:Math.round(performance.now() - start), status:res.status};
  }catch(e){ return {label, ok:false, ms:0, status:e.message || 'offline'}; }
}
async function collectHealth(){
  const storage = navigator.storage && navigator.storage.estimate ? await navigator.storage.estimate().catch(()=>null) : null;
  const cache = await getCacheStatus();
  const sw = navigator.serviceWorker ? await navigator.serviceWorker.getRegistration().catch(()=>null) : null;
  const nav = performance.getEntriesByType && performance.getEntriesByType('navigation')[0];
  const loadTime = nav ? Math.round(nav.loadEventEnd || performance.now()) : Math.round(performance.now());
  const apiTests = await Promise.all([
    ping('https://api.jikan.moe/v4/anime?q=one%20piece&limit=1', 'Jikan'),
    ping('https://api.tvmaze.com/search/shows?q=one%20piece', 'TVMaze')
  ]);
  return {
    online:navigator.onLine,
    standalone:window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true,
    swActive:!!(sw && sw.active), cache, storage, loadTime, apiTests,
    errors:getErrors(), viewport:window.innerWidth + '×' + window.innerHeight, ua:navigator.userAgent
  };
}
export async function renderSystemHealth(){
  const box = $('systemHealthContent');
  if(!box) return;
  box.innerHTML = '<div class="wjb-v12-loading">กำลังตรวจระบบฟรี 100%...</div>';
  const health = await collectHealth();
  const apiHtml = health.apiTests.map((api)=>'<div class="wjb-v12-health-row"><b>' + escapeText(api.label) + '</b><span>' + (api.ok ? '🟢 ' + api.ms + ' ms' : '🔴 ' + escapeText(api.status)) + '</span></div>').join('');
  const errorHtml = health.errors.length ? health.errors.slice(-8).reverse().map((err)=>'<div class="wjb-v12-error"><b>' + escapeText(err.type) + '</b><span>' + escapeText(err.message) + '</span><small>' + new Date(err.at).toLocaleString('th-TH') + '</small></div>').join('') : '<div class="wjb-v12-empty">ยังไม่พบ Error ที่บันทึกไว้</div>';
  box.innerHTML =
    '<div class="wjb-v12-health-grid">' +
    '<div class="wjb-v12-health-card"><small>Version</small><b>v12.6 Scroll Debug Audit</b><span>' + VERSION + '</span></div>' +
    '<div class="wjb-v12-health-card"><small>Network</small>' + statusPill(health.online, 'Online', 'Offline') + '</div>' +
    '<div class="wjb-v12-health-card"><small>PWA</small>' + '<span class="wjb-v12-pill warn">🟡 ' + (health.standalone ? 'Standalone' : 'Browser Mode') + '</span>' + '</div>' +
    '<div class="wjb-v12-health-card"><small>Service Worker</small>' + statusPill(health.swActive, 'Active', 'Not Active') + '</div>' +
    '<div class="wjb-v12-health-card"><small>Cache</small>' + statusPill(health.cache.ok, 'Ready', 'Not Ready') + '<span>' + escapeText(health.cache.text) + '</span></div>' +
    '<div class="wjb-v12-health-card"><small>Storage</small><b>' + formatBytes(health.storage && health.storage.usage) + '</b><span>/ ' + formatBytes(health.storage && health.storage.quota) + '</span></div>' +
    '<div class="wjb-v12-health-card"><small>Load</small><b>' + health.loadTime + ' ms</b><span>โหลดหน้าโดยประมาณ</span></div>' +
    '<div class="wjb-v12-health-card"><small>Viewport</small><b>' + health.viewport + '</b><span>iPhone / Android / Desktop</span></div>' +
    '</div><h3>🌐 Free API Status</h3><div class="wjb-v12-health-list">' + apiHtml + '</div>' +
    '<h3>📝 Error Log</h3><div class="wjb-v12-error-list">' + errorHtml + '</div>' +
    '<details class="wjb-v12-details"><summary>ข้อมูลอุปกรณ์</summary><p>' + escapeText(health.ua) + '</p></details>';
}
export function installSystemHealth(){
  window.openSystemHealthDashboard = function(){
    const modal = $('systemHealthModal');
    if(modal){ modal.style.display = 'flex'; history.pushState({wjbModal:'systemHealth'}, '', location.href); renderSystemHealth(); }
  };
  window.closeSystemHealthDashboard = function(){ const modal = $('systemHealthModal'); if(modal) modal.style.display = 'none'; };
  window.refreshSystemHealthDashboard = renderSystemHealth;
  window.clearWJBLocalErrorLog = function(){ clearErrors(); renderSystemHealth(); };
}
