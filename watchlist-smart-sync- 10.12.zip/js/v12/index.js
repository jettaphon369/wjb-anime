/* WJB v12.1 Safe Modular Core — free-only helper entrypoint */
import { VERSION } from './utils.js';
import { installErrorCapture, setErrorLogChangeHandler } from './error-log.js';
import { installNavigationHelpers } from './navigation.js';
import { installSystemHealth } from './health.js';
import { installDeveloperMode, updateDevPanel } from './dev-mode.js';
import { installQACenter } from './qa-center.js';
import { installScrollDebugAudit } from './scroll-debug.js';
import { installModalStability } from './modal-stability.js';

window.WJB_V12 = Object.assign(window.WJB_V12 || {}, { version: VERSION, freeOnly: true, startedAt: window.WJB_V12?.startedAt || Date.now(), modular: true });

function start(){
  document.documentElement.classList.add('wjb-v12-free-core-ready', 'wjb-v12-4-scroll-stable', 'wjb-v12-5-no-jitter', 'wjb-v12-6-scroll-debug', 'wjb-v13-1-critical-interaction-unlock', 'wjb-v13-2-admin-responsive', 'wjb-v13-5-admin-mobile-fix');
  installErrorCapture();
  setErrorLogChangeHandler(updateDevPanel);
  installNavigationHelpers();
  installSystemHealth();
  installDeveloperMode();
  installQACenter();
  installScrollDebugAudit();
  installModalStability();
}

if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, {once:true});
else start();


function groupSeries(list){
  const map = {};
  list.forEach(item=>{
    const id = item.seriesId || item.title;
    if(!map[id]){
      map[id] = {seriesId:id,title:item.title,seasons:[]};
    }
    map[id].seasons.push(item.season);
  });
  return Object.values(map);
}
