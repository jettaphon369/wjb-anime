import { $, VERSION, escapeText, statusPill, safeSetItem } from './utils.js';
import { getErrors } from './error-log.js';

const QA_KEY = 'wjb_v12_2_qa_manual_checklist';
let lastQAReport = null;

function boolCheck(label, ok, detail, group='Core'){
  return { label, ok: !!ok, detail: detail || (ok ? 'พร้อมใช้งาน' : 'ต้องตรวจสอบ'), group };
}
function hasFn(name){ return typeof window[name] === 'function'; }
function hasEl(id){ return !!$(id); }
function getManualChecks(){
  try{ return JSON.parse(localStorage.getItem(QA_KEY) || '{}') || {}; }catch(_e){ return {}; }
}
function saveManualChecks(data){ safeSetItem(QA_KEY, JSON.stringify(data || {})); }
function manualItems(){
  return [
    ['login','Login / Logout บนเครื่องจริง'],
    ['search','ค้นหาออนไลน์ + เลือกไปกรอกฟอร์ม'],
    ['add','เพิ่มรายการ + เด้งกลับรายการล่าสุด'],
    ['edit','แก้ไข + บันทึก + ยกเลิกกลับตำแหน่งเดิม'],
    ['delete','ลบรายการ / ยืนยันก่อนลบ'],
    ['trending','Trending เปิด-เลื่อน-ปิด'],
    ['admin','Admin / Activity Log / System Health'],
    ['iphone','iPhone Safari / PWA / Safe Area'],
    ['android','Android Chrome / Back Button / PWA'],
    ['desktop','Desktop Responsive']
  ];
}
async function getCacheNames(){
  if(!('caches' in window)) return [];
  try{ return await caches.keys(); }catch(_e){ return []; }
}
async function quickPing(url){
  const start = performance.now();
  try{
    const controller = new AbortController();
    const timeout = setTimeout(()=>controller.abort(), 5500);
    const res = await fetch(url, {cache:'no-store', signal:controller.signal});
    clearTimeout(timeout);
    return {ok:res.ok, ms:Math.round(performance.now()-start), status:res.status};
  }catch(e){ return {ok:false, ms:0, status:e.name === 'AbortError' ? 'Timeout' : (e.message || 'Error')}; }
}
async function collectAutoChecks(){
  const cacheNames = await getCacheNames();
  const sw = navigator.serviceWorker ? await navigator.serviceWorker.getRegistration().catch(()=>null) : null;
  const storage = navigator.storage && navigator.storage.estimate ? await navigator.storage.estimate().catch(()=>null) : null;
  const api = await Promise.all([
    quickPing('https://api.jikan.moe/v4/anime?q=one%20piece&limit=1').then(r=>({name:'Jikan', ...r})),
    quickPing('https://api.tvmaze.com/search/shows?q=one%20piece').then(r=>({name:'TVMaze', ...r}))
  ]);
  const checks = [
    boolCheck('Bootstrap v12.2', !!window.WJB_V12 && window.WJB_V12.freeOnly === true, VERSION, 'Core'),
    boolCheck('Legacy App Loaded', hasFn('switchTab') || hasFn('toggleMenu'), 'พบฟังก์ชันหลักของแอปเดิม', 'Core'),
    boolCheck('Form Area', hasEl('formBox') && hasEl('title') && hasEl('type') && hasEl('status'), 'พบฟอร์มเพิ่ม/แก้ไขรายการ', 'My List'),
    boolCheck('List Area', hasEl('list'), 'พบพื้นที่แสดงรายการของฉัน', 'My List'),
    boolCheck('Search Field', hasEl('search'), 'พบช่องค้นหาในรายการ', 'Search'),
    boolCheck('Trending Modal', hasEl('trendingModal') && hasFn('openTrendingExplorer'), 'พบระบบ Trending', 'Trending'),
    boolCheck('Season Detail Modal', hasEl('seasonDetailModal'), 'พบหน้ารายละเอียด/ซีซั่น', 'Details'),
    boolCheck('Admin Modal', hasEl('adminModal') && hasFn('openAdminPanel'), 'พบแผงแอดมิน', 'Admin'),
    boolCheck('System Health', hasEl('systemHealthModal') && hasFn('openSystemHealthDashboard'), 'พร้อมตรวจสุขภาพระบบ', 'Admin'),
    boolCheck('QA Center', hasEl('qaCenterModal'), 'พร้อมใช้งาน QA Center', 'Admin'),
    boolCheck('Developer Mode', hasFn('toggleWJBDeveloperMode'), 'เปิด/ปิด Developer Mode ได้', 'Admin'),
    boolCheck('Error Capture', Array.isArray(getErrors()), `${getErrors().length} error(s)`, 'Diagnostics'),
    boolCheck('Online Status', typeof navigator.onLine === 'boolean', navigator.onLine ? 'Online' : 'Offline', 'Platform'),
    boolCheck('Service Worker', !!(sw && sw.active), sw && sw.active ? 'Active' : 'ยังไม่ active / ต้องเปิดผ่าน HTTPS หรือ deploy จริง', 'PWA'),
    boolCheck('Cache Version', cacheNames.some(n=>n.includes('v12-2') || n.includes('v12-2-qa')), cacheNames.join(', ') || 'ยังไม่มี cache', 'PWA'),
    boolCheck('PWA Manifest', !!document.querySelector('link[rel="manifest"]'), 'พบ manifest link', 'PWA'),
    boolCheck('Safe Area Support', CSS.supports('padding-bottom: env(safe-area-inset-bottom)'), 'รองรับ env(safe-area-inset-bottom)', 'Cross Platform'),
    boolCheck('Storage Estimate', !!storage, storage ? `usage ${Math.round((storage.usage||0)/1024/1024)} MB` : 'ไม่รองรับ navigator.storage', 'Platform')
  ];
  api.forEach(a=>checks.push(boolCheck(`${a.name} API`, a.ok, a.ok ? `${a.ms} ms` : String(a.status), 'Free API')));
  return checks;
}
function renderSummary(checks, manual){
  const autoPass = checks.filter(c=>c.ok).length;
  const manualPass = manualItems().filter(([key])=>manual[key]).length;
  const autoPct = checks.length ? Math.round(autoPass/checks.length*100) : 0;
  const manualPct = Math.round(manualPass/manualItems().length*100);
  const overall = Math.round((autoPct*0.65) + (manualPct*0.35));
  return `<div class="qa-score-grid">
    <div class="qa-score-card"><small>Overall</small><b>${overall}%</b><span>${overall >= 90 ? 'พร้อมมาก' : overall >= 70 ? 'ควรทดสอบเพิ่ม' : 'ต้องตรวจเพิ่ม'}</span></div>
    <div class="qa-score-card"><small>Auto Checks</small><b>${autoPass}/${checks.length}</b><span>${autoPct}%</span></div>
    <div class="qa-score-card"><small>Manual QA</small><b>${manualPass}/${manualItems().length}</b><span>${manualPct}%</span></div>
    <div class="qa-score-card"><small>Errors</small><b>${getErrors().length}</b><span>localStorage log</span></div>
  </div>`;
}
function renderAutoChecks(checks){
  const groups = {};
  checks.forEach(c=>{ (groups[c.group] ||= []).push(c); });
  return Object.entries(groups).map(([group, rows])=>`<details class="qa-group" open><summary>${escapeText(group)}</summary>${rows.map(c=>`<div class="wjb-v12-health-row qa-row"><b>${c.ok ? '✅' : '⚠️'} ${escapeText(c.label)}</b><span>${escapeText(c.detail)}</span></div>`).join('')}</details>`).join('');
}
function renderManualChecklist(manual){
  return `<div class="qa-manual-list">${manualItems().map(([key,label])=>`<label class="qa-manual-item"><input type="checkbox" data-qa-key="${key}" ${manual[key] ? 'checked' : ''}> <span>${escapeText(label)}</span></label>`).join('')}</div>`;
}
function bindManualChecks(){
  document.querySelectorAll('[data-qa-key]').forEach(input=>{
    if(input.__wjbQABound) return;
    input.__wjbQABound = true;
    input.addEventListener('change', ()=>{
      const manual = getManualChecks();
      manual[input.dataset.qaKey] = input.checked;
      saveManualChecks(manual);
      if(lastQAReport) renderQA(lastQAReport.checks);
    });
  });
}
function buildReportText(checks, manual){
  const lines = [`WJB QA Center Report`, `Version: ${VERSION}`, `Time: ${new Date().toLocaleString('th-TH')}`, ''];
  lines.push('Auto Checks:');
  checks.forEach(c=>lines.push(`${c.ok ? 'PASS' : 'WARN'} - ${c.group} - ${c.label}: ${c.detail}`));
  lines.push('', 'Manual Checklist:');
  manualItems().forEach(([key,label])=>lines.push(`${manual[key] ? 'PASS' : 'TODO'} - ${label}`));
  lines.push('', `Errors: ${getErrors().length}`);
  return lines.join('\n');
}
function renderQA(checks){
  const box = $('qaCenterContent'); if(!box) return;
  const manual = getManualChecks();
  lastQAReport = {checks, manual, text:buildReportText(checks, manual)};
  box.innerHTML = renderSummary(checks, manual) +
    '<h3>🔎 Auto Checks</h3>' + renderAutoChecks(checks) +
    '<h3>☑️ Manual QA Checklist</h3><p class="muted">ข้อเหล่านี้ต้องลองบนเครื่องจริง โดยเฉพาะ iPhone/Android หลัง deploy</p>' + renderManualChecklist(manual) +
    '<details class="wjb-v12-details"><summary>QA Report Text</summary><pre class="qa-report-text">' + escapeText(lastQAReport.text) + '</pre></details>';
  bindManualChecks();
}
export async function runQAChecks(){
  const box = $('qaCenterContent');
  if(box) box.innerHTML = '<div class="wjb-v12-loading">กำลังตรวจ QA แบบฟรี 100%...</div>';
  const checks = await collectAutoChecks();
  renderQA(checks);
}
export function installQACenter(){
  window.openWJBQACenter = function(){
    const modal = $('qaCenterModal');
    if(modal){ modal.style.display = 'flex'; history.pushState({wjbModal:'qaCenter'}, '', location.href); runQAChecks(); }
  };
  window.closeWJBQACenter = function(){ const modal = $('qaCenterModal'); if(modal) modal.style.display = 'none'; };
  window.runWJBQAChecks = runQAChecks;
  window.resetWJBQAChecklist = function(){ localStorage.removeItem(QA_KEY); runQAChecks(); };
  window.copyWJBQAReport = async function(){
    if(!lastQAReport) await runQAChecks();
    const text = lastQAReport?.text || 'ยังไม่มีรายงาน QA';
    try{ await navigator.clipboard.writeText(text); alert('คัดลอกรายงาน QA แล้ว'); }
    catch(_e){ prompt('คัดลอกรายงาน QA:', text); }
  };
}
