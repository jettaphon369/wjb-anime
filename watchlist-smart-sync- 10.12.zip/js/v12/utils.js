export const VERSION = 'premium-ui-v13-5-admin-mobile-card-fix';
export const ERROR_KEY = 'wjb_v12_error_log';
export const DEV_KEY = 'wjb_v12_developer_mode';
export const SCROLL_KEY = 'wjb_v12_last_scroll';
export const MAX_ERRORS = 40;
export function $(id){ return document.getElementById(id); }
export function safeJSONParse(value, fallback){ try{ return JSON.parse(value); }catch(_e){ return fallback; } }
// เขียนค่าลง localStorage อย่างปลอดภัย กัน throw ตอน storage เต็ม (มือถือหลายรุ่นจำกัด ~5MB)
// คืน true/false ว่าสำเร็จไหม เผื่อฝั่งเรียกอยากแจ้งเตือนผู้ใช้
export function safeSetItem(key, value){
  try{ localStorage.setItem(key, value); return true; }
  catch(_e){ return false; }
}
export function escapeText(value){ return String(value ?? '').replace(/[<>&"']/g, (m)=>({ '<':'&lt;', '>':'&gt;', '&':'&amp;', '"':'&quot;', "'":'&#039;' }[m])); }
export function formatBytes(bytes){
  if(!bytes && bytes !== 0) return 'ไม่ทราบ';
  const mb = bytes / 1024 / 1024;
  if(mb < 1024) return mb.toFixed(1) + ' MB';
  return (mb / 1024).toFixed(2) + ' GB';
}
export function statusPill(ok, goodText, badText){
  return '<span class="wjb-v12-pill ' + (ok ? 'ok' : 'bad') + '">' + (ok ? '🟢 ' + goodText : '🔴 ' + badText) + '</span>';
}
