/* WJB v13.1 Critical Modal/Overlay Stability
   Goal: prevent feature screens from trapping touch/scroll behind transparent overlays.
   Free-only: browser APIs only.
*/
const VISIBLE_SURFACE_SELECTOR = '.settings-modal,.modal,.wjb-smart-sheet-backdrop,.wjb-v11-sheet-backdrop,.wjb-bottom-sheet-backdrop,.wjb-sheet-backdrop';
const NAV_SELECTOR = '.wjb-v60-bottom-nav';

function getStyle(el){ try{ return getComputedStyle(el); }catch(_e){ return null; } }

function isVisibleSurface(el){
  if(!el || !el.isConnected) return false;
  const st = getStyle(el);
  if(!st) return false;
  const display = (el.style && el.style.display) || st.display;
  const rect = el.getBoundingClientRect();
  return display !== 'none' && st.visibility !== 'hidden' && st.opacity !== '0' && rect.width > 4 && rect.height > 4;
}

function isAppSurface(el){
  if(!el) return false;
  const id = el.id || '';
  return id === 'mainApp' || id === 'app' || el.classList?.contains('app');
}

export function forceUnlockPageScroll(){
  const body = document.body;
  const html = document.documentElement;
  if(!body || !html) return;

  // v13.1: old modal-lock used position:fixed + negative top. It caused frozen pages on iPhone.
  const rawTop = body.style.top || '';
  const wasFixed = body.style.position === 'fixed';
  const restoreY = rawTop && /^-?\d+px$/.test(rawTop) ? Math.abs(parseInt(rawTop, 10)) : 0;

  ['overflow','overflow-y','touch-action','position','height','top','left','right','width'].forEach((prop)=>body.style.removeProperty(prop));
  ['overflow','overflow-y','touch-action','position','height'].forEach((prop)=>html.style.removeProperty(prop));

  body.classList.remove(
    'wjb-modal-open','wjb-real-modal-open','wjb-v84-real-modal-open',
    'wjb-v123-scroll-locked','wjb-v13-scroll-locked','wjb-scroll-locked'
  );

  const app = document.querySelector('.app,#mainApp');
  if(app){
    app.style.removeProperty('pointer-events');
    app.style.removeProperty('touch-action');
    app.style.removeProperty('overflow');
  }

  if(wasFixed && restoreY > 0 && !document.documentElement.classList.contains('wjb-v131-user-scrolling')){
    // Restore only after a forced fixed-body lock, and never while the user is actively scrolling.
    requestAnimationFrame(()=>{
      try{ window.scrollTo({ top: restoreY, behavior: 'auto' }); }
      catch(_e){ try{ window.scrollTo(0, restoreY); }catch(__e){} }
    });
  }
}

export function closeStaleInvisibleSurfaces(){
  document.querySelectorAll(VISIBLE_SURFACE_SELECTOR).forEach((el)=>{
    if(isAppSurface(el)) return;
    if(isVisibleSurface(el)) return;
    el.classList.remove('show','active','open');
    el.style.pointerEvents = 'none';
    if(el.classList.contains('wjb-smart-sheet-backdrop') || el.classList.contains('wjb-v11-sheet-backdrop') || el.classList.contains('wjb-bottom-sheet-backdrop')){
      try{ el.remove(); }catch(_e){ el.style.setProperty('display','none','important'); }
    }
  });
}

export function closeAllFeatureSurfaces(){
  document.querySelectorAll(VISIBLE_SURFACE_SELECTOR).forEach((el)=>{
    if(isAppSurface(el)) return;
    if(!isVisibleSurface(el)) return;
    el.classList.remove('show','active','open');
    el.style.setProperty('display','none','important');
    el.style.pointerEvents = 'none';
  });
  forceUnlockPageScroll();
  closeStaleInvisibleSurfaces();
  syncModalState();
}

export function syncModalState(){
  const body = document.body;
  if(!body) return false;
  const openSurfaces = Array.from(document.querySelectorAll(VISIBLE_SURFACE_SELECTOR))
    .filter((el)=>!isAppSurface(el) && isVisibleSurface(el));
  const hasOpen = openSurfaces.length > 0;

  body.classList.toggle('wjb-v131-feature-surface-open', hasOpen);
  body.dataset.wjbOpenSurfaces = String(openSurfaces.length);

  // Keep the visible modal scrollable, but never body-lock the whole app.
  forceUnlockPageScroll();

  openSurfaces.forEach((el)=>{
    el.style.setProperty('pointer-events','auto','important');
    el.style.setProperty('overflow-y','auto','important');
    el.style.setProperty('-webkit-overflow-scrolling','touch');
  });

  const nav = document.querySelector(NAV_SELECTOR);
  if(nav){
    if(hasOpen){
      nav.style.setProperty('display','none','important');
      nav.style.setProperty('pointer-events','none','important');
    }else{
      nav.style.removeProperty('display');
      nav.style.removeProperty('pointer-events');
      // Let the existing bottom-nav controller re-apply its normal style.
      if(typeof window.wjbUpdateBottomNavVisibility === 'function'){
        setTimeout(()=>{ try{ window.wjbUpdateBottomNavVisibility(); }catch(_e){} }, 30);
      }
    }
  }
  return hasOpen;
}

function wrapSurfaceFunctions(){
  // v14.10: openTrendingExplorer, openSettings, openGuardianAI, openControlCenter,
  // openSystemHealthDashboard, showPWAInstallHelp moved out of this list — they are
  // now wrapped exactly once, by menu-drawer-stability.js, which also calls
  // forceUnlockPageScroll()/syncModalState() (exposed on window below) so the
  // same effect happens without a second wrap layer and a second timer cascade
  // on every single click.
  const names = [
    'closeTrendingExplorer','openSeasonDetail','closeSeasonDetail',
    'openHallOfFame','closeHallOfFame','closeSettings',
    'openPersonalAI','closePersonalAI','openAdmin','closeAdmin','closeControlCenter',
    'closeGuardianAI','closeSystemHealthDashboard',
    'openQACenter','closeQACenter','chooseAvatar','closeAvatarModal','closePWAInstallHelp'
  ];
  names.forEach((name)=>{
    const fn = window[name];
    if(typeof fn !== 'function' || fn.__wjbV131SurfaceWrapped) return;
    const wrapped = function(...args){
      // Always start from an unlocked state before opening/changing surfaces.
      forceUnlockPageScroll();
      const out = fn.apply(this, args);
      setTimeout(syncModalState, 0);
      setTimeout(syncModalState, 260);
      return out;
    };
    wrapped.__wjbV131SurfaceWrapped = true;
    window[name] = wrapped;
  });
}

// Exposed once so menu-drawer-stability.js (a plain script, not a module) can
// call these directly for the 6 functions it now wraps on its own.
window.forceUnlockPageScroll = forceUnlockPageScroll;
window.syncModalState = syncModalState;

function installNavClickCleaner(){
  document.addEventListener('click', (event)=>{
    const navBtn = event.target.closest(NAV_SELECTOR + ' button');
    if(!navBtn) return;
    // If the bottom nav somehow remains visible while a feature modal exists, clear it first.
    closeAllFeatureSurfaces();
  }, true);
}

function installUserScrollFlag(){
  let timer = 0;
  const root = document.documentElement;
  const start = ()=>{
    root.classList.add('wjb-v131-user-scrolling');
    clearTimeout(timer);
  };
  const end = ()=>{
    clearTimeout(timer);
    timer = setTimeout(()=>root.classList.remove('wjb-v131-user-scrolling'), 260);
  };
  window.addEventListener('touchstart', start, {passive:true});
  window.addEventListener('touchmove', start, {passive:true});
  window.addEventListener('touchend', end, {passive:true});
  window.addEventListener('touchcancel', end, {passive:true});
  window.addEventListener('wheel', ()=>{ start(); end(); }, {passive:true});
}

function observeSurfaces(){
  let raf = 0;
  const schedule = ()=>{
    if(raf) return;
    raf = requestAnimationFrame(()=>{ raf = 0; syncModalState(); closeStaleInvisibleSurfaces(); });
  };

  // เดิม: observe ทั้ง <html> ด้วย {subtree:true, childList:true} ซึ่งจะ trigger
  // ทุกครั้งที่ DOM ไหนๆ เปลี่ยน (เช่น ลิสต์เรื่อง re-render ตอนพิมพ์ค้นหา) แล้วยังยิง
  // getComputedStyle/getBoundingClientRect ต่อใน syncModalState/closeStaleInvisibleSurfaces
  // ทำให้ reflow รัวๆ ยิ่ง DOM ใหญ่ยิ่งหนัก
  // ใหม่: เฝ้าเฉพาะ attribute (style/class) ของ node ที่เป็น modal/overlay ที่รู้จักอยู่แล้ว
  // (นิ่ง ไม่ได้ถูกสร้าง/ลบบ่อย) บวกกับเฝ้า childList แบบตื้น (ไม่ subtree) ที่ <body>
  // เพื่อจับ backdrop ที่ถูก appendChild เข้า body ตรงๆ (เช่น wjbSmartDetailSheet)
  const attrObs = new MutationObserver(schedule);
  function watchNode(el){
    if(!el || el.__wjbV131AttrObserved) return;
    el.__wjbV131AttrObserved = true;
    attrObs.observe(el, { attributes:true, attributeFilter:['style','class'] });
  }
  function watchExistingSurfaces(){
    document.querySelectorAll(VISIBLE_SURFACE_SELECTOR).forEach(watchNode);
  }

  const bodyObs = new MutationObserver((mutations)=>{
    let sawNewSurface = false;
    mutations.forEach((m)=>{
      m.addedNodes && m.addedNodes.forEach((node)=>{
        if(node.nodeType !== 1) return;
        if(node.matches && node.matches(VISIBLE_SURFACE_SELECTOR)){
          watchNode(node);
          sawNewSurface = true;
        }
      });
    });
    if(sawNewSurface) schedule();
  });
  if(document.body){
    bodyObs.observe(document.body, { childList:true, subtree:false });
  }

  watchExistingSurfaces();
  ['pageshow','resize','orientationchange','visibilitychange'].forEach((ev)=>window.addEventListener(ev, schedule, {passive:true}));
  return schedule;
}

export function installModalStability(){
  if(window.__wjbV131ModalStability) return;
  window.__wjbV131ModalStability = true;
  document.documentElement.classList.add('wjb-v13-1-modal-stability');
  installUserScrollFlag();
  installNavClickCleaner();
  const schedule = observeSurfaces();
  wrapSurfaceFunctions();
  setTimeout(wrapSurfaceFunctions, 300);
  setTimeout(wrapSurfaceFunctions, 1200);
  setTimeout(schedule, 60);
  setTimeout(schedule, 500);
  window.WJB_MODAL_STABILITY = { syncModalState, forceUnlockPageScroll, closeAllFeatureSurfaces, closeStaleInvisibleSurfaces, version:'v13.1-critical-interaction-unlock' };
}
