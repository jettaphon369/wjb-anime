import { $, DEV_KEY, safeSetItem } from './utils.js';
import { getErrors } from './error-log.js';
let devPanelTimer = null;
function buildDevPanel(){
  let panel = $('wjbV12DevPanel');
  if(panel) return panel;
  panel = document.createElement('div');
  panel.id = 'wjbV12DevPanel';
  panel.className = 'wjb-v12-dev-panel';
  panel.innerHTML = '<button type="button" onclick="toggleWJBDeveloperMode()">×</button><div id="wjbV12DevPanelContent">Developer Mode</div>';
  document.body.appendChild(panel);
  return panel;
}
export function updateDevPanel(){
  if(localStorage.getItem(DEV_KEY) !== '1') return;
  buildDevPanel();
  const content = $('wjbV12DevPanelContent');
  if(!content) return;
  const mem = performance.memory ? Math.round(performance.memory.usedJSHeapSize / 1024 / 1024) + ' MB' : 'N/A';
  content.innerHTML = '<b>WJB v12.2 Dev</b><span>Online: ' + (navigator.onLine ? '🟢' : '🔴') + '</span><span>Memory: ' + mem + '</span><span>Errors: ' + getErrors().length + '</span><span>Load: ' + Math.round(performance.now()) + ' ms</span>';
}
function setDevMode(enabled){
  if(enabled){
    safeSetItem(DEV_KEY, '1'); buildDevPanel(); updateDevPanel();
    devPanelTimer = devPanelTimer || setInterval(updateDevPanel, 2500);
  }else{
    localStorage.removeItem(DEV_KEY);
    const panel = $('wjbV12DevPanel'); if(panel) panel.remove();
    if(devPanelTimer) clearInterval(devPanelTimer); devPanelTimer = null;
  }
  const btn = $('developerModeToggleBtn');
  if(btn) btn.textContent = enabled ? '🧪 ปิด Developer Mode' : '🧪 Developer Mode';
}
export function installDeveloperMode(){
  window.toggleWJBDeveloperMode = function(){ setDevMode(localStorage.getItem(DEV_KEY) !== '1'); };
  const installLogoTapUnlock = ()=>{
    const logo = document.querySelector('.wjb-v73-hero-center h2');
    if(!logo || logo.__wjbV121LogoTap) return;
    logo.__wjbV121LogoTap = true;
    let taps = 0; let timer = null;
    logo.style.cursor = 'pointer';
    logo.addEventListener('click', ()=>{
      taps += 1; clearTimeout(timer); timer = setTimeout(()=>{ taps = 0; }, 1400);
      if(taps >= 7){ taps = 0; setDevMode(localStorage.getItem(DEV_KEY) !== '1'); }
    });
  };
  installLogoTapUnlock();
  if(localStorage.getItem(DEV_KEY) === '1') setDevMode(true);
  window.addEventListener('online', updateDevPanel);
  window.addEventListener('offline', updateDevPanel);
}
