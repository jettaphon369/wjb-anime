import { ERROR_KEY, MAX_ERRORS, safeJSONParse } from './utils.js';
let onChange = null;
export function setErrorLogChangeHandler(fn){ onChange = typeof fn === 'function' ? fn : null; }
export function getErrors(){ return safeJSONParse(localStorage.getItem(ERROR_KEY) || '[]', []); }
export function saveErrors(errors){ try{ localStorage.setItem(ERROR_KEY, JSON.stringify(errors.slice(-MAX_ERRORS))); }catch(_e){} }
export function clearErrors(){ saveErrors([]); if(onChange) onChange(); }
export function logError(type, message, detail){
  const errors = getErrors();
  errors.push({
    type: type || 'error',
    message: String(message || 'Unknown error').slice(0, 240),
    detail: detail ? String(detail).slice(0, 700) : '',
    at: new Date().toISOString(),
    url: location.pathname
  });
  saveErrors(errors);
  if(onChange) onChange();
}
export function installErrorCapture(){
  if(window.__wjbV121ErrorCapture) return;
  window.__wjbV121ErrorCapture = true;
  window.addEventListener('error', (event)=>logError('window.error', event.message, event.filename + ':' + event.lineno + ':' + event.colno));
  window.addEventListener('unhandledrejection', (event)=>logError('promise', event.reason && (event.reason.stack || event.reason.message || event.reason)));
}
