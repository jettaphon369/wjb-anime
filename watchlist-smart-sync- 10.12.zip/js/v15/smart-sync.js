/* ==========================================================================
   WJB v15.0 — Smart Sync (Local-first + Batched Firebase Sync + CRDT-lite)
   --------------------------------------------------------------------------
   ปัญหาเดิม: ทุกครั้งที่ผู้ใช้กด เพิ่ม/แก้ไข/ลบ/ปุ่มโปรด/สาธารณะ ฯลฯ โค้ดจะยิง
   addDoc/updateDoc/deleteDoc ไปที่ Firestore ทันที "ทุกคลิก" รวมถึง logActivity
   ที่ถูกเรียกแทบทุก action ด้วย -> ยิ่งผู้ใช้เยอะ/คลิกถี่ ยิ่งเปลืองเขียน Firestore

   วิธีแก้ในไฟล์นี้:
   1) ทุก action เขียนผล "ทันที" ลง localStorage ก่อน (local-first) แล้ว render UI
      ทันทีโดยไม่ต้องรอเน็ต/Firestore เลย
   2) แทนที่จะยิง Firestore ทันที เราจะ "จดคิว" การเปลี่ยนแปลงไว้ (queue) แล้วค่อย
      ส่งเป็น batch (writeBatch เดียว) ทุก ~5-10 วินาที หรือตอน idle/กลับมาออนไลน์
   3) การแก้ไข doc เดียวกันซ้ำ ๆ ในช่วงเวลาสั้น ๆ จะถูกยุบรวมเป็นการเขียนครั้งเดียว
      (เก็บเฉพาะสถานะล่าสุด) ก่อนส่งขึ้น Firestore จริง ๆ
   4) ถ้า sync ล้มเหลว (ออฟไลน์/error) จะ retry แบบ exponential backoff และคิวจะยัง
      อยู่ใน localStorage เสมอ ไม่มีข้อมูลหาย แม้ปิดแท็บ/รีเฟรชหน้า
   5) CRDT-lite: ทุก item มี id + updatedAtMs (epoch ms) ใช้ตัดสิน conflict แบบ
      last-write-wins เวลาต้อง merge ข้อมูล local กับข้อมูลจาก Firestore (เช่น
      แก้จากหลายเครื่อง/หลายแท็บ)
   ========================================================================== */

const QUEUE_KEY = "wjb_smart_sync_queue_v1";
const DEAD_LETTER_KEY = "wjb_smart_sync_dead_letter_v1";
const ITEMS_CACHE_PREFIX = "wjb_local_items_v1_"; // + uid
const MIN_FLUSH_DELAY_MS = 6000;   // อยู่ในช่วง 5-10 วิ ตามสเปค
const MAX_QUEUE_AGE_MS = 10000;    // ถ้าคิวรอนานเกินนี้ ให้ flush ทันทีไม่ต้องรอ debounce ใหม่
const BASE_RETRY_MS = 5000;
const MAX_RETRY_MS = 60000;
const MAX_OPS_PER_BATCH = 400;     // Firestore batch limit คือ 500 กันชนขอบไว้หน่อย
const MAX_ATTEMPTS_BEFORE_ISOLATION = 5; // ถ้า op ไหน fail ติดกันเกินนี้ (รวมอยู่ใน batch ที่ fail)
                                          // จะแยกไปลองทีละตัว กันไม่ให้ตัวเดียวบล็อกทั้งคิวตลอดไป

let fs = null;            // { db, doc, collection, writeBatch } ที่ initSmartSync ใส่เข้ามา
let queue = [];           // [{ opKey, collection, docId, type, data, queuedAt, attempts }]
let flushTimer = null;
let retryDelay = BASE_RETRY_MS;
let isFlushing = false;
let statusListeners = []; // รองรับหลาย subscriber (เดิมมีแค่ badge ตัวเดียว ตอนนี้เพิ่ม sync-dashboard เข้ามาอีก)

// v15.1: BroadcastChannel ให้แท็บอื่น ๆ ของแอปเดียวกันรู้ทันทีว่ามี op ใหม่เข้าคิว หรือ
// flush เสร็จแล้ว แทนที่จะรอให้แท็บนั้นทำ action เองแล้วค่อย reconcileWithDisk() เฉย ๆ
// ลดหน้าต่างเวลาที่สองแท็บจะเขียน localStorage ทับกันได้อีกชั้นหนึ่ง (ยังไม่ใช่ lock แบบ
// atomic เต็มรูปแบบ แต่ในทางปฏิบัติปิดช่องโหว่ส่วนใหญ่ที่เจอได้บ่อยที่สุด)
let bc = null;
try {
  if (typeof BroadcastChannel !== "undefined") {
    bc = new BroadcastChannel("wjb_smart_sync_v1");
    bc.onmessage = (ev) => {
      if (ev && ev.data === "queue-changed") {
        reconcileWithDisk();
        emitStatus();
      }
    };
  }
} catch (_e) {
  bc = null; // เบราว์เซอร์เก่า/ไม่รองรับ - ระบบยังทำงานได้ปกติ แค่ไม่มีอัปเดตข้ามแท็บแบบทันที
}

function notifyOtherTabs() {
  if (bc) {
    try { bc.postMessage("queue-changed"); } catch (_e) {}
  }
}

const STORAGE_WARN_COOLDOWN_MS = 15000;
let lastStorageWarnAt = 0;

function warnStorageFail() {
  const now = Date.now();
  if (now - lastStorageWarnAt < STORAGE_WARN_COOLDOWN_MS) return;
  lastStorageWarnAt = now;
  if (typeof window !== "undefined" && typeof window.wjbToast === "function") {
    window.wjbToast("พื้นที่จัดเก็บข้อมูลในเครื่องเต็มหรือถูกบล็อก การซิงก์อาจไม่สมบูรณ์ ลองล้างแคชหรือลบรายการเก่าดูนะครับ", "error");
  }
}

function safeGetJSON(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch (_e) {
    return fallback;
  }
}

function safeSetJSON(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (_e) {
    warnStorageFail(); // เต็ม/ถูกบล็อก (Safari private mode ฯลฯ) - แจ้งผู้ใช้แทนที่จะเงียบไว้
    return false;
  }
}

function loadQueueFromDisk() {
  queue = safeGetJSON(QUEUE_KEY, []);
  if (!Array.isArray(queue)) queue = [];
}

/**
 * ลดโอกาสชนกันระหว่างหลายแท็บ: ก่อนจะเขียนคิวทับ ให้อ่านของบนดิสก์ล่าสุดมา "รวม" กับ
 * ของในหน่วยความจำก่อนเสมอ (read-merge-write) แทนที่จะเขียนทับตรง ๆ จากสำเนาที่อาจเก่าไปแล้ว
 * - ถ้ามี op ที่แท็บอื่นเพิ่งเพิ่มแต่แท็บนี้ไม่มีในหน่วยความจำ -> รับมาด้วย
 * - ถ้า doc เดียวกันถูกแท็บอื่นสั่งลบทีหลังเรา (queuedAt ใหม่กว่า) -> ให้ลบชนะ
 * หมายเหตุ: นี่คือการลดความเสี่ยง ไม่ใช่ lock จริง ๆ (เบราว์เซอร์ไม่มี lock ข้ามแท็บแบบ
 * atomic ให้ localStorage) กรณีเปิดหลายแท็บพร้อมกันเป๊ะ ๆ ยังมีโอกาสชนกันอยู่บ้าง
 */
function reconcileWithDisk() {
  const onDisk = safeGetJSON(QUEUE_KEY, []);
  if (!Array.isArray(onDisk)) return;
  const mine = new Map(queue.map((o) => [o.opKey, o]));
  onDisk.forEach((diskOp) => {
    const existing = mine.get(diskOp.opKey);
    if (!existing) {
      queue.push(diskOp);
      mine.set(diskOp.opKey, diskOp);
    } else if ((diskOp.queuedAt || 0) > (existing.queuedAt || 0) && diskOp.type === "delete" && existing.type !== "delete") {
      existing.type = "delete";
      existing.data = null;
    }
  });
}

function persistQueue() {
  safeSetJSON(QUEUE_KEY, queue);
  notifyOtherTabs();
  emitStatus();
}

function emitStatus() {
  const s = getSyncStatus();
  statusListeners.forEach((cb) => {
    try { cb(s); } catch (_e) {}
  });
}

/**
 * เริ่มระบบ smart sync ให้พร้อมทำงาน ต้องเรียกครั้งเดียวหลังจากมี Firestore
 * instance แล้ว (db) พร้อม fn ที่ import มาจาก firebase/firestore
 */
export function initSmartSync({ db, doc, collection, writeBatch }) {
  fs = { db, doc, collection, writeBatch };
  loadQueueFromDisk();

  // ถ้ามีคิวค้างจากรอบก่อน (เช่น ปิดแท็บตอนออฟไลน์) ให้ลองส่งใหม่ตอนบูต
  if (queue.length) scheduleFlush();

  window.addEventListener("online", () => {
    retryDelay = BASE_RETRY_MS;
    flush();
  });

  // best-effort: พยายามส่งคิวก่อนออกจากหน้า/สลับแท็บ (ไม่การันตีสำเร็จ แต่คิวไม่หาย
  // เพราะ persist ไว้ใน localStorage ตลอดอยู่แล้ว)
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden" && queue.length) flush();
  });
  window.addEventListener("beforeunload", () => {
    if (queue.length) flush();
  });

  return true;
}

export function onSyncStatusChange(cb) {
  statusListeners.push(cb);
  return () => { statusListeners = statusListeners.filter((l) => l !== cb); };
}

export function getSyncStatus() {
  return {
    pendingOps: queue.length,
    isOnline: typeof navigator !== "undefined" ? navigator.onLine : true,
    isFlushing,
    hasError: queue.some((o) => (o.attempts || 0) > 0),
    deadLetterCount: safeGetJSON(DEAD_LETTER_KEY, []).length,
  };
}

function opKeyOf(collectionName, docId) {
  return collectionName + "/" + docId;
}

/**
 * Firestore ปฏิเสธการเขียนทันทีถ้ามี field ไหนเป็น `undefined` (throw ตั้งแต่ฝั่ง client
 * เลย ไม่ใช่ error ชั่วคราวที่ retry แล้วหาย) ถ้าโค้ดฝั่งแอปเผลอส่ง undefined มาโดยไม่ได้
 * ตั้งใจ (เช่น field ที่ยังไม่ได้กรอก) จะกลายเป็น op ที่ fail ทุกครั้งไม่มีทางสำเร็จ ต้อง
 * กรองออกตั้งแต่ตอนเข้าคิวเลย เพื่อไม่ให้กลายเป็น poison pill
 */
function sanitizeForFirestore(data) {
  if (data === null || typeof data !== "object") return data;
  if (Array.isArray(data)) return data.map(sanitizeForFirestore);
  const out = {};
  for (const k of Object.keys(data)) {
    const v = data[k];
    if (v === undefined) continue; // ตัดทิ้ง ไม่ใช่แปลงเป็น null (ชัดเจนกว่า เผื่อ field มีความหมายต่างกัน)
    out[k] = (v && typeof v === "object" && typeof v.toMillis !== "function") ? sanitizeForFirestore(v) : v;
  }
  return out;
}

/**
 * ใส่ action ลงคิว (dedupe ต่อ doc: ถ้ามีของเดิมค้างอยู่ ให้ยุบรวมเป็นรายการเดียว
 * เก็บเฉพาะสถานะล่าสุด แทนที่จะส่งซ้ำหลายครั้ง)
 */
function enqueue(type, collectionName, docId, data) {
  reconcileWithDisk(); // ดูดของแท็บอื่นก่อน กันเขียนทับ
  const key = opKeyOf(collectionName, docId);
  const now = Date.now();
  const existingIdx = queue.findIndex((o) => o.opKey === key);
  const cleanData = data ? sanitizeForFirestore(data) : data;

  if (type === "delete") {
    // ลบ = คำสั่งสุดท้ายชนะเสมอ ไม่ต้องสนใจ set/update ที่ค้างอยู่ก่อนหน้า
    const op = { opKey: key, collection: collectionName, docId, type: "delete", data: null, queuedAt: now, attempts: 0 };
    if (existingIdx > -1) queue[existingIdx] = op;
    else queue.push(op);
  } else {
    if (existingIdx > -1 && queue[existingIdx].type !== "delete") {
      queue[existingIdx].data = { ...queue[existingIdx].data, ...cleanData };
      queue[existingIdx].queuedAt = queue[existingIdx].queuedAt || now;
      // type คงเดิม (ถ้าเคยเป็น set ก็ยังเป็น set/merge ต่อ)
    } else {
      queue.push({ opKey: key, collection: collectionName, docId, type, data: cleanData, queuedAt: now, attempts: 0 });
    }
  }

  persistQueue();
  scheduleFlush();
}

export function queueSet(collectionName, docId, data) {
  enqueue("set", collectionName, docId, data);
}

export function queueUpdate(collectionName, docId, data) {
  enqueue("update", collectionName, docId, data);
}

export function queueDelete(collectionName, docId) {
  enqueue("delete", collectionName, docId);
}

/** สร้าง doc id ใหม่แบบ client-side (ไม่ต้องรอเน็ต) เพื่อให้สร้างรายการตอนออฟไลน์ได้ */
export function newDocId(collectionName) {
  return fs.doc(fs.collection(fs.db, collectionName)).id;
}

export function scheduleFlush() {
  if (flushTimer) return; // มีนัดไว้แล้ว ไม่ต้องซ้อน
  const oldestAge = queue.length ? Date.now() - Math.min(...queue.map((o) => o.queuedAt)) : 0;
  const delay = oldestAge >= MAX_QUEUE_AGE_MS ? 0 : MIN_FLUSH_DELAY_MS;
  flushTimer = setTimeout(() => {
    flushTimer = null;
    flush();
  }, delay);
}

/** ยิง batch commit จริง คืน true ถ้าส่งสำเร็จ (หรือไม่มีอะไรต้องส่ง) */
export async function flush() {
  if (isFlushing) return false;
  if (!queue.length) return true;
  if (!fs) return false;
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    scheduleRetry();
    return false;
  }

  isFlushing = true;
  emitStatus();
  const batchOps = queue.slice(0, MAX_OPS_PER_BATCH);

  try {
    await commitOps(batchOps);

    reconcileWithDisk(); // เผื่อแท็บอื่นเพิ่ม op ใหม่เข้ามาระหว่าง commit กำลังทำงาน อย่าทำหาย
    const doneKeys = new Set(batchOps.map((o) => o.opKey));
    queue = queue.filter((o) => !doneKeys.has(o.opKey));
    persistQueue();
    retryDelay = BASE_RETRY_MS;
    isFlushing = false;
    emitStatus();
    if (queue.length) scheduleFlush();
    return true;
  } catch (e) {
    batchOps.forEach((o) => { o.attempts = (o.attempts || 0) + 1; });

    // v15.2: กัน "poison pill" — writeBatch เป็น all-or-nothing ถ้า op ไหนพังถาวร (เช่น
    // โดน security rule ปฏิเสธ, หรือเอกสารเกิน 1MB) มันจะทำให้ batch ทั้งก้อน fail รวมถึง
    // op อื่น ๆ ที่ปกติดีไปด้วย ซ้ำ ๆ ไม่จบไม่สิ้น พอ op ไหนล้มเหลวเกิน MAX_ATTEMPTS_BEFORE_ISOLATION
    // ครั้ง (นับรวมตอนอยู่ใน batch ร่วมกับตัวอื่น) ให้แยกออกมาลองทีละตัว เพื่อหาตัวที่พังจริง
    // แล้วย้ายไป dead-letter โดยไม่ดึงตัวอื่นที่ดีอยู่ให้ค้างไปด้วย
    const stuck = batchOps.filter((o) => o.attempts >= MAX_ATTEMPTS_BEFORE_ISOLATION);
    if (stuck.length) {
      await isolateStuckOps(stuck);
    }

    persistQueue();
    isFlushing = false;
    emitStatus();
    scheduleRetry();
    if (typeof window !== "undefined" && typeof window.wjbToast === "function" && batchOps.some((o) => o.attempts >= 3 && o.attempts < MAX_ATTEMPTS_BEFORE_ISOLATION)) {
      window.wjbToast("ซิงก์ข้อมูลขึ้นคลาวด์ยังไม่สำเร็จ ระบบจะลองใหม่อัตโนมัติ (ข้อมูลปลอดภัยอยู่ในเครื่อง)", "error");
    }
    return false;
  }
}

async function commitOps(ops) {
  const batch = fs.writeBatch(fs.db);
  for (const op of ops) {
    const ref = fs.doc(fs.db, op.collection, op.docId);
    if (op.type === "delete") batch.delete(ref);
    else batch.set(ref, op.data, { merge: true }); // set+merge ครอบทั้ง create และ partial update ปลอดภัยกว่า update() ตรง ๆ (ไม่ error ถ้า doc ยังไม่มี)
  }
  await batch.commit();
}

/**
 * ลองส่ง op ที่ค้างมานานทีละตัว (แยกจากกันคนละ batch) เพื่อไม่ให้ตัวที่พังถาวรบล็อกตัวอื่น
 * - ตัวที่ยังพอ commit ได้เดี่ยว ๆ -> สำเร็จ ลบออกจากคิวปกติ (แปลว่าปัญหาจริง ๆ คือตัวอื่นในกลุ่ม)
 * - ตัวที่ยัง fail อยู่ดีแม้ลองเดี่ยว ๆ -> ย้ายไป dead-letter (เก็บไว้ให้ตรวจสอบ/ลองใหม่ทีหลังได้
 *   แต่ไม่ปล่อยให้บล็อกคิวหลักอีกต่อไป) แล้วแจ้งเตือนผู้ใช้
 */
async function isolateStuckOps(ops) {
  for (const op of ops) {
    try {
      await commitOps([op]);
      queue = queue.filter((o) => o.opKey !== op.opKey);
    } catch (e) {
      moveToDeadLetter(op, e);
      queue = queue.filter((o) => o.opKey !== op.opKey);
    }
  }
}

function moveToDeadLetter(op, err) {
  const dead = safeGetJSON(DEAD_LETTER_KEY, []);
  dead.push({
    ...op,
    failedAt: Date.now(),
    errorMessage: (err && err.message) ? String(err.message) : String(err || "unknown error"),
  });
  safeSetJSON(DEAD_LETTER_KEY, dead);
  if (typeof window !== "undefined" && typeof window.wjbToast === "function") {
    window.wjbToast(`ซิงก์รายการหนึ่งขึ้นคลาวด์ไม่สำเร็จหลังลองหลายครั้ง (ข้อมูลยังอยู่ในเครื่องปกติ) ลองแก้ไข/บันทึกรายการนั้นใหม่อีกครั้งภายหลัง`, "error");
  }
}

/** รายการที่ sync ล้มเหลวถาวรและถูกย้ายออกจากคิวหลักแล้ว (ไว้โชว์ใน UI/debug ภายหลังได้) */
export function getDeadLetterOps() {
  return safeGetJSON(DEAD_LETTER_KEY, []);
}

/** เอา op ออกจาก dead-letter หลังจากผู้ใช้แก้ไข/บันทึกรายการนั้นใหม่แล้ว (ป้องกันรายการค้างโชว์ซ้ำ) */
export function clearDeadLetterOp(opKey) {
  const dead = safeGetJSON(DEAD_LETTER_KEY, []).filter((o) => o.opKey !== opKey);
  safeSetJSON(DEAD_LETTER_KEY, dead);
}

function scheduleRetry() {
  if (flushTimer) return;
  flushTimer = setTimeout(() => {
    flushTimer = null;
    flush();
  }, retryDelay);
  retryDelay = Math.min(retryDelay * 2, MAX_RETRY_MS);
}

export function getPendingCount() {
  return queue.length;
}

/** เช็คว่ารายการนี้ (collection+docId) ยังอยู่ในคิวรอซิงก์อยู่หรือเปล่า */
export function isPending(collectionName, docId) {
  const key = opKeyOf(collectionName, docId);
  return queue.some((o) => o.opKey === key);
}

/** เช็คว่ารายการนี้ถูกย้ายไป dead-letter (ซิงก์ไม่สำเร็จถาวร) แล้วหรือยัง */
export function isDeadLettered(collectionName, docId) {
  const key = opKeyOf(collectionName, docId);
  return safeGetJSON(DEAD_LETTER_KEY, []).some((o) => o.opKey === key);
}

/**
 * ใช้สำหรับ automated test เท่านั้น (เคลียร์คิวในหน่วยความจำ + ยกเลิก timer ที่นัดไว้)
 * แอปจริงไม่ควรเรียกฟังก์ชันนี้ — มีไว้ให้ test แต่ละเคสเริ่มจากสถานะสะอาดเท่านั้น
 */
export function __resetForTests() {
  queue = [];
  if (flushTimer) { clearTimeout(flushTimer); flushTimer = null; }
  retryDelay = BASE_RETRY_MS;
  isFlushing = false;
  statusListeners = [];
  safeSetJSON(DEAD_LETTER_KEY, []);
}

/* ---------------------------- Local item cache --------------------------- */

export function getLocalItems(uid) {
  if (!uid) return [];
  const arr = safeGetJSON(ITEMS_CACHE_PREFIX + uid, []);
  return Array.isArray(arr) ? arr : [];
}

export function setLocalItems(uid, items) {
  if (!uid) return;
  safeSetJSON(ITEMS_CACHE_PREFIX + uid, items);
}

function msOf(item) {
  if (!item) return 0;
  if (typeof item.updatedAtMs === "number") return item.updatedAtMs;
  if (item.updatedAt && typeof item.updatedAt.toMillis === "function") return item.updatedAt.toMillis();
  return item.createdMs || 0;
}

/**
 * CRDT-lite merge (last-write-wins ตาม updatedAtMs):
 * - local: แคชในเครื่อง (อาจมีรายการที่ยังไม่ sync ขึ้นคลาวด์ หรือถูกลบแบบ tombstone
 *   ระหว่างรอส่งคิว)
 * - remote: ผลล่าสุดจาก Firestore
 * คืนค่า array ที่ merge แล้ว (รวม tombstone ที่ยังรอ flush เพื่อไม่ให้ remote ดึง
 * ข้อมูลเก่ากลับมาโผล่ซ้ำระหว่างรอลบ)
 */
export function mergeItems(local, remote) {
  const pendingDeleteIds = new Set(
    queue.filter((o) => o.type === "delete").map((o) => o.docId)
  );
  const localById = new Map((local || []).map((i) => [i.id, i]));
  const remoteById = new Map((remote || []).map((i) => [i.id, i]));
  const allIds = new Set([...localById.keys(), ...remoteById.keys()]);
  const merged = [];

  allIds.forEach((id) => {
    if (pendingDeleteIds.has(id)) return; // ลบค้างคิวอยู่ ไม่เอากลับมาแสดง
    const l = localById.get(id);
    const r = remoteById.get(id);
    if (l && !r) { merged.push(l); return; }        // เพิ่มใหม่ตอนออฟไลน์ ยังไม่ขึ้นคลาวด์
    if (r && !l) { merged.push(r); return; }        // มาจากเครื่อง/อุปกรณ์อื่น
    if (l && r) { merged.push(msOf(l) > msOf(r) ? l : r); return; } // ใหม่กว่าชนะ
  });

  return merged;
}
