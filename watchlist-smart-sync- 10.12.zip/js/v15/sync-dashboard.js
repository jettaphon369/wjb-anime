/* ==========================================================================
   WJB v15.4 — Sync Dashboard
   --------------------------------------------------------------------------
   แผงตรวจสอบ: "ตั้งแต่ล็อกอินเข้ามา แก้ไขไปกี่ครั้ง แต่ละอันซิงก์ขึ้นคลาวด์แล้วหรือยัง"
   กันความรู้สึก "ไม่รู้ว่าข้อมูลหายไปหรือเปล่า" — เก็บ log การแก้ไขไว้ใน memory (reset
   ทุกครั้งที่ล็อกอินใหม่) แล้วเช็คสถานะจริงจากคิวของ smart-sync.js แบบ real-time
   ========================================================================== */

import * as WJBSync from "./smart-sync.js";

let sessionLog = []; // [{ collection, itemId, itemTitle, action, ts }] เรียงใหม่สุดก่อน

const ACTION_LABELS = {
  add_item: "เพิ่มรายการ",
  update_item: "แก้ไขรายการ",
  delete_item: "ลบรายการ",
  toggle_favorite: "กดรายการโปรด",
  toggle_group_privacy: "เปลี่ยนสถานะสาธารณะ/ส่วนตัว",
  copy_public_item: "คัดลอกจากลิสต์คนอื่น",
};

/** เรียกตอนล็อกอินใหม่ทุกครั้ง เพื่อให้นับ "ตั้งแต่ล็อกอิน" ถูกต้อง ไม่ปนของรอบก่อน */
export function resetSessionLog() {
  sessionLog = [];
  updateModalIfOpen();
}

/** เรียกทุกครั้งที่มี action เกิดขึ้นกับ item เฉพาะตัว (ข้าม action ที่ไม่ผูกกับ item เช่น login) */
export function recordEdit({ collection = "watchItems", itemId, itemTitle, action }) {
  if (!itemId) return;
  sessionLog.unshift({ collection, itemId, itemTitle: itemTitle || "(ไม่ทราบชื่อรายการ)", action, ts: Date.now() });
  updateModalIfOpen();
}

export function getSessionLog() {
  return sessionLog;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function statusOf(entry) {
  if (WJBSync.isDeadLettered(entry.collection, entry.itemId)) return { text: "❌ ซิงก์ไม่สำเร็จ", cls: "wjb-sd-fail" };
  if (WJBSync.isPending(entry.collection, entry.itemId)) return { text: "⏳ รอซิงก์", cls: "wjb-sd-pending" };
  return { text: "✅ ซิงก์แล้ว", cls: "wjb-sd-done" };
}

function renderBody() {
  const total = sessionLog.length;
  let pendingCount = 0, failedCount = 0;
  const rows = sessionLog.map((e) => {
    const s = statusOf(e);
    if (s.cls === "wjb-sd-pending") pendingCount++;
    if (s.cls === "wjb-sd-fail") failedCount++;
    const time = new Date(e.ts).toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    return `<div class="wjb-sd-row">
      <div class="wjb-sd-row-main">
        <div class="wjb-sd-row-title">${escapeHtml(e.itemTitle)}</div>
        <div class="wjb-sd-row-sub">${ACTION_LABELS[e.action] || e.action} • ${time}</div>
      </div>
      <div class="wjb-sd-row-status ${s.cls}">${s.text}</div>
    </div>`;
  }).join("") || `<div class="wjb-sd-empty">ยังไม่มีการแก้ไขตั้งแต่ล็อกอินเข้ามาครับ</div>`;

  const syncedCount = total - pendingCount - failedCount;

  return `
    <div class="wjb-sd-summary">
      <div class="wjb-sd-summary-total">แก้ไขทั้งหมด <b>${total}</b> ครั้ง ตั้งแต่ล็อกอิน</div>
      <div class="wjb-sd-summary-tags">
        <span class="wjb-sd-tag wjb-sd-done">✅ ซิงก์แล้ว ${syncedCount}</span>
        <span class="wjb-sd-tag wjb-sd-pending">⏳ รอซิงก์ ${pendingCount}</span>
        <span class="wjb-sd-tag wjb-sd-fail">❌ ไม่สำเร็จ ${failedCount}</span>
      </div>
      ${failedCount > 0 ? `<div class="wjb-sd-warning">⚠️ มีรายการซิงก์ไม่สำเร็จ ${failedCount} รายการ — ลองเปิดรายการนั้นแล้วบันทึกซ้ำอีกครั้ง ไม่งั้นจะไม่ขึ้นคลาวด์</div>` : ""}
    </div>
    <div class="wjb-sd-list">${rows}</div>
  `;
}

let modalEl = null;
let unsubscribe = null;

function updateModalIfOpen() {
  if (modalEl && modalEl.style.display !== "none") {
    const body = modalEl.querySelector(".wjb-sd-body");
    if (body) body.innerHTML = renderBody();
  }
}

function buildModal() {
  modalEl = document.createElement("div");
  modalEl.className = "wjb-sd-overlay";
  modalEl.innerHTML = `
    <div class="wjb-sd-modal">
      <div class="wjb-sd-header">
        <span>📋 ตรวจสอบการแก้ไข</span>
        <button type="button" class="wjb-sd-close" aria-label="ปิด">✕</button>
      </div>
      <div class="wjb-sd-body"></div>
    </div>`;
  modalEl.querySelector(".wjb-sd-close").addEventListener("click", closeDashboard);
  modalEl.addEventListener("click", (e) => { if (e.target === modalEl) closeDashboard(); });
  document.body.appendChild(modalEl);

  // อัปเดตแบบ real-time ตอนสถานะ sync เปลี่ยน (ระหว่างที่เปิด modal ค้างไว้)
  unsubscribe = WJBSync.onSyncStatusChange(() => updateModalIfOpen());
}

export function openDashboard() {
  if (!modalEl) buildModal();
  modalEl.style.display = "flex";
  updateModalIfOpen();
}

export function closeDashboard() {
  if (modalEl) modalEl.style.display = "none";
}

window.wjbOpenSyncDashboard = openDashboard;
window.wjbCloseSyncDashboard = closeDashboard;
