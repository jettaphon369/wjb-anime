// WJB v13.6 Favorite UX helper - isolated, no data schema changes
(function(){
  function ensureToast(){
    let el=document.getElementById('wjbFavoriteToast');
    if(!el){
      el=document.createElement('div');
      el.id='wjbFavoriteToast';
      el.className='wjb-favorite-toast';
      document.body.appendChild(el);
    }
    return el;
  }
  window.wjbFavoriteToast=function(message){
    const el=ensureToast();
    el.textContent=message || 'อัปเดตรายการโปรดแล้ว';
    el.classList.add('show');
    clearTimeout(window.__wjbFavToastTimer);
    window.__wjbFavToastTimer=setTimeout(()=>el.classList.remove('show'),2200);
  };
})();
