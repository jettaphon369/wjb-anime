/* WJB v13.10 Long-Press Bulk Select
   Scope: "my list" group cards only. Lets the user long-press a card to
   jump straight into bulk-delete mode (or toggle that card's selection if
   bulk-delete mode is already active) without touching the checkbox by hand.
   No Firebase/data/API/Admin/Search/Hall logic changes.
*/
(function(){
  'use strict';

  const VERSION = 'premium-ui-v13-10-long-press-bulk-select';
  window.WJB_LONG_PRESS_BULK_SELECT_VERSION = VERSION;

  const PRESS_MS = 550;
  const MOVE_CANCEL_PX = 10;

  let pressTimer = null;
  let pressCard = null;
  let startX = 0;
  let startY = 0;
  let longPressFired = false;

  function getList(){
    return document.getElementById('list');
  }

  function isInteractiveTarget(target){
    return !!target.closest('button, a, input, label, .actions, .wjb-group-actions, .bulk-select-card');
  }

  function clearPressState(){
    if(pressTimer){ clearTimeout(pressTimer); pressTimer = null; }
    if(pressCard){ pressCard.classList.remove('long-press-active'); }
    pressCard = null;
  }

  function vibrate(ms){
    try{ if(navigator.vibrate) navigator.vibrate(ms); }catch(_e){}
  }

  function isAlreadyInBulkMode(card){
    return !!card.querySelector('.bulk-select-card input[type="checkbox"]');
  }

  function selectWholeGroup(card){
    const checkbox = card.querySelector('.bulk-select-card input[type="checkbox"]');
    if(!checkbox) return;
    const nextChecked = !checkbox.checked;
    checkbox.checked = nextChecked;
    checkbox.dispatchEvent(new Event('change', { bubbles:true }));
    card.classList.toggle('bulk-selected-card', nextChecked);
  }

  function enterBulkModeAndSelect(idsAttr){
    if(typeof window.toggleBulkDeleteMode !== 'function') return;
    window.toggleBulkDeleteMode(); // re-renders the list synchronously

    const list = getList();
    if(!list) return;
    const freshCard = list.querySelector(`[data-bulk-ids="${CSS.escape(idsAttr)}"]`);
    if(!freshCard) return;

    const checkbox = freshCard.querySelector('.bulk-select-card input[type="checkbox"]');
    if(!checkbox) return;
    checkbox.checked = true;
    checkbox.dispatchEvent(new Event('change', { bubbles:true }));
    freshCard.classList.add('bulk-selected-card');
  }

  function handlePressStart(target, x, y){
    const card = target.closest ? target.closest('.card.group-card') : null;
    if(!card || isInteractiveTarget(target)) return;
    if(!card.dataset.bulkIds) return;

    clearPressState();
    pressCard = card;
    startX = x;
    startY = y;
    longPressFired = false;

    card.classList.add('long-press-active');
    pressTimer = setTimeout(()=>{
      longPressFired = true;
      vibrate(30);
      const idsAttr = card.dataset.bulkIds;
      if(isAlreadyInBulkMode(card)){
        selectWholeGroup(card);
        card.classList.remove('long-press-active');
      }else{
        card.classList.remove('long-press-active');
        enterBulkModeAndSelect(idsAttr);
      }
      pressCard = null;
      pressTimer = null;
    }, PRESS_MS);
  }

  function handlePressMove(x, y){
    if(!pressCard) return;
    if(Math.abs(x - startX) > MOVE_CANCEL_PX || Math.abs(y - startY) > MOVE_CANCEL_PX){
      clearPressState();
    }
  }

  function handlePressEnd(){
    clearPressState();
  }

  function bind(){
    const list = getList();
    if(!list || list.__wjbLongPressBound) return;
    list.__wjbLongPressBound = true;

    list.addEventListener('pointerdown', (e)=>{
      if(e.pointerType === 'mouse' && e.button !== 0) return;
      handlePressStart(e.target, e.clientX, e.clientY);
    }, { passive:true });

    list.addEventListener('pointermove', (e)=>{
      handlePressMove(e.clientX, e.clientY);
    }, { passive:true });

    list.addEventListener('pointerup', handlePressEnd, { passive:true });
    list.addEventListener('pointercancel', handlePressEnd, { passive:true });
    list.addEventListener('pointerleave', (e)=>{
      if(e.target === pressCard || (pressCard && pressCard.contains(e.target))) clearPressState();
    }, { passive:true });

    // Suppress the ghost click that some browsers fire right after a long
    // press so it doesn't accidentally trigger a button under the finger.
    list.addEventListener('click', (e)=>{
      if(longPressFired){
        longPressFired = false;
        e.preventDefault();
        e.stopPropagation();
      }
    }, true);
  }

  function patch(){
    bind();
    // #list's innerHTML is replaced on every render, but the element itself
    // persists, so a single delegated listener set survives re-renders.
    // Re-check periodically in case the container is ever recreated.
    setTimeout(bind, 400);
    setTimeout(bind, 1200);
  }

  document.addEventListener('DOMContentLoaded', ()=>setTimeout(patch, 120));
  window.addEventListener('load', ()=>setTimeout(patch, 220));
  setTimeout(patch, 320);
})();
