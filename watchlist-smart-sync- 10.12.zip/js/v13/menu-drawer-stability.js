/* WJB v13.7 Menu Drawer Stability Fix
   Scope: drawer/menu navigation only. No Firebase/data/API changes.
*/
(function(){
  'use strict';

  const VERSION = 'premium-ui-v13-7-menu-drawer-stability-fix';
  window.WJB_MENU_DRAWER_FIX_VERSION = VERSION;
  let navGuard = false;

  function getDrawer(){
    return document.getElementById('userBox');
  }

  function isDrawerOpen(){
    const drawer = getDrawer();
    return !!(drawer && drawer.classList.contains('open'));
  }

  function closeDrawer(){
    const drawer = getDrawer();
    if(!drawer) return false;
    const wasOpen = drawer.classList.contains('open');
    drawer.classList.remove('open');
    drawer.setAttribute('aria-hidden','true');
    drawer.dataset.wjbClosing = wasOpen ? '1' : '0';
    window.setTimeout(()=>{ try{ delete drawer.dataset.wjbClosing; }catch(_e){} }, 260);
    return wasOpen;
  }

  function clearDrawerTouchState(){
    try{ document.activeElement && document.activeElement.blur && document.activeElement.blur(); }catch(_e){}
    document.body.classList.remove('wjb-menu-open','wjb-drawer-open','menu-open');
  }

  function closeDrawerBeforeAction(action, isSurfaceOpen){
    const wasOpen = closeDrawer();
    clearDrawerTouchState();
    if(isSurfaceOpen){
      try{ window.forceUnlockPageScroll && window.forceUnlockPageScroll(); }catch(_e){}
    }
    const run = () => {
      try{ return action(); }
      finally{
        window.setTimeout(()=>{
          try{ window.wjbUpdateBottomNavVisibility && window.wjbUpdateBottomNavVisibility(); }catch(_e){}
        }, 80);
        if(isSurfaceOpen){
          window.setTimeout(()=>{ try{ window.syncModalState && window.syncModalState(); }catch(_e){} }, 0);
          window.setTimeout(()=>{ try{ window.syncModalState && window.syncModalState(); }catch(_e){} }, 260);
        }
      }
    };
    if(wasOpen){
      return new Promise((resolve, reject)=>window.setTimeout(()=>{
        try{ resolve(run()); }
        catch(error){ reject(error); }
      }, 150));
    }
    return run();
  }

  // Functions that used to be wrapped a second time by modal-stability.js —
  // they open a full-screen "surface" (modal/panel), so they still need the
  // scroll-unlock + modal-state-sync behavior that system used to add.
  const SURFACE_OPEN_FNS = new Set([
    'openTrendingExplorer','openSettings','openGuardianAI',
    'openControlCenter','openSystemHealthDashboard','showPWAInstallHelp'
  ]);

  function wrapNavFunction(name){
    const original = window[name];
    if(typeof original !== 'function' || original.__wjb137DrawerFixed) return;
    const isSurfaceOpen = SURFACE_OPEN_FNS.has(name);
    const wrapped = function(...args){
      if(navGuard) return original.apply(this,args);
      navGuard = true;
      const ctx = this;
      try{
        const result = closeDrawerBeforeAction(()=>original.apply(ctx,args), isSurfaceOpen);
        if(result && typeof result.finally === 'function'){
          return result.finally(()=>{ navGuard = false; });
        }
        navGuard = false;
        return result;
      }catch(error){
        navGuard = false;
        throw error;
      }
    };
    wrapped.__wjb137DrawerFixed = true;
    wrapped.__wjbOriginal = original;
    window[name] = wrapped;
  }

  function patch(){
    [
      'switchTab',
      'wjbNavHome',
      'wjbNavAdd',
      'wjbNavTrending',
      'wjbNavExplore',
      'wjbNavViewToggle',
      'openTrendingExplorer',
      'openSettings',
      'openGuardianAI',
      'openBrotherAI',
      'openControlCenter',
      'openAdminPanel',
      'openSystemHealthDashboard',
      'showPWAInstallHelp',
      'logout'
    ].forEach(wrapNavFunction);
  }

  document.addEventListener('click', (event)=>{
    const drawer = getDrawer();
    if(!drawer || !drawer.classList.contains('open')) return;

    const menuButton = event.target.closest && event.target.closest('.premium-menu-item, .premium-menu-close, .wjb-v60-bottom-nav button, .bottom-nav button, [data-wjb-nav]');
    if(menuButton){
      closeDrawer();
      clearDrawerTouchState();
      return;
    }

    const toggle = event.target.closest && event.target.closest('.menu-toggle');
    if(toggle) return;

    if(!drawer.contains(event.target)){
      closeDrawer();
      clearDrawerTouchState();
    }
  }, true);

  window.wjbCloseMenuDrawer = function(){
    closeDrawer();
    clearDrawerTouchState();
  };

  document.addEventListener('keydown', (event)=>{
    if(event.key === 'Escape' && isDrawerOpen()){
      closeDrawer();
      clearDrawerTouchState();
    }
  });

  document.addEventListener('DOMContentLoaded', ()=>setTimeout(patch, 80));
  window.addEventListener('load', ()=>setTimeout(patch, 160));
  setTimeout(patch, 250);
})();
