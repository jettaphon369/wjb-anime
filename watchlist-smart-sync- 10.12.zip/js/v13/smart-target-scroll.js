/* WJB v13.8 Smart Target Scroll Fix
   Scope: drawer/menu navigation target scrolling only.
   No Firebase/data/API/Admin/Search/Hall logic changes.
*/
(function(){
  'use strict';

  const VERSION = 'premium-ui-v14-2-lts-action-row-fix';
  window.WJB_SMART_TARGET_SCROLL_VERSION = VERSION;

  let navToken = 0;
  let navBusy = false;

  function sleep(ms){ return new Promise(resolve => setTimeout(resolve, ms)); }

  function closeDrawer(){
    try{
      const drawer = document.getElementById('userBox');
      if(drawer){
        drawer.classList.remove('open');
        drawer.setAttribute('aria-hidden','true');
      }
      document.body.classList.remove('wjb-menu-open','wjb-drawer-open','menu-open');
      if(document.activeElement && document.activeElement.blur) document.activeElement.blur();
    }catch(_e){}
  }

  function getTopOffset(){
    // Keep a small breathing space below iOS/Safari top chrome and app card border.
    const width = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0);
    return width <= 560 ? 92 : 72;
  }

  function getScrollRoot(){
    return document.scrollingElement || document.documentElement || document.body;
  }

  function scrollToElement(element, behavior){
    if(!element) return false;
    try{
      const root = getScrollRoot();
      const y = Math.max(0, element.getBoundingClientRect().top + window.pageYOffset - getTopOffset());
      root.scrollTo({ top: y, behavior: behavior || 'smooth' });
      return true;
    }catch(_e){
      try{ element.scrollIntoView({ behavior: behavior || 'smooth', block: 'start' }); return true; }catch(__e){ return false; }
    }
  }

  function findListTarget(preferFirstCard){
    const list = document.getElementById('list');
    if(!list) return null;
    if(preferFirstCard){
      const card = list.querySelector('.group-card, .card, .wjb-premium-card, .search-result-card, article, .empty');
      if(card) return card;
    }
    return list;
  }

  async function waitForListTarget(preferFirstCard, token){
    const delays = [0, 70, 140, 240, 380, 560];
    let last = null;
    for(const delay of delays){
      if(token !== navToken) return null;
      if(delay) await sleep(delay);
      last = findListTarget(preferFirstCard);
      if(last && last.offsetParent !== null) return last;
    }
    return last;
  }

  async function smartScrollToList(options){
    const token = ++navToken;
    const preferFirstCard = !!(options && options.preferFirstCard);
    const target = await waitForListTarget(preferFirstCard, token);
    if(token !== navToken || !target) return;

    // First jump instantly near the correct rendered location, then a tiny smooth correction.
    scrollToElement(target, 'auto');
    await sleep(80);
    if(token === navToken) scrollToElement(target, 'smooth');
  }

  function shouldScrollForTab(tab){
    return tab === 'my' || tab === 'explore';
  }

  function wrapSwitchTab(){
    const original = window.switchTab;
    if(typeof original !== 'function' || original.__wjb138SmartTargetScroll) return;

    const wrapped = async function(tab, ...rest){
      closeDrawer();
      const result = original.apply(this, [tab, ...rest]);
      if(result && typeof result.then === 'function') await result;

      if(shouldScrollForTab(tab)){
        await sleep(170); // wait for drawer close animation + DOM render
        await smartScrollToList({ preferFirstCard: true });
      }
      return result;
    };
    wrapped.__wjb138SmartTargetScroll = true;
    wrapped.__wjbOriginal = original;
    window.switchTab = wrapped;
  }

  function wrapOpenStatView(){
    const original = window.openStatView;
    if(typeof original !== 'function' || original.__wjb138SmartTargetScroll) return;

    const wrapped = function(filter, ...rest){
      closeDrawer();
      const result = original.apply(this, [filter, ...rest]);
      // openStatView renders synchronously; delay only to let Safari finish layout.
      setTimeout(()=>smartScrollToList({ preferFirstCard: true }), 180);
      return result;
    };
    wrapped.__wjb138SmartTargetScroll = true;
    wrapped.__wjbOriginal = original;
    window.openStatView = wrapped;
  }

  function patch(){
    wrapSwitchTab();
    wrapOpenStatView();
  }

  // Safety: explicit helper for future drawer buttons without touching business logic.
  window.wjbSmartScrollToCurrentList = function(){
    return smartScrollToList({ preferFirstCard: true });
  };

  document.addEventListener('DOMContentLoaded', ()=>setTimeout(patch, 120));
  window.addEventListener('load', ()=>setTimeout(patch, 220));
  setTimeout(patch, 320);
})();
