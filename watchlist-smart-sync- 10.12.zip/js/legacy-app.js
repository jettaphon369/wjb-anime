/* ==========================================================================
   WJB legacy-app.js — สารบัญ (เพิ่มเพื่อความเป็นระเบียบเท่านั้น ไม่มีผลต่อการทำงาน)
   ไฟล์นี้สะสมแพตช์มาตั้งแต่เวอร์ชัน v5.x–v14.x บรรทัดอาจขยับได้เมื่อแก้ไขต่อ
   ใช้ Ctrl+F หาข้อความในคอลัมน์ขวาเพื่อกระโดดไปจุดนั้นเร็วขึ้น
   --------------------------------------------------------------------------
   บรรทัด ~28    Firebase config / init (app, auth, db)
   บรรทัด ~69    Admin Settings
   บรรทัด ~87    Control Center v1 (Feature flags, ข้อความหน้าเว็บ)
   บรรทัด ~480   Bottom Navigation (ปุ่มมุมมอง/เมนูล่าง)
   บรรทัด ~764   Admin Panel (openAdminPanel)
   บรรทัด ~1037  Tab switching หลัก (switchTab)
   บรรทัด ~1177  บันทึกรายการ (saveItem)
   บรรทัด ~1554  หน้ารายละเอียดซีซั่น (openSeasonDetail)
   บรรทัด ~3315  Trending Explorer (สำรวจอนิเมะ/หนัง/ซีรีส์ยอดนิยม)
   บรรทัด ~4109  Personal AI v1 + AI Brain v2
   บรรทัด ~4446  Guardian AI v1
   บรรทัด ~4681  Guardian AI v2 (Health Dashboard + Auto Fix) — เวอร์ชันที่ใช้งานจริง
   บรรทัด ~4965  WJB Brain (ผู้ช่วยแบบ offline ไม่เรียก OpenAI)
   บรรทัด ~5174  Free Only v3 (Data Doctor v3, Duplicate Finder, Smart Filter)
   บรรทัด ~5811  Hall of Fame Preview Card (v13.4)
   บรรทัด ~5843  Anime Airing Notify v1 (แจ้งตอนใหม่วันนี้ + ดองไว้กี่ตอน — แจ้งในแอปเท่านั้น)
   บรรทัด ~5950  Airing Board v1 (กระดานออนไลน์ตารางออกอากาศ + กระดานของฉันจดวันฉายเอง)
   ========================================================================== */

import { initializeApp } from "https://www.gstatic.com/firebasejs/12.0.0/firebase-app.js";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  sendPasswordResetEmail
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js";
import {
  getFirestore,
  initializeFirestore,
  persistentLocalCache,
  persistentSingleTabManager,
  collection,
  doc,
  setDoc,
  addDoc,
  getDocs,
  getDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp,
  limit,
  writeBatch
} from "https://www.gstatic.com/firebasejs/12.0.0/firebase-firestore.js";

// v15.0: Smart Sync — เก็บ action ลงคิว + ส่งเป็น batch แทนการยิง Firestore ทุกคลิก
// ดูรายละเอียดที่ ./v15/smart-sync.js
import * as WJBSync from "./v15/smart-sync.js";
// v15.4: แผงตรวจสอบการแก้ไขตั้งแต่ล็อกอิน + สถานะซิงก์รายชิ้น
import * as WJBSyncDashboard from "./v15/sync-dashboard.js";

const firebaseConfig = {
  apiKey: "AIzaSyBqnc_thE_OqINJ55aTP96nwGxcSfpJ45Q",
  authDomain: "wach-jettaphon.firebaseapp.com",
  projectId: "wach-jettaphon",
  storageBucket: "wach-jettaphon.firebasestorage.app",
  messagingSenderId: "174690509237",
  appId: "1:174690509237:web:c763c0c41749dbab0c79fc",
  measurementId: "G-3T0Q4QGLYC"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// v15.0 fix: items (including base64 poster images) used to be re-downloaded from
// the network in full on every load/refresh, with no local cache at all. The more
// titles a user accumulates over time, the bigger that payload gets — which is why
// the app felt more stuck the longer it was used, and refreshing didn't help (it just
// re-ran the same, ever-growing network fetch). Persistent local cache stores data in
// IndexedDB so previously-seen items load instantly and only changes need to sync.
let db;
try{
  db = initializeFirestore(app, {
    localCache: persistentLocalCache({ tabManager: persistentSingleTabManager({}) })
  });
}catch(_e){
  // Falls back to the plain client if persistence isn't available (e.g. private
  // browsing mode, or an already-initialized Firestore instance from a previous
  // hot-reload) — app still works, just without the local cache speed-up.
  db = getFirestore(app);
}

// v15.0: เปิดใช้ Smart Sync (local-first queue + batched writes) ทันทีที่มี db แล้ว
WJBSync.initSmartSync({ db, doc, collection, writeBatch });
// เปิดให้เรียกตรวจสอบจาก DevTools Console ได้สะดวก เช่น WJBSync.getPendingCount()
window.WJBSync = WJBSync;

// v15.3: badge เล็ก ๆ บอกว่ามีกี่รายการรอ sync ขึ้นคลาวด์ + โชว์ข้อความยืนยันสั้น ๆ ตอน
// ซิงก์ครบแล้ว (ไม่ใช่แค่หายไปเฉย ๆ ซึ่งแยกไม่ออกว่า "เพิ่งซิงก์เสร็จ" หรือ "ยังไม่ทำอะไรเลย")
let wjbPrevPendingOps = 0;
let wjbSyncDoneTimer = null;
WJBSync.onSyncStatusChange((status) => {
  const badge = document.getElementById("wjbSyncBadge");
  if (!badge) return;

  const justFinishedSyncing = wjbPrevPendingOps > 0 && status.pendingOps === 0 && status.deadLetterCount === 0;
  wjbPrevPendingOps = status.pendingOps;

  if (!status.pendingOps && !status.deadLetterCount) {
    clearTimeout(wjbSyncDoneTimer);
    if (justFinishedSyncing) {
      badge.style.display = "flex";
      badge.classList.remove("wjb-sync-offline", "wjb-sync-error");
      badge.classList.add("wjb-sync-done");
      badge.innerHTML = `<span class="wjb-sync-dot"></span>✓ ซิงก์ขึ้นคลาวด์ครบแล้ว`;
      wjbSyncDoneTimer = setTimeout(() => {
        badge.style.display = "none";
        badge.classList.remove("wjb-sync-done");
      }, 2200); // โชว์ทิ้งไว้สั้น ๆ ให้เห็นแน่ ๆ ว่าเสร็จแล้ว ก่อนซ่อนตามปกติ
    } else {
      badge.style.display = "none";
    }
    return;
  }

  clearTimeout(wjbSyncDoneTimer);
  badge.classList.remove("wjb-sync-done");
  badge.style.display = "flex";
  badge.classList.toggle("wjb-sync-offline", !status.isOnline);
  badge.classList.toggle("wjb-sync-error", (status.isOnline && status.hasError) || status.deadLetterCount > 0);
  const label = status.deadLetterCount > 0
    ? `ซิงก์ไม่สำเร็จ ${status.deadLetterCount} รายการ — ลองบันทึกใหม่อีกครั้ง`
    : !status.isOnline
      ? `ออฟไลน์ — รอซิงก์ ${status.pendingOps} รายการ`
      : status.hasError
        ? `ซิงก์ไม่สำเร็จ กำลังลองใหม่ (${status.pendingOps} รายการ)`
        : status.isFlushing
          ? `กำลังซิงก์ ${status.pendingOps} รายการ...`
          : `รอซิงก์ ${status.pendingOps} รายการ`;
  badge.innerHTML = `<span class="wjb-sync-dot"></span>${label}`;
});

// ==========================================================================
// WJB Storage Wrapper v1 — ครอบ localStorage ทุกจุดด้วย try/catch กลาง
// กันแอปพังตอน storage เต็ม/ถูกบล็อก (Safari private mode ฯลฯ) และแจ้งเตือนผู้ใช้
// ==========================================================================
const WJB_STORAGE_WARN_COOLDOWN_MS = 15000; // กันแจ้งเตือนถี่เกินไปถ้าเขียนพลาดหลายครั้งติดกัน
let wjbStorageLastWarnAt = 0;

function wjbIsQuotaError(e){
  if(!e) return false;
  return e.name === "QuotaExceededError" ||
         e.name === "NS_ERROR_DOM_QUOTA_REACHED" ||
         e.code === 22 ||
         e.code === 1014;
}

function wjbStorageWarnFull(){
  const now = Date.now();
  if(now - wjbStorageLastWarnAt < WJB_STORAGE_WARN_COOLDOWN_MS) return;
  wjbStorageLastWarnAt = now;
  if(typeof window.wjbToast === "function"){
    window.wjbToast("พื้นที่จัดเก็บข้อมูลในเครื่องเต็ม บางรายการอาจไม่ถูกบันทึก ลองล้างแคชหรือลบรายการเก่าดูนะครับ", "error");
  }
}

// อ่านค่า string ดิบจาก localStorage อย่างปลอดภัย
function wjbStorageGet(key, fallback){
  try{
    const raw = localStorage.getItem(key);
    return raw === null ? (fallback === undefined ? null : fallback) : raw;
  }catch(_e){
    return fallback === undefined ? null : fallback;
  }
}

// อ่านค่า JSON จาก localStorage อย่างปลอดภัย (คืน fallback ถ้าไม่มี/parse ไม่ได้)
function wjbStorageGetJSON(key, fallback){
  try{
    const raw = localStorage.getItem(key);
    if(raw === null) return fallback;
    return JSON.parse(raw);
  }catch(_e){
    return fallback;
  }
}

// เขียนค่า string ลง localStorage อย่างปลอดภัย คืน true/false ว่าสำเร็จไหม
function wjbStorageSet(key, value){
  try{
    localStorage.setItem(key, value);
    return true;
  }catch(e){
    if(wjbIsQuotaError(e)) wjbStorageWarnFull();
    return false;
  }
}

// เขียนค่า JSON ลง localStorage อย่างปลอดภัย
function wjbStorageSetJSON(key, value){
  try{
    return wjbStorageSet(key, JSON.stringify(value));
  }catch(_e){
    return false;
  }
}

function wjbStorageRemove(key){
  try{ localStorage.removeItem(key); return true; }
  catch(_e){ return false; }
}

// จำกัดจำนวน entry ของ object แบบ { key: value } ให้ไม่เกิน maxEntries
// (ตัดตัวที่ถูกเพิ่มเข้ามาก่อนสุดทิ้งก่อน อาศัย insertion order ของ object key ปกติของ JS)
function wjbCapObjectEntries(obj, maxEntries){
  if(!obj || typeof obj !== "object") return obj;
  const keys = Object.keys(obj);
  if(keys.length <= maxEntries) return obj;
  const dropCount = keys.length - maxEntries;
  for(let i = 0; i < dropCount; i++){ delete obj[keys[i]]; }
  return obj;
}

// จำกัดความยาว array ให้ไม่เกิน maxEntries โดยเก็บรายการล่าสุด (ท้ายสุด) ไว้
function wjbCapArrayEntries(arr, maxEntries){
  if(!Array.isArray(arr)) return arr;
  if(arr.length <= maxEntries) return arr;
  return arr.slice(arr.length - maxEntries);
}

let items = [];
let publicItems = [];
let editId = null;
let editReturnTitle = null;
let currentUser = null;
let currentTab = "my";
// v15.0 fix: currentStatFilter used to also exist as a separate local variable
// that some code paths (openStatView) wrote to while others (showFilteredStatItems)
// wrote to window.currentStatFilter instead. renderCurrentTab() only ever read the
// local copy, so it could re-render the wrong stat-filtered page (e.g. right after
// toggling compact/large card view while scrolled into a filtered view) whenever the
// two copies drifted apart. Now there is exactly one source of truth: window.currentStatFilter.
window.currentStatFilter = window.currentStatFilter || "all";
let smartPoster = "";
let smartSearchTimer = null;
let smartSearchSeq = 0;
const smartSearchCache = new Map();
let pendingFocusItemId = null;
let pendingFocusItemTitle = null;

const WJB_FREE_ONLY_MODE = true;
const WJB_PAID_API_LOCK = true;
const WJB_FREE_ONLY_PROJECT_LOCK = true;
const WJB_OPENAI_DISABLED = true;
const WJB_USER_API_KEYS_DISABLED = true;
const TMDB_API_KEY = ""; // FREE ONLY MODE: ไม่ฝัง key ในไฟล์ เพื่อกันความเสี่ยงค่าใช้จ่าย/การใช้งานผิดเงื่อนไข
const WJB_FREE_SEARCH_HUB_VERSION = "v4";
const WJB_FREE_SEARCH_SOURCES = ["WJB Memory", "Jikan", "AniList", "Kitsu", "TVMaze", "iTunes", "Wikipedia/Wikidata"];
function getWJBTmdbFreeKey(){
  // WJB Free 100% Lock: ไม่รับ/ไม่เก็บ API key จากผู้ใช้ และไม่เรียก TMDB เพื่อกันความเสี่ยงค่าใช้จ่ายหรือ quota
  return "";
}

// ===== WJB ADMIN SETTINGS =====
// วิธีตั้งแอดมิน:
// 1) แนะนำ: ไปที่ Firestore > users > {uid} แล้วเพิ่ม field role = "admin"
// 2) หรือใส่อีเมล/UID แอดมินในรายการด้านล่างแล้ว deploy ไฟล์นี้ใหม่
const ADMIN_EMAILS = []; // ตัวอย่าง: ["admin@example.com"]
const ADMIN_UIDS = [];   // ตัวอย่าง: ["firebase-user-uid"]
let isAdmin = false;
let adminItems = [];
let adminUsers = [];
let adminLogs = [];
try{ document.body.classList.add("wjb-user"); }catch(_e){}
let bulkDeleteMode = false;
let bulkDeleteSelectedIds = new Set();
let myListCompactView = wjbStorageGet("wjb_my_list_compact") === "1";


const $ = (id) => document.getElementById(id);

// ===== WJB Control Center v1: Admin System Settings =====
const DEFAULT_SYSTEM_SETTINGS = {
  appTitle: "🌊 Watch Jettaphon",
  appSubtitle: "สมุดบันทึกหนัง ซีรีส์ และอนิเมะของคุณ",
  updateMessage: "",
  enableTrending: true,
  enablePersonalAI: true,
  enableGuardian: true,
  enableRegister: true,
  maintenanceMode: false,
  defaultCompactView: false,
  trendingLoadSize: 20,
  trendingShowAddedBadge: true,
  hideAddedTrending: false,
  guardianAutoCheckDefault: false,
  guardianAutoFixRequiresConfirm: true,
  updatedAtText: ""
};
let systemSettings = { ...DEFAULT_SYSTEM_SETTINGS };
let systemSettingsLoaded = false;

function controlBool(value, fallback = false){
  return typeof value === "boolean" ? value : fallback;
}

function controlNumber(value, fallback = 20, min = 1, max = 200){
  const n = Number(value);
  if(Number.isNaN(n)) return fallback;
  return Math.max(min, Math.min(max, Math.round(n)));
}

async function loadSystemSettings(){
  try{
    const snap = await getDoc(doc(db, "systemSettings", "main"));
    systemSettings = { ...DEFAULT_SYSTEM_SETTINGS, ...(snap.exists() ? snap.data() : {}) };
    systemSettings.trendingLoadSize = controlNumber(systemSettings.trendingLoadSize, 20, 5, 100);
    systemSettingsLoaded = true;
    if(isAdmin && !snap.exists()){
      await setDoc(doc(db, "systemSettings", "main"), {
        ...systemSettings,
        updatedAt: serverTimestamp(),
        updatedBy: currentUser?.uid || "system"
      }, { merge:true });
    }
  }catch(e){
    console.warn("loadSystemSettings failed", e);
    systemSettings = { ...DEFAULT_SYSTEM_SETTINGS };
  }
  applySystemSettings();
  return systemSettings;
}

function setElementsDisplay(selector, visible){
  document.querySelectorAll(selector).forEach(el => {
    el.style.display = visible ? "" : "none";
  });
}

function ensureSystemBanner(){
  let banner = document.getElementById("systemUpdateBanner");
  if(!banner){
    banner = document.createElement("div");
    banner.id = "systemUpdateBanner";
    banner.className = "system-update-banner";
    document.body.prepend(banner);
  }
  return banner;
}

function applySystemSettings(){
  const titleEl = document.querySelector(".hero h1");
  const subEl = document.querySelector(".hero p");
  if(titleEl && systemSettings.appTitle) titleEl.innerText = systemSettings.appTitle;
  if(subEl && systemSettings.appSubtitle) subEl.innerText = systemSettings.appSubtitle;

  setElementsDisplay(".trend-menu-btn, .trend-hero-btn", controlBool(systemSettings.enableTrending, true));
  setElementsDisplay(".ai-menu-btn, .ai-hero-btn", controlBool(systemSettings.enablePersonalAI, true));
  setElementsDisplay(".guardian-menu-btn", isAdmin && controlBool(systemSettings.enableGuardian, true));
  setElementsDisplay(".brother-ai-menu-btn", isAdmin);

  const registerModeBtn = $("registerModeBtn");
  const registerActionBtn = document.querySelector('.actions.two button[onclick="register()"]');
  const registerOn = controlBool(systemSettings.enableRegister, true);
  if(registerModeBtn) registerModeBtn.style.display = registerOn ? "" : "none";
  if(registerActionBtn) registerActionBtn.style.display = registerOn ? "" : "none";
  if(!registerOn && authMode === "register") window.setAuthMode("login");

  const banner = ensureSystemBanner();
  const messages = [];
  if(systemSettings.updateMessage) messages.push(systemSettings.updateMessage);
  if(controlBool(systemSettings.maintenanceMode, false)){
    messages.push(isAdmin ? "🛠️ Maintenance Mode เปิดอยู่: ผู้ดูแลยังใช้งานได้" : "🛠️ เว็บอยู่ระหว่างปรับปรุงชั่วคราว");
  }
  banner.innerHTML = messages.map(escapeText).join("<br>");
  banner.style.display = messages.length ? "block" : "none";
  document.body.classList.toggle("wjb-maintenance", controlBool(systemSettings.maintenanceMode, false));

  if(wjbStorageGet("wjb_my_list_compact") === null && controlBool(systemSettings.defaultCompactView, false)){
    myListCompactView = true;
    updateMyListCompactUI();
  }
}

function controlCheckbox(id, value, label, help=""){
  return `<label class="control-toggle"><input id="${id}" type="checkbox" ${value ? "checked" : ""}> <span>${label}</span>${help ? `<small>${help}</small>` : ""}</label>`;
}

function controlInput(id, label, value, type="text", placeholder=""){
  return `<label class="control-field"><span>${label}</span><input id="${id}" type="${type}" value="${escapeText(value ?? "")}" placeholder="${escapeText(placeholder)}"></label>`;
}

function renderControlCenter(){
  const box = $("controlCenterContent");
  if(!box) return;
  box.innerHTML = `
    <div class="control-grid">
      <section class="control-card">
        <h3>🚦 Feature Flags</h3>
        ${controlCheckbox("ccEnableTrending", systemSettings.enableTrending, "เปิดหน้าเทรนด์", "ซ่อน/แสดงบอร์ดแนะนำออนไลน์")}
        ${controlCheckbox("ccEnableAI", systemSettings.enablePersonalAI, "เปิด AI แนะนำให้ดู", "ซ่อน/แสดง Personal AI")}
        ${controlCheckbox("ccEnableGuardian", systemSettings.enableGuardian, "เปิดสมองกลตรวจเว็บ", "ซ่อน/แสดง Guardian AI")}
        ${controlCheckbox("ccEnableRegister", systemSettings.enableRegister, "เปิดสมัครสมาชิก", "ปิดเมื่อไม่อยากรับ user ใหม่")}
        ${controlCheckbox("ccMaintenance", systemSettings.maintenanceMode, "Maintenance Mode", "แจ้งผู้ใช้ว่าเว็บกำลังปรับปรุง")}
        ${controlCheckbox("ccDefaultCompact", systemSettings.defaultCompactView, "เริ่มต้นด้วยมุมมองย่อ", "เหมาะเมื่อข้อมูลเยอะ")}
      </section>

      <section class="control-card">
        <h3>✏️ ข้อความหน้าเว็บ</h3>
        ${controlInput("ccAppTitle", "ชื่อเว็บ", systemSettings.appTitle)}
        ${controlInput("ccAppSubtitle", "คำอธิบายใต้ชื่อเว็บ", systemSettings.appSubtitle)}
        <label class="control-field"><span>ประกาศ/ข้อความอัปเดต</span><textarea id="ccUpdateMessage" placeholder="เช่น วันนี้ปรับระบบเทรนด์ใหม่">${escapeText(systemSettings.updateMessage || "")}</textarea></label>
      </section>

      <section class="control-card">
        <h3>🔥 ตั้งค่าเทรนด์</h3>
        ${controlInput("ccTrendingLoadSize", "จำนวนโหลดต่อรอบ", systemSettings.trendingLoadSize, "number", "20")}
        ${controlCheckbox("ccTrendingAddedBadge", systemSettings.trendingShowAddedBadge, "แสดงสถานะ ✅ เพิ่มแล้ว", "ช่วยไม่เพิ่มซ้ำ")}
        ${controlCheckbox("ccHideAddedTrending", systemSettings.hideAddedTrending, "ซ่อนเรื่องที่เพิ่มแล้ว", "ใช้กับเวอร์ชั่นเทรนด์ถัดไป")}
      </section>

      <section class="control-card">
        <h3>🛡️ Guardian AI</h3>
        ${controlCheckbox("ccGuardianAuto", systemSettings.guardianAutoCheckDefault, "เปิด Auto Check เป็นค่าเริ่มต้น", "ตรวจสุขภาพเว็บตอนเปิด")}
        ${controlCheckbox("ccGuardianConfirm", systemSettings.guardianAutoFixRequiresConfirm, "Auto Fix ต้องยืนยันก่อน", "แนะนำให้เปิดไว้")}
        <div class="control-mini-report">
          <b>สถานะล่าสุด</b>
          <p>Settings loaded: ${systemSettingsLoaded ? "✅" : "⚠️"}</p>
          <p>ผู้ดูแล: ${isAdmin ? "✅" : "❌"}</p>
        </div>
      </section>
    </div>

    <div class="control-actions">
      <button onclick="saveControlCenterSettings()">💾 บันทึกค่าระบบ</button>
      <button class="gray" onclick="resetControlCenterDraft()">↩️ คืนค่าเริ่มต้น</button>
      <button class="gray" onclick="exportControlSettings()">📤 Export Config</button>
      <button class="gray" onclick="importControlSettings()">📥 Import Config</button>
    </div>

    <textarea id="controlConfigBox" class="control-config-box" placeholder="พื้นที่ Export / Import Config"></textarea>
  `;
}

window.openControlCenter = async function(){
  if(!isAdmin) return wjbToast("เฉพาะผู้ดูแลเว็บเท่านั้น");
  if($("controlCenterModal")) $("controlCenterModal").style.display = "flex";
  await loadSystemSettings();
  renderControlCenter();
};

window.closeControlCenter = function(){
  if($("controlCenterModal")) $("controlCenterModal").style.display = "none";
};

window.saveControlCenterSettings = async function(){
  if(!isAdmin) return wjbToast("เฉพาะผู้ดูแลเว็บเท่านั้น");
  const next = {
    appTitle: $("ccAppTitle")?.value.trim() || DEFAULT_SYSTEM_SETTINGS.appTitle,
    appSubtitle: $("ccAppSubtitle")?.value.trim() || DEFAULT_SYSTEM_SETTINGS.appSubtitle,
    updateMessage: $("ccUpdateMessage")?.value.trim() || "",
    enableTrending: !!$("ccEnableTrending")?.checked,
    enablePersonalAI: !!$("ccEnableAI")?.checked,
    enableGuardian: !!$("ccEnableGuardian")?.checked,
    enableRegister: !!$("ccEnableRegister")?.checked,
    maintenanceMode: !!$("ccMaintenance")?.checked,
    defaultCompactView: !!$("ccDefaultCompact")?.checked,
    trendingLoadSize: controlNumber($("ccTrendingLoadSize")?.value, 20, 5, 100),
    trendingShowAddedBadge: !!$("ccTrendingAddedBadge")?.checked,
    hideAddedTrending: !!$("ccHideAddedTrending")?.checked,
    guardianAutoCheckDefault: !!$("ccGuardianAuto")?.checked,
    guardianAutoFixRequiresConfirm: !!$("ccGuardianConfirm")?.checked,
    updatedBy: currentUser.uid,
    updatedByEmail: currentUser.email || "",
    updatedAtText: new Date().toLocaleString("th-TH"),
    updatedAt: serverTimestamp()
  };
  await setDoc(doc(db, "systemSettings", "main"), next, { merge:true });
  systemSettings = { ...DEFAULT_SYSTEM_SETTINGS, ...next };
  applySystemSettings();
  await logActivity("admin_update_system_settings", { changedFields: Object.keys(next).filter(k => !["updatedAt"].includes(k)) });
  wjbToast("บันทึกค่าระบบเรียบร้อยแล้ว");
  renderControlCenter();
};

window.resetControlCenterDraft = async function(){
  if(!(await wjbConfirm("คืนค่าหน้าฟอร์มเป็นค่าเริ่มต้นก่อนบันทึก ใช่ไหม?"))) return;
  systemSettings = { ...DEFAULT_SYSTEM_SETTINGS };
  renderControlCenter();
};

window.exportControlSettings = function(){
  const box = $("controlConfigBox");
  if(box) box.value = JSON.stringify({ ...systemSettings, updatedAt: undefined }, null, 2);
};

window.importControlSettings = function(){
  const box = $("controlConfigBox");
  if(!box || !box.value.trim()) return wjbToast("วาง Config JSON ก่อน");
  try{
    const data = JSON.parse(box.value);
    systemSettings = { ...DEFAULT_SYSTEM_SETTINGS, ...data };
    renderControlCenter();
    wjbToast("นำเข้า Config ลงฟอร์มแล้ว กดบันทึกค่าระบบเพื่อใช้งานจริง");
  }catch(e){
    wjbToast("Config JSON ไม่ถูกต้อง: " + e.message);
  }
};
function normalizeUsernameKey(name){
  return String(name || "").trim().toLowerCase();
}

async function ensureUsernameIndex(uid, username, email){
  const key = normalizeUsernameKey(username);
  if(!uid || !key || !email) return;
  try{
    await setDoc(doc(db, "usernames", key), {
      uid,
      username,
      email: String(email).toLowerCase(),
      updatedAt: serverTimestamp()
    }, { merge: true });
  }catch(_e){}
}
let authMode="login";
window.setAuthMode=function(mode){
  if(mode === "register" && !controlBool(systemSettings.enableRegister, true)){
    wjbToast("ตอนนี้ผู้ดูแลเว็บปิดการสมัครสมาชิกชั่วคราว");
    mode = "login";
  }
  authMode=mode;
  const emailInput = document.getElementById("email");
  document.body.classList.toggle("auth-login-mode", mode === "login");
  document.body.classList.toggle("auth-register-mode", mode === "register");
  if(emailInput){
    emailInput.style.display = mode === "register" ? "block" : "none";
    emailInput.required = mode === "register";
    if(mode === "login") emailInput.value = "";
  }
  authTitle.innerText=mode=="login"?"เข้าสู่ระบบ WJB":"สมัครสมาชิก WJB";
  loginModeBtn.className=mode=="login"?"":"gray";
  registerModeBtn.className=mode=="register"?"":"gray";
  if(mode !== "login") toggleForgotPassword(null, true);
}

window.toggleForgotPassword=function(event, forceClose){
  if(event) event.preventDefault();
  const box = document.getElementById("forgotPasswordBox");
  if(!box) return false;
  const show = forceClose ? false : box.style.display === "none";
  box.style.display = show ? "block" : "none";
  if(show){
    const loginVal = ($("displayName")?.value || "").trim();
    const emailField = $("forgotPasswordEmail");
    if(emailField){
      emailField.value = loginVal.includes("@") ? loginVal : "";
      emailField.focus();
    }
  }
  return false;
}

window.sendForgotPasswordEmail=async function(){
  const email = ($("forgotPasswordEmail")?.value || "").trim();
  if(!email) return wjbToast("กรุณากรอกอีเมลที่ใช้สมัคร");
  const btn = $("forgotPasswordBtn");
  const originalText = btn ? btn.innerText : "";
  try{
    if(btn){ btn.disabled = true; btn.innerText = "กำลังส่ง..."; }
    await sendPasswordResetEmail(auth, email.toLowerCase());
    wjbToast("ส่งลิงก์รีเซ็ตรหัสผ่านไปที่อีเมลแล้ว กรุณาตรวจสอบกล่องขาเข้า (หรือ Junk/Spam)");
    toggleForgotPassword(null, true);
  }catch(e){
    if(e.code === "auth/invalid-email") return wjbToast("รูปแบบอีเมลไม่ถูกต้อง");
    if(e.code === "auth/user-not-found") return wjbToast("ไม่พบบัญชีที่ใช้อีเมลนี้");
    wjbToast("เกิดข้อผิดพลาด: "+e.message);
  }finally{
    if(btn){ btn.disabled = false; btn.innerText = originalText; }
  }
}

function getCurrentUsername(){
  return $("userName")?.innerText || currentUser?.displayName || currentUser?.email || "WJB User";
}

function sanitizeLogPayload(payload = {}){
  const safe = { ...payload };
  ["poster", "password", "emailVal"].forEach(k => delete safe[k]);
  return safe;
}

async function logActivity(action, detail = {}){
  if(!currentUser) return;
  try{
    // v15.4: เก็บ log ไว้ในแผงตรวจสอบการแก้ไข (เฉพาะ action ที่ผูกกับ item เฉพาะตัว)
    WJBSyncDashboard.recordEdit({ itemId: detail.itemId, itemTitle: detail.itemId ? (detail.itemTitle || detail.title || "") : null, action });
    // v15.0: activityLogs เดิมยิง addDoc ทันทีทุกครั้ง (ทุก add/edit/delete/favorite ฯลฯ
    // เรียก logActivity อยู่แล้ว) เปลี่ยนมาต่อคิวแทน ให้ไปรวมกับ batch เดียวกับ watchItems
    const logId = WJBSync.newDocId("activityLogs");
    WJBSync.queueSet("activityLogs", logId, {
      action,
      uid: currentUser.uid,
      email: currentUser.email || "",
      username: getCurrentUsername(),
      detail: sanitizeLogPayload(detail),
      itemId: detail.itemId || "",
      itemTitle: detail.itemTitle || detail.title || "",
      targetUid: detail.targetUid || "",
      createdMs: Date.now()
    });
  }catch(e){
    console.warn("logActivity failed", e);
  }
}

function checkAdmin(user, userData = {}){
  const email = (user?.email || "").toLowerCase();
  return userData.role === "admin" || ADMIN_EMAILS.map(e => e.toLowerCase()).includes(email) || ADMIN_UIDS.includes(user?.uid);
}

function setAdminUI(){
  try{ document.body.classList.toggle("wjb-admin", !!isAdmin); }catch(_e){}
  try{ document.body.classList.toggle("wjb-user", !isAdmin); }catch(_e){}
  const adminBox = document.querySelector(".admin-only-menu");
  if(adminBox) adminBox.style.display = isAdmin ? "block" : "none";

  const roleBadge = $("menuRoleBadge");
  if(roleBadge) roleBadge.innerText = isAdmin ? "👑 บัญชีผู้ดูแล" : "👤 บัญชีผู้ใช้ปกติ";

  const btn = $("adminMenuBtn");
  if(btn) btn.style.display = isAdmin ? "flex" : "none";
  const controlBtn = $("controlCenterMenuBtn");
  if(controlBtn) controlBtn.style.display = isAdmin ? "flex" : "none";

  document.querySelectorAll(".guardian-menu-btn, .brother-ai-menu-btn").forEach(el => {
    el.style.display = isAdmin ? "flex" : "none";
  });
}

function setBulkDeleteUI(){
  const bar = $("bulkDeleteBar");
  if(bar) bar.style.display = currentTab === "my" && currentUser ? "flex" : "none";

  const toggleBtn = $("bulkDeleteToggleBtn");
  const confirmBtn = $("bulkDeleteConfirmBtn");
  const cancelBtn = $("bulkDeleteCancelBtn");
  const count = $("bulkDeleteCount");
  const floating = $("bulkDeleteFloatingBar");
  const floatingCount = $("bulkDeleteFloatingCount");

  if(toggleBtn) toggleBtn.style.display = bulkDeleteMode ? "none" : "block";
  if(confirmBtn) confirmBtn.style.display = bulkDeleteMode ? "block" : "none";
  if(cancelBtn) cancelBtn.style.display = bulkDeleteMode ? "block" : "none";
  if(count) count.innerText = bulkDeleteMode
    ? `เลือกแล้ว ${bulkDeleteSelectedIds.size} รายการ`
    : "กดปุ่มเพื่อเลือกหลายรายการแล้วลบทีเดียว (หรือกดค้างที่การ์ดเพื่อเลือกเรื่องนั้นได้ทันที)";

  if(floating) floating.style.display = (currentTab === "my" && currentUser && bulkDeleteMode) ? "flex" : "none";
  if(floatingCount) floatingCount.innerText = `เลือกแล้ว ${bulkDeleteSelectedIds.size} รายการ`;
}

function updateMyListCompactUI(){
  const list = $("list");
  if(list) list.classList.toggle("my-list-compact", !!myListCompactView);
}


window.toggleMyListCompactView = function(){
  const anchorTitle = wjbGetVisibleCardAnchor();
  myListCompactView = !myListCompactView;
  wjbStorageSet("wjb_my_list_compact", myListCompactView ? "1" : "0");
  updateMyListCompactUI();
  renderCurrentTab();
  if(anchorTitle){
    wjbRestoreScrollToCardSettled(anchorTitle);
  }
};

// ===== WJB v6.3 Bottom Navigation: one-tap safe handlers =====
function wjbStopNavEvent(event){
  try{
    if(event){
      event.preventDefault();
      event.stopPropagation();
    }
  }catch(_e){}
  return false;
}

function wjbScrollToHomeTop(){
  setTimeout(() => {
    try{ window.scrollTo({ top: 0, behavior: "smooth" }); }
    catch(_e){ window.scrollTo(0, 0); }
  }, 40);
}


// v11.1 Navigation/Form Jump Fix:
// - Bottom nav buttons close any open overlay/modal before moving pages.
// - Search/Trending "เลือก" jumps directly to the detail form fields, not the preview card.
function wjbCloseAllOverlays(){
  try{ if(typeof closeSmartDetail === "function") closeSmartDetail(); }catch(_e){}
  const modalIds = [
    "trendingModal","settingsModal","seasonDetailModal","adminPanel","personalAIBox","brotherAIBox","airingBoardModal",
    "hallOfFameModal","controlCenterModal","guardianAIModal","pwaInstallModal","avatarModal"
  ];
  modalIds.forEach((id)=>{
    const el = document.getElementById(id);
    if(el) el.style.display = "none";
  });
  try{ document.querySelectorAll(".menu-toggle").forEach(btn => btn.style.display = ""); }catch(_e){}
  try{ document.body.classList.remove("modal-open","wjb-real-modal-open","wjb-v84-real-modal-open","wjb-subscreen-open"); }catch(_e){}
}

function wjbJumpToFormDetails(focusId){
  const target = document.getElementById("wjbFormDetailsStart") || document.getElementById("season") || document.getElementById("formBox");
  setTimeout(()=>{
    try{
      const y = Math.max(0, target.getBoundingClientRect().top + window.scrollY - 84);
      window.scrollTo({ top: y, behavior: "smooth" });
    }catch(_e){ try{ target.scrollIntoView({behavior:"smooth", block:"start"}); }catch(__e){} }
    setTimeout(()=>{
      const focusEl = document.getElementById(focusId || "season") || document.getElementById("season");
      try{ if(focusEl) focusEl.focus({preventScroll:true}); }catch(_e){ try{ if(focusEl) focusEl.focus(); }catch(__e){} }
    }, 260);
  }, 120);
}

function wjbUpdateBottomViewButton(){
  const icon = $("wjbBottomViewIcon");
  const label = $("wjbBottomViewLabel");
  const btn = $("wjbBottomViewToggle");
  if(icon) icon.innerText = myListCompactView ? "▦" : "▣";
  if(label) label.innerText = "มุมมอง";
  if(btn) btn.title = myListCompactView ? "กดเพื่อเปลี่ยนเป็นรูปใหญ่" : "กดเพื่อเปลี่ยนเป็นมุมมองย่อ";
}

// v14.8: จำการ์ดที่กำลังดูอยู่ก่อนสลับมุมมอง แล้วเลื่อนกลับไปการ์ดเดิมหลังสลับ
// (แก้ปัญหาสลับมุมมองแล้วเด้งไปโผล่เรื่องอื่น เพราะความสูงการ์ดเปลี่ยนแต่ scroll ยังอยู่ตำแหน่ง pixel เดิม)
// v15.0 fix: anchor line used to be a hardcoded 130px, which only matched the
// plain header. When a stat-filtered view was open, "viewBar"/"typeFilterBar"
// add extra sticky height on top of the list, so the old fixed offset picked
// the wrong card as the anchor and the first tap on the view toggle appeared
// to "land on the wrong page" — a second tap (recalculated from the now-shifted
// scroll position) happened to look closer to correct. Now the offset is
// measured from whichever bars are actually visible.
function wjbGetStickyHeaderOffset(){
  let offset = 130;
  try{
    const viewBar = $("viewBar");
    const typeBar = $("typeFilterBar");
    if(viewBar && getComputedStyle(viewBar).display !== "none"){
      offset += viewBar.getBoundingClientRect().height || 0;
    }
    if(typeBar && getComputedStyle(typeBar).display !== "none"){
      offset += typeBar.getBoundingClientRect().height || 0;
    }
  }catch(_e){}
  return offset;
}

function wjbGetVisibleCardAnchor(){
  try{
    const list = $("list");
    if(!list) return null;
    const cards = Array.from(list.querySelectorAll("[data-bulk-title]"));
    const anchorLine = wjbGetStickyHeaderOffset();
    for(const el of cards){
      const rect = el.getBoundingClientRect();
      if(rect.bottom > anchorLine){
        return el.getAttribute("data-bulk-title") || null;
      }
    }
  }catch(_e){}
  return null;
}

function wjbRestoreScrollToCard(encodedTitle){
  if(!encodedTitle) return;
  try{
    const list = $("list");
    if(!list) return;
    const target = list.querySelector(`[data-bulk-title="${encodedTitle}"]`);
    if(target){
      const offset = wjbGetStickyHeaderOffset() - 40;
      const y = Math.max(0, target.getBoundingClientRect().top + window.scrollY - offset);
      window.scrollTo({ top: y, behavior: "auto" });
    }
  }catch(_e){}
}

// v15.0 fix: one requestAnimationFrame pair isn't always enough to catch layout
// that's still settling right after a bottom-nav tap (the same click also triggers
// prepareForNavigation()/unlockBodyScroll() in navigation.js, which can adjust body
// scroll-lock styles around the same frame). Re-checking once more shortly after
// makes the restore land correctly on the first tap instead of needing a second one.
function wjbRestoreScrollToCardSettled(encodedTitle){
  if(!encodedTitle) return;
  requestAnimationFrame(() => requestAnimationFrame(() => {
    wjbRestoreScrollToCard(encodedTitle);
    setTimeout(() => wjbRestoreScrollToCard(encodedTitle), 220);
  }));
}

window.wjbNavAdd = function(event){
  try{ wjbCloseAllOverlays(); backToAdd(); wjbJumpToFormDetails("title"); }catch(_e){}
  return wjbStopNavEvent(event);
};

window.wjbNavHome = function(event){
  try{
    wjbCloseAllOverlays();
    currentTab = "my";
    const myTab = $("myTab"), exploreTab = $("exploreTab"), formBox = $("formBox"), backupBox = $("backupBox"), viewBar = $("viewBar"), typeFilterBar = $("typeFilterBar");
    if(myTab) myTab.className = "";
    if(exploreTab) exploreTab.className = "gray";
    if(formBox) formBox.style.display = "grid";
    if(backupBox) backupBox.style.display = "grid";
    if(viewBar) viewBar.style.display = "none";
    if(typeFilterBar) typeFilterBar.style.display = "none";
    window.statTypeFilter = "all";
    showItems();
    setBulkDeleteUI();
    wjbScrollToHomeTop();
  }catch(_e){ try{ window.scrollTo(0,0); }catch(__e){} }
  return wjbStopNavEvent(event);
};

window.wjbNavTrending = function(event){
  try{ openTrendingExplorer(); }catch(_e){}
  return wjbStopNavEvent(event);
};

window.wjbNavExplore = function(event){
  try{ wjbCloseAllOverlays(); switchTab("explore"); }catch(_e){}
  return wjbStopNavEvent(event);
};

window.wjbNavViewToggle = function(event){
  try{
    // v13.9 fix: only close floating overlays/modals here — do NOT touch
    // currentTab or the tab UI. Previously this always forced currentTab
    // back to "my", so tapping the view toggle while on the public/explore
    // list ("รายการสาธารณะจากคนอื่น") bounced the user back to the home tab
    // instead of just switching the card layout in place.
    wjbCloseAllOverlays();
    const anchorTitle = wjbGetVisibleCardAnchor(); // v14.8: จำเรื่องที่กำลังดูอยู่
    myListCompactView = !myListCompactView;
    wjbStorageSet("wjb_my_list_compact", myListCompactView ? "1" : "0");
    updateMyListCompactUI();
    wjbUpdateBottomViewButton();
    renderCurrentTab();
    if(anchorTitle){
      wjbRestoreScrollToCardSettled(anchorTitle);
    }
  }catch(_e){}
  return wjbStopNavEvent(event);
};

// Sync bottom view label/icon after old compact toggles too
const wjbUpdateMyListCompactUIV63 = updateMyListCompactUI;
updateMyListCompactUI = function(){
  wjbUpdateMyListCompactUIV63();
  wjbUpdateBottomViewButton();
};
setTimeout(wjbUpdateBottomViewButton, 300);

window.toggleBulkDeleteMode = function(){
  bulkDeleteMode = !bulkDeleteMode;
  if(!bulkDeleteMode) bulkDeleteSelectedIds.clear();
  setBulkDeleteUI();
  renderCurrentTab();
};

window.cancelBulkDeleteMode = function(){
  bulkDeleteMode = false;
  bulkDeleteSelectedIds.clear();
  setBulkDeleteUI();
  renderCurrentTab();
};

window.toggleBulkGroup = function(encodedIds, checked){
  try{
    const ids = JSON.parse(decodeURIComponent(encodedIds));
    ids.forEach(id => checked ? bulkDeleteSelectedIds.add(id) : bulkDeleteSelectedIds.delete(id));
    setBulkDeleteUI();
  }catch(e){
    console.warn("toggleBulkGroup failed", e);
  }
};

window.deleteSelectedItems = async function(){
  if(!currentUser || !bulkDeleteSelectedIds.size) return wjbToast("ยังไม่ได้เลือกรายการที่จะลบ");

  const selectedIds = Array.from(bulkDeleteSelectedIds);
  const selectedItems = items.filter(i => selectedIds.includes(i.id));
  const label = selectedItems.slice(0, 5).map(summarizeItem).join(", ");
  const more = selectedItems.length > 5 ? ` และอีก ${selectedItems.length - 5} รายการ` : "";

  if(!(await wjbConfirm(`ต้องการลบ ${selectedItems.length} รายการที่เลือกใช่ไหม?\n${label}${more}`, {danger:true, okText:"ลบ"}))) return;

  try{
    // v15.0: ลบใน local ทันทีทั้งหมด + ต่อคิวลบทีละรายการ (จะไปรวมเป็น batch commit
    // เดียวกันตอน flush อยู่แล้ว ไม่ต้องรอ Firestore ทีละตัว)
    for(const item of selectedItems){
      logActivity("delete_item", { itemId:item.id, itemTitle:summarizeItem(item), bulkDelete:true });
      WJBSync.queueDelete("watchItems", item.id);
    }
    const removedIds = new Set(selectedIds);
    items = items.filter(i => !removedIds.has(i.id));
    WJBSync.setLocalItems(currentUser.uid, items);
    bulkDeleteSelectedIds.clear();
    bulkDeleteMode = false;
    showItems();
    setBulkDeleteUI();
    wjbToast(`ลบเรียบร้อย ${selectedItems.length} รายการ`);
  }catch(e){
    wjbToast("ลบไม่สำเร็จ: " + e.message);
  }
};

function formatAdminDate(ms){
  if(!ms) return "-";
  try{return new Date(ms).toLocaleString("th-TH");}catch(e){return "-";}
}

function summarizeItem(item){
  return `${item.title || "ไม่ระบุ"}${item.season ? " / " + item.season : ""}`;
}

function getActionLabel(action){
  const labels = {
    login: "เข้าสู่ระบบ",
    add_item: "เพิ่มรายการ",
    update_item: "แก้ไขรายการ",
    delete_item: "ลบรายการ",
    toggle_favorite: "เปลี่ยนรายการโปรด",
    toggle_group_privacy: "เปลี่ยนสถานะสาธารณะ/ส่วนตัวทั้งเรื่อง",
    copy_public_item: "คัดลอกรายการสาธารณะ",
    import_data: "นำเข้าข้อมูล",
    add_related_season: "เพิ่มซีซั่น/ภาค",
    change_username: "เปลี่ยนชื่อผู้ใช้",
    change_password: "เปลี่ยนรหัสผ่าน",
    change_avatar: "เปลี่ยนรูปโปรไฟล์",
    admin_delete_item: "แอดมินลบรายการ",
    admin_set_user_role: "แอดมินเปลี่ยนสิทธิ์",
    admin_update_system_settings: "แอดมินแก้ค่าระบบ"
  };
  return labels[action] || action || "-";
}

function getActionBadgeClass(action){
  if(["delete_item", "admin_delete_item"].includes(action)) return "danger";
  if(["add_item", "copy_public_item", "add_related_season"].includes(action)) return "success";
  if(["admin_set_user_role"].includes(action)) return "admin";
  return "normal";
}

function formatLogDetail(log){
  const detail = log.detail || {};
  const mainTitle = log.itemTitle || detail.itemTitle || detail.title || "-";
  const detailPairs = [];
  if(detail.type) detailPairs.push(["ประเภท", detail.type]);
  if(detail.status) detailPairs.push(["สถานะ", detail.status]);
  if(detail.season) detailPairs.push(["ซีซั่น/ภาค", detail.season]);
  if(detail.role) detailPairs.push(["สิทธิ์", detail.role]);
  if(detail.count !== undefined) detailPairs.push(["จำนวน", detail.count]);
  if(detail.favorite !== undefined) detailPairs.push(["รายการโปรด", detail.favorite ? "ใช่" : "ไม่ใช่"]);
  if(Array.isArray(detail.changedFields) && detail.changedFields.length) detailPairs.push(["แก้ไขช่อง", detail.changedFields.join(", ")]);

  const summary = detailPairs.map(([k,v]) => `<span class="log-chip">${escapeText(k)}: ${escapeText(v)}</span>`).join(" ");
  const raw = JSON.stringify(detail, null, 2);
  const detailId = `logDetail_${log.id || Math.random().toString(36).slice(2)}`;
  return `
    <div class="log-main-title">${escapeText(mainTitle)}</div>
    <div class="log-summary">${summary || "<span class=\"muted\">ไม่มีรายละเอียดเพิ่มเติม</span>"}</div>
    <button class="log-detail-btn gray" onclick="toggleLogDetail('${detailId}')">ดูรายละเอียด</button>
    <pre id="${detailId}" class="log-json" style="display:none">${escapeText(raw)}</pre>
  `;
}

window.toggleLogDetail = function(id){
  const el = $(id);
  if(!el) return;
  el.style.display = el.style.display === "none" ? "block" : "none";
};

function buildAdminStatCards(){
  const publicCount = adminItems.filter(i => i.isPublic !== false).length;
  const privateCount = adminItems.length - publicCount;
  const adminCount = adminUsers.filter(u => u.role === "admin").length;
  return `
    <div class="admin-stats">
      <div><b>${adminUsers.length}</b><span>ผู้ใช้</span></div>
      <div><b>${adminItems.length}</b><span>รายการทั้งหมด</span></div>
      <div><b>${publicCount}</b><span>สาธารณะ</span></div>
      <div><b>${privateCount}</b><span>ส่วนตัว</span></div>
      <div><b>${adminLogs.length}</b><span>ประวัติล่าสุด</span></div>
      <div><b>${adminCount}</b><span>แอดมิน</span></div>
    </div>
  `;
}

window.openAdminPanel = async function(){
  if(!isAdmin) return wjbToast("เฉพาะแอดมินเท่านั้น");
  const modal = $("adminModal");
  if(modal) modal.style.display = "flex";
  await loadAdminData();
};

window.closeAdminPanel = function(){
  if($("adminModal")) $("adminModal").style.display = "none";
};

async function loadAdminData(){
  if(!isAdmin) return;
  const content = $("adminContent");
  if(content) content.innerHTML = `<div class="smart-loading">กำลังโหลดข้อมูลแอดมิน...</div>`;
  try{
    const [usersSnap, itemsSnap, logsSnap] = await Promise.all([
      getDocs(collection(db,"users")),
      getDocs(query(collection(db,"watchItems"), orderBy("createdMs","desc"), limit(250))),
      getDocs(query(collection(db,"activityLogs"), orderBy("createdMs","desc"), limit(150)))
    ]);
    adminUsers = usersSnap.docs.map(d => ({ id:d.id, ...d.data() }));
    adminItems = itemsSnap.docs.map(d => ({ id:d.id, ...d.data() }));
    adminLogs = logsSnap.docs.map(d => ({ id:d.id, ...d.data() }));
    renderAdminTab("overview");
  }catch(e){
    if(content) content.innerHTML = `<div class="empty">โหลดข้อมูลแอดมินไม่สำเร็จ: ${escapeText(e.message)}</div>`;
  }
}

window.refreshAdminData = loadAdminData;

window.renderAdminTab = function(tab){
  if(!isAdmin) return;
  document.querySelectorAll(".admin-tabs button").forEach(btn => btn.classList.add("gray"));
  const active = document.querySelector(`[data-admin-tab="${tab}"]`);
  if(active) active.classList.remove("gray");
  const content = $("adminContent");
  if(!content) return;

  if(tab === "overview"){
    content.innerHTML = buildAdminStatCards() + `
      <div class="admin-note">
        <b>สถานะแอดมินพร้อมใช้งาน</b>
        <p>แอดมินดูผู้ใช้ รายการทั้งหมด และประวัติการกระทำได้จากหน้านี้</p>
      </div>
    `;
    return;
  }

  if(tab === "users"){
    content.innerHTML = `
      <div class="admin-table-wrap"><table class="admin-table">
        <thead><tr><th>ชื่อ</th><th>อีเมล</th><th>สิทธิ์</th><th>UID</th><th>จัดการ</th></tr></thead>
        <tbody>${adminUsers.map(u => `
          <tr>
            <td>${escapeText(u.username || u.displayName || "-")}</td>
            <td>${escapeText(u.email || "-")}</td>
            <td>${u.role === "admin" ? "👑 admin" : "user"}</td>
            <td><code>${escapeText(u.uid || u.id || "-")}</code></td>
            <td>
              ${u.role === "admin" ? `<button class="gray" onclick="setUserRole('${u.id}','user')">ลดเป็น user</button>` : `<button onclick="setUserRole('${u.id}','admin')">ตั้งเป็น admin</button>`}
            </td>
          </tr>`).join("")}</tbody>
      </table></div>`;
    return;
  }

  if(tab === "items"){
    const search = ($("adminSearch")?.value || "").toLowerCase();
    const list = adminItems.filter(i => `${i.title||""} ${i.ownerName||""} ${i.ownerEmail||""}`.toLowerCase().includes(search));
    content.innerHTML = `
      <input id="adminSearch" class="search" placeholder="🔍 ค้นหารายการ/เจ้าของ" value="${escapeText(search)}" oninput="renderAdminTab('items')">
      <div class="admin-table-wrap"><table class="admin-table">
        <thead><tr><th>รายการ</th><th>ประเภท</th><th>สถานะ</th><th>เจ้าของ</th><th>วันที่</th><th>จัดการ</th></tr></thead>
        <tbody>${list.map(i => `
          <tr>
            <td><b>${escapeText(summarizeItem(i))}</b><br><small>${i.isPublic ? "🌍 สาธารณะ" : "🔒 ส่วนตัว"}</small></td>
            <td>${escapeText(i.type || "-")}</td>
            <td>${escapeText(i.status || "-")}</td>
            <td>${escapeText(i.ownerName || "-")}<br><small>${escapeText(i.ownerEmail || "")}</small></td>
            <td>${formatAdminDate(i.createdMs)}</td>
            <td><button class="danger" onclick="adminDeleteItem('${i.id}')">ลบ</button></td>
          </tr>`).join("")}</tbody>
      </table></div>`;
    return;
  }

  if(tab === "logs"){
    content.innerHTML = `
      <div class="admin-table-wrap"><table class="admin-table admin-log-table">
        <thead><tr><th>เวลา</th><th>ผู้ใช้</th><th>การกระทำ</th><th>รายการ/รายละเอียด</th></tr></thead>
        <tbody>${adminLogs.map(l => `
          <tr>
            <td>${formatAdminDate(l.createdMs)}</td>
            <td>${escapeText(l.username || l.email || "-")}<br><small>${escapeText(l.email || "")}</small></td>
            <td><span class="action-badge ${getActionBadgeClass(l.action)}">${escapeText(getActionLabel(l.action))}</span><br><small>${escapeText(l.action || "-")}</small></td>
            <td>${formatLogDetail(l)}</td>
          </tr>`).join("")}</tbody>
      </table></div>`;
    return;
  }
};

window.setUserRole = async function(uid, role){
  if(!isAdmin) return wjbToast("เฉพาะแอดมินเท่านั้น");
  if(!(await wjbConfirm(`ยืนยันเปลี่ยนสิทธิ์ผู้ใช้นี้เป็น ${role}?`))) return;
  await setDoc(doc(db,"users",uid), { role, updatedAt: serverTimestamp() }, { merge:true });
  await logActivity("admin_set_user_role", { targetUid: uid, role });
  await loadAdminData();
};

window.adminDeleteItem = async function(id){
  if(!isAdmin) return wjbToast("เฉพาะแอดมินเท่านั้น");
  const item = adminItems.find(i => i.id === id);
  if(!(await wjbConfirm(`แอดมินต้องการลบ "${summarizeItem(item || {})}" ใช่ไหม?`, {danger:true, okText:"ลบ"}))) return;
  await logActivity("admin_delete_item", { itemId:id, itemTitle: summarizeItem(item || {}), ownerId:item?.ownerId || "" });
  await deleteDoc(doc(db,"watchItems",id));
  await loadAdminData();
  if(currentUser && item?.ownerId === currentUser.uid) await loadMyItems();
};


window.register = async function(){
const registerBtn = $("registerActionBtn");
const doneRegisterBtn = window.wjbBusy ? window.wjbBusy(registerBtn, "กำลังสมัคร...") : () => {};
try{
if(!controlBool(systemSettings.enableRegister, true)) return wjbToast("ตอนนี้ผู้ดูแลเว็บปิดการสมัครสมาชิกชั่วคราว");
const username=$("displayName").value.trim();
const emailVal=$("email").value.trim();
const password=$("password").value;

if(!username) return wjbToast("กรุณาใส่ชื่อผู้ใช้");
if(!emailVal) return wjbToast("กรุณากรอกอีเมล");

const regex=/^[A-Za-z0-9ก-๙_]{3,20}$/;
if(!regex.test(username))
  return wjbToast("ชื่อผู้ใช้ใช้ได้เฉพาะ ภาษาไทย อังกฤษ ตัวเลข และ _ (3-20 ตัว)");

if(password.length < 6)
  return wjbToast("รหัสผ่านต้องอย่างน้อย 6 ตัว");

try{
const usernameKey = normalizeUsernameKey(username);
try {
  const nameSnap = await getDoc(doc(db, "usernames", usernameKey));
  if(nameSnap.exists()) return wjbToast("ชื่อผู้ใช้นี้ถูกใช้แล้ว");
} catch(_e) {}

const r=await createUserWithEmailAndPassword(auth,emailVal.toLowerCase(),password);
await updateProfile(r.user,{displayName:username});
await setDoc(doc(db,"users",r.user.uid),{
 uid:r.user.uid,
 username,
 email:emailVal.toLowerCase(),
 displayName:username,
 role:"user",
 createdAt: serverTimestamp(),
 updatedAt: serverTimestamp()
});
await ensureUsernameIndex(r.user.uid, username, emailVal);
try{
  await addDoc(collection(db,"activityLogs"),{
    action:"register",
    uid:r.user.uid,
    email:emailVal,
    username,
    detail:{},
    createdAt: serverTimestamp(),
    createdMs: Date.now()
  });
}catch(_e){}
wjbToast("สมัครสมาชิกสำเร็จ");
}catch(e){
 if(e.code==="auth/email-already-in-use") return wjbToast("อีเมลนี้ถูกใช้งานแล้ว");
 if(e.code==="auth/invalid-email") return wjbToast("รูปแบบอีเมลไม่ถูกต้อง");
 wjbToast("เกิดข้อผิดพลาด: "+e.message);
}
} finally {
  doneRegisterBtn();
}};

window.login = async function(){
  const loginInput = $("displayName").value.trim();
  const password = $("password").value;
  if(!loginInput) return wjbToast("กรุณาใส่อีเมลหรือชื่อผู้ใช้");
  if(!password) return wjbToast("กรุณาใส่รหัสผ่าน");
  const loginBtn = $("loginActionBtn");
  const doneLoginBtn = window.wjbBusy ? window.wjbBusy(loginBtn, "กำลังเข้าสู่ระบบ...") : () => {};
  try{
    // ถ้ากรอกเป็นอีเมล ให้ล็อกอินผ่าน Firebase Auth โดยตรง ไม่ต้องค้นหา users ก่อน
    if(loginInput.includes("@")){
      await signInWithEmailAndPassword(auth, loginInput.toLowerCase(), password);
      return;
    }

    // ถ้ากรอกเป็นชื่อผู้ใช้ ให้ค้นจาก username index ที่เปิดให้อ่านก่อนล็อกอิน
    const usernameKey = normalizeUsernameKey(loginInput);
    const nameSnap = await getDoc(doc(db, "usernames", usernameKey));
    if(!nameSnap.exists()) return wjbToast("ไม่พบชื่อผู้ใช้นี้ กรุณาลองใช้อีเมลในการเข้าสู่ระบบ");
    const email = nameSnap.data().email;
    if(!email) return wjbToast("ชื่อผู้ใช้นี้ยังไม่ได้ผูกอีเมล กรุณาเข้าสู่ระบบด้วยอีเมลก่อน 1 ครั้ง");
    await signInWithEmailAndPassword(auth,String(email).toLowerCase(),password);
  }catch(e){
    if(e.code === "permission-denied") return wjbToast("ระบบยังไม่อนุญาตให้ค้นหาด้วยชื่อผู้ใช้ กรุณาอัปเดต Firestore Rules ชุดล่าสุด");
    if(e.code === "auth/user-not-found") return wjbToast("ไม่พบบัญชีอีเมลนี้");
    if(e.code === "auth/wrong-password" || e.code === "auth/invalid-credential") return wjbToast("รหัสผ่านไม่ถูกต้อง");
    wjbToast("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง");
  } finally {
    doneLoginBtn();
  }
};

window.logout = async function() {
  await signOut(auth);
};

onAuthStateChanged(auth, async (user) => {
  currentUser = user;

  if (user) {
    document.body.classList.remove("wjb-auth-only");
    $("authBox").style.display = "none";
    $("userBox").classList.remove("open");
    $("mainApp").style.display = "block";
    setBulkDeleteUI();
    const userSnap = await getDoc(doc(db,"users",user.uid));
    const userData = userSnap.exists() ? userSnap.data() : {};
    isAdmin = checkAdmin(user, userData);
    setAdminUI();
    await loadSystemSettings();
    const savedName = userSnap.exists() ? (userData.username || user.displayName) : user.displayName;
    const finalUsername = savedName || (user.email ? user.email.split("@")[0] : "WJB User");
    $("userName").innerText = finalUsername;
    $("userEmail").innerText = user.email;
    const avatar = userSnap.exists() ? userData.avatar : null;
    if(avatar){ wjbStorageSet('avatar_'+user.uid,avatar); const menuAvatar=document.getElementById('menuAvatar'); if(menuAvatar) menuAvatar.src=avatar; }


    await setDoc(doc(db, "users", user.uid), {
      uid: user.uid,
      username: finalUsername,
      displayName: finalUsername,
      email: user.email,
      role: userData.role || "user",
      lastLogin: serverTimestamp()
    }, { merge: true });
    await ensureUsernameIndex(user.uid, finalUsername, user.email);

    await logActivity("login", {});
    WJBSyncDashboard.resetSessionLog(); // v15.4: เริ่มนับการแก้ไข "ตั้งแต่ล็อกอิน" ใหม่ทุกครั้ง

    await loadMyItems();
    setupDraftAutosave();
    restoreDraftIfNeeded();
  } else {
    document.body.classList.add("wjb-auth-only");
    currentUser = null;
    isAdmin = false;
    setAdminUI();
    applySystemSettings();
    items = [];
    publicItems = [];
    $("authBox").style.display = "grid";
    $("userBox").style.display = "none";
    $("userBox").classList.remove("open");
    $("mainApp").style.display = "none";
    bulkDeleteMode = false;
    bulkDeleteSelectedIds.clear();
    setBulkDeleteUI();
    updateStats();
  }
});

// v15.0: รองรับใช้งานหลายอุปกรณ์ — เวลากลับมาที่แท็บนี้ (สลับแอปกลับมา/สลับแท็บ) ให้
// ดึงข้อมูลจาก Firestore มา merge กับ local แบบ CRDT-lite เบา ๆ อีกครั้ง เผื่อมีการ
// แก้ไขจากอุปกรณ์/แท็บอื่นระหว่างที่ไม่ได้เปิดหน้านี้อยู่ (throttle กันยิงถี่เกินไป)
let wjbLastVisibilityRefresh = 0;
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState !== "visible" || !currentUser) return;
  const now = Date.now();
  if (now - wjbLastVisibilityRefresh < 30000) return; // อย่างน้อย 30 วิ/ครั้ง
  wjbLastVisibilityRefresh = now;
  fetchMyItemsData().then(() => showItems()).catch(() => {});
});

window.switchTab = async function(tab) {
  currentTab = tab;
  $("myTab").className = tab === "my" ? "" : "gray";
  $("exploreTab").className = tab === "explore" ? "" : "gray";
  $("formBox").style.display = tab === "my" ? "grid" : "none";
  $("backupBox").style.display = tab === "my" ? "grid" : "none";
  if ($("viewBar")) $("viewBar").style.display = "none";

  if(tab !== "my") {
    bulkDeleteMode = false;
    bulkDeleteSelectedIds.clear();
  }
  setBulkDeleteUI();

  if (tab === "explore") {
    await loadPublicItems();
  } else {
    showItems();
  }
};

window.renderCurrentTab = function() {
  if (currentTab === "explore") {
    showPublicItems();
    return;
  }

  if ($("viewBar") && $("viewBar").style.display !== "none") {
    showFilteredStatItems(window.currentStatFilter);
    return;
  }

  showItems();
};

// v15.0 fix: the search box calls renderCurrentTab() on every keystroke (oninput),
// which rebuilds the whole card list's HTML from scratch. That cost scales with how
// many items the user has, so the longer someone uses the app and accumulates items,
// the more each keystroke makes the page stutter/feel stuck. Debounce so a fast typer
// only triggers one rebuild after they pause, instead of one per character.
let wjbRenderCurrentTabDebounceTimer = null;
window.wjbDebouncedRenderCurrentTab = function(){
  clearTimeout(wjbRenderCurrentTabDebounceTimer);
  wjbRenderCurrentTabDebounceTimer = setTimeout(() => {
    try{ window.renderCurrentTab(); }catch(_e){}
  }, 180);
};

async function fetchMyItemsData() {
  if (!currentUser) return;
  // v15.0: local-first — ใช้แคชในเครื่องเป็นฐานเสมอ แล้วค่อยดึงจาก Firestore มา merge
  // แบบ CRDT-lite (last-write-wins ตาม updatedAtMs) กันข้อมูลที่เพิ่ง sync จากอุปกรณ์นี้
  // (ซึ่งอาจยังไม่ flush ขึ้นคลาวด์) ถูกข้อมูลเก่าจาก Firestore ทับ
  const local = WJBSync.getLocalItems(currentUser.uid);
  try {
    const q = query(
      collection(db, "watchItems"),
      where("ownerId", "==", currentUser.uid)
    );
    const snapshot = await getDocs(q);
    const remote = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
    const merged = WJBSync.mergeItems(local, remote);
    WJBSync.setLocalItems(currentUser.uid, merged);
    items = merged;
  } catch (_e) {
    // ออฟไลน์/error: ใช้ข้อมูลในเครื่องไปก่อน ไม่ให้แอปพัง
    items = local || [];
  }
  items.sort((a, b) => (b.createdMs || 0) - (a.createdMs || 0));
}

async function loadMyItems() {
  if (!currentUser) return;
  // v15.0: วาดหน้าจอทันทีจากแคชในเครื่องก่อน (ไม่ต้องรอเน็ต) แล้วค่อย sync พื้นหลัง
  const cached = WJBSync.getLocalItems(currentUser.uid);
  if (cached.length) {
    items = cached.sort((a, b) => (b.createdMs || 0) - (a.createdMs || 0));
    showItems();
  }
  await fetchMyItemsData();
  showItems();
  wjbCheckAnimeAiringUpdates();
}

async function loadPublicItems() {
  const q = query(
    collection(db, "watchItems"),
    where("isPublic", "==", true)
  );
  const snapshot = await getDocs(q);
  publicItems = snapshot.docs
    .map(d => ({ id: d.id, ...d.data() }))
    .filter(item => !currentUser || item.ownerId !== currentUser.uid);
  publicItems.sort((a, b) => (b.createdMs || 0) - (a.createdMs || 0));
  showPublicItems();
}

window.addItem = async function() {
  if (!currentUser) {
    wjbToast("กรุณาเข้าสู่ระบบก่อน");
    return;
  }

  const title = $("title").value;
  const file = $("poster").files[0];
  const season = $("season") ? $("season").value : "";
  const releaseInfo = $("releaseInfo") ? $("releaseInfo").value : "";
  const episode = $("episode").value;
  const total = $("total").value;
  const episodeMode = $("episodeMode") ? $("episodeMode").value : "manual";
  const type = $("type").value;
  const status = $("status").value;
  const score = $("score").value === "" ? "" : Math.min(10, Math.max(0, Number($("score").value)));
  const note = $("note").value;
  const isPublic = $("isPublic").checked;

  if (title.trim() === "") {
    wjbToast("กรุณาใส่ชื่อเรื่อง");
    return;
  }

  const saveBtn = $("saveBtn");
  const doneSaveBtn = window.wjbBusy ? window.wjbBusy(saveBtn, "กำลังบันทึก...") : () => {};

  if (file) {
    resizeImage(file, async (resizedImage) => {
      try{
        await saveItem(title, resizedImage, season, releaseInfo, episode, total, episodeMode, type, status, score, note, isPublic);
      } finally {
        doneSaveBtn();
      }
    });
  } else {
    try{
      const oldPoster = editId ? (items.find(i => i.id === editId)?.poster || smartPoster || "") : (smartPoster || "");
      await saveItem(title, oldPoster, season, releaseInfo, episode, total, episodeMode, type, status, score, note, isPublic);
    } finally {
      doneSaveBtn();
    }
  }
};

function resizeImage(file, callback) {
  const reader = new FileReader();
  reader.onload = function(event) {
    const img = new Image();
    img.onload = function() {
      const canvas = document.createElement("canvas");
      const maxWidth = 500;
      const maxHeight = 700;
      let width = img.width;
      let height = img.height;

      if (width > height && width > maxWidth) {
        height = height * (maxWidth / width);
        width = maxWidth;
      } else if (height > maxHeight) {
        width = width * (maxHeight / height);
        height = maxHeight;
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, width, height);
      callback(canvas.toDataURL("image/jpeg", 0.65));
    };
    img.src = event.target.result;
  };
  reader.readAsDataURL(file);
}

async function saveItem(title, poster, season, releaseInfo, episode, total, episodeMode, type, status, score, note, isPublic) {
  const old = editId ? items.find(i => i.id === editId) : null;
  const data = {
    title,
    poster,
    season: season || old?.season || "ซีซั่น 1",
    releaseInfo: releaseInfo || old?.releaseInfo || "",
    episode,
    total,
    episodeMode: episodeMode || old?.episodeMode || "manual",
    type,
    status,
    score,
    note,
    isPublic,
    ownerId: currentUser.uid,
    ownerName: currentUser.displayName || currentUser.email,
    ownerEmail: currentUser.email,
    date: old?.date || new Date().toLocaleDateString("th-TH"),
    createdMs: old?.createdMs || Date.now(),
    updatedAtMs: Date.now(),
    favorite: old?.favorite || false
  };

  const returnTitle = editReturnTitle;
  let savedItemId = null;
  let savedItemTitle = title;

  // v15.0: เขียนลง local ทันที (local-first) + ต่อคิว sync ขึ้น Firestore แบบ batch
  // แทนที่จะ await updateDoc/addDoc ตรง ๆ ทุกครั้ง ทำให้บันทึกได้ทันทีแม้ออฟไลน์
  if (editId) {
    savedItemId = editId;
    const changedFields = old ? Object.keys(data).filter(k => JSON.stringify(data[k]) !== JSON.stringify(old[k]) && k !== "updatedAtMs") : [];
    // v15.0: poster เป็น base64 (มักเป็น field ที่หนักที่สุด) ถ้าไม่เปลี่ยนจากเดิม ไม่ต้อง
    // ส่งซ้ำขึ้น Firestore ทุกครั้งที่แก้แค่ episode/note/score ฯลฯ (เก็บเต็มไว้แค่ใน local)
    const firestorePatch = { ...data };
    if (old && firestorePatch.poster === old.poster) delete firestorePatch.poster;
    WJBSync.queueSet("watchItems", editId, firestorePatch);
    const idx = items.findIndex(i => i.id === editId);
    if (idx > -1) items[idx] = { ...items[idx], ...data };
    logActivity("update_item", { itemId: editId, itemTitle: title, changedFields });
    editId = null;
    editReturnTitle = null;
    $("saveBtn").innerText = "+ เพิ่มรายการ";
    if ($("cancelEditBtn")) $("cancelEditBtn").style.display = "none";
  } else {
    const newId = WJBSync.newDocId("watchItems");
    WJBSync.queueSet("watchItems", newId, data);
    items.unshift({ id: newId, ...data });
    savedItemId = newId;
    logActivity("add_item", { itemId: newId, itemTitle: title, type, status, season: data.season });
  }
  WJBSync.setLocalItems(currentUser.uid, items);

  clearForm();
  $("saveBtn").innerText = "+ เพิ่มรายการ";
  clearDraft();
  if ($("search")) $("search").value = "";
  items.sort((a, b) => (b.createdMs || 0) - (a.createdMs || 0));
  showItems();
  wjbCheckAnimeAiringUpdates();

  if (savedItemId) {
    focusSavedItem(savedItemId, returnTitle || savedItemTitle, true);
  } else if (returnTitle) {
    setTimeout(() => {
      openSeasonDetail(encodeURIComponent(returnTitle));
    }, 150);
  }
}

function focusSavedItem(itemId, title, openDetail = true) {
  pendingFocusItemId = itemId;
  pendingFocusItemTitle = title;

  if (currentTab !== "my") {
    currentTab = "my";
    if ($("myTab")) $("myTab").className = "";
    if ($("exploreTab")) $("exploreTab").className = "gray";
    if ($("formBox")) $("formBox").style.display = "grid";
    if ($("backupBox")) $("backupBox").style.display = "grid";
  }

  showItems();

  setTimeout(() => {
    const card = document.querySelector(".group-card.just-added-card");
    if (card) {
      card.scrollIntoView({ behavior: "smooth", block: "center" });
    }

    if (openDetail && title) {
      setTimeout(() => {
        openSeasonDetail(encodeURIComponent(title));
        setTimeout(() => {
          const row = document.getElementById(`season-row-${itemId}`);
          if (row) row.scrollIntoView({ behavior: "smooth", block: "center" });
        }, 180);
      }, 550);
    }

    setTimeout(() => {
      pendingFocusItemId = null;
      pendingFocusItemTitle = null;
      document.querySelectorAll(".just-added-card").forEach(el => el.classList.remove("just-added-card"));
    }, 9000);
  }, 180);
}

function showItems() {
  setBulkDeleteUI();
  const list = $("list");
  const search = $("search").value.toLowerCase();
  updateStats();

  const categories = ["กำลังดู", "ดูจบแล้ว", "ดองไว้", "อยากดู"];
  let fullHTML = "";

  // v15.0 fix: จัดกลุ่มตามชื่อเรื่องก่อน (รวมทุกซีซั่นของเรื่องเดียวกัน แม้จะมีสถานะ
  // ต่างกันคนละซีซั่น) แล้วค่อยตัดสินใจว่าการ์ดนั้นควรอยู่หมวดไหนจาก "สถานะของซีซั่น
  // ปัจจุบัน" (ตัวเดียวกับที่การ์ดใช้แสดงผลอยู่แล้วใน getCurrentSeason/getSmartStatus)
  // เดิมโค้ด filter ตามสถานะรายชิ้นก่อนแล้วค่อย group ทีหลัง ทำให้เรื่องเดียวกันที่มี
  // ซีซั่นคนละสถานะ (เช่น S1 ดูจบแล้ว, S2 กำลังดู) ถูกสร้างเป็นคนละการ์ดคนละหมวด
  const searchedItems = items.filter(item => (item.title || "").toLowerCase().includes(search));
  const allGroups = groupItemsByTitle(searchedItems);

  categories.forEach(category => {
    let groupsInCategory = allGroups.filter(group => getSmartStatus(getCurrentSeason(group)) === category);
    groupsInCategory.sort((a, b) => Number(b.favorite) - Number(a.favorite));
    if (groupsInCategory.length === 0) return;

    let html = `<section class="category"><h2>${category}</h2><div class="grid">`;
    groupsInCategory.forEach(group => html += groupCardHTML(group, "my"));
    html += `</div></section>`;
    fullHTML += html;
  });

  // v14.9: เขียน DOM ครั้งเดียวหลัง build string ครบ (เดิมใช้ innerHTML += ในลูป
  // ทำให้ต้อง serialize + re-parse DOM ทั้งก้อนซ้ำทุกหมวด และหนักขึ้นเรื่อยๆ ตามจำนวนเรื่อง
  // เพราะช่องค้นหาเรียกฟังก์ชันนี้ทุกตัวอักษรที่พิมพ์ผ่าน oninput="renderCurrentTab()")
  list.innerHTML = fullHTML || `<div class="empty">ยังไม่มีรายการในลิสต์ของคุณ</div>`;
}


function groupItemsByTitle(sourceItems){
  const map = new Map();
  sourceItems.forEach(item => {
    // v15.0 fix: collapse internal whitespace too (not just trim), so e.g.
    // "วันพีซ  ซีซั่น 2" (double space) and "วันพีซ ซีซั่น 2" merge into the
    // same card instead of silently becoming two separate groups.
    const key = (item.title || "").trim().toLowerCase().replace(/\s+/g, " ");
    if(!map.has(key)){
      map.set(key, {
        title: item.title || "ไม่ระบุชื่อ",
        type: item.type || "อนิเมะ",
        poster: item.poster || "",
        items: [],
        favorite: false,
        latest: item
      });
    }
    const group = map.get(key);
    group.items.push(item);
    if(item.favorite) group.favorite = true;
    if((item.createdMs || 0) > (group.latest?.createdMs || 0)) group.latest = item;
    if(!group.poster && item.poster) group.poster = item.poster;
  });
  return Array.from(map.values()).sort((a,b)=>(b.latest.createdMs||0)-(a.latest.createdMs||0));
}


function isReleaseLikeSeasonName(value){
  const text = String(value || "").trim().toLowerCase();
  if(!text) return false;
  return /^(winter|spring|summer|fall|autumn)\s+\d{4}$/.test(text)
    || /^ปี\s*\d{4}$/.test(text)
    || /^\d{4}$/.test(text)
    || /^เริ่มฉาย\s*\d{4}$/.test(text);
}

function getSeasonDisplayName(item){
  const raw = item?.season || "";
  if(isReleaseLikeSeasonName(raw)) return "ซีซั่น 1";
  return raw || "ซีซั่น 1";
}

// v14.6: ใช้เรียงลำดับซีซั่นตามหมายเลข (1,2,3,4...) แทนลำดับที่เพิ่มเข้ามา
function getSeasonSortNumber(item){
  const name = getSeasonDisplayName(item);
  const match = String(name).match(/\d+(\.\d+)?/);
  return match ? Number(match[0]) : Number.MAX_SAFE_INTEGER;
}

function formatReleaseInfo(value){
  const raw = String(value || "").trim();
  if(!raw) return "";
  const m = raw.toLowerCase().match(/^(winter|spring|summer|fall|autumn)\s+(\d{4})$/);
  if(m){
    const seasonMap = {
      winter: "ฤดูหนาว",
      spring: "ฤดูใบไม้ผลิ",
      summer: "ฤดูร้อน",
      fall: "ฤดูใบไม้ร่วง",
      autumn: "ฤดูใบไม้ร่วง"
    };
    return `${seasonMap[m[1]] || raw} ${m[2]}`;
  }
  return raw.replace(/^ปี\s*/i, "ปี ").replace(/^เริ่มฉาย\s*/i, "ปี ");
}

function getReleaseInfo(item){
  if(!item) return "";
  const value = item.releaseInfo || (isReleaseLikeSeasonName(item.season) ? item.season : "");
  return formatReleaseInfo(value);
}

function getEpisodeNumbers(item){
  const episode = Number(item?.episode) || 0;
  const total = Number(item?.total) || 0;
  return { episode, total };
}

function getProgressPercent(item){
  if(!item || item.type === "หนัง" || item.episodeMode === "ongoing") return null;
  const { episode, total } = getEpisodeNumbers(item);
  if(total <= 0) return null;
  return Math.min(Math.round((episode / total) * 100), 100);
}

function isSeasonCompleted(item){
  if(!item) return false;
  if(item.type === "หนัง") return item.status === "ดูจบแล้ว";

  const { episode, total } = getEpisodeNumbers(item);
  if(item.episodeMode !== "ongoing" && total > 0){
    return episode >= total;
  }

  return item.status === "ดูจบแล้ว";
}

function getSmartStatus(item){
  if(!item) return "ไม่ระบุ";
  if(isSeasonCompleted(item)) return "ดูจบแล้ว";
  if(item.status === "ดองไว้" || item.status === "อยากดู") return item.status;

  const { episode, total } = getEpisodeNumbers(item);
  if(item.type !== "หนัง" && episode > 0 && (!total || episode < total)){
    return "กำลังดู";
  }

  return item.status || "กำลังดู";
}

function getStatusIcon(status){
  if(status === "ดูจบแล้ว") return "✅";
  if(status === "กำลังดู") return "⏳";
  if(status === "ดองไว้") return "🕒";
  if(status === "อยากดู") return "⭐";
  return "📌";
}

function getCurrentSeason(group){
  const list = [...(group.items || [])].sort((a,b)=>(a.createdMs||0)-(b.createdMs||0));
  return list.find(i => getSmartStatus(i) === "กำลังดู")
    || list.find(i => !isSeasonCompleted(i) && (Number(i.episode) || 0) > 0)
    || list.find(i => getSmartStatus(i) === "ดองไว้")
    || list.find(i => getSmartStatus(i) === "อยากดู")
    || group.latest
    || list[0];
}



function getGroupDisplayText(group){
  const type = group.type || "";
  const allRelated = items.filter(i =>
    (i.title || "").trim().toLowerCase() ===
    (group.title || "").trim().toLowerCase()
  );
  const count = allRelated.length || (group.items || []).length;

  if(type === "หนัง"){
    return count > 1 ? `🎬 ภาพยนตร์ ${count} รายการ` : "🎬 ภาพยนตร์เดี่ยว";
  }

  return count <= 1 ? "📚 1 ซีซั่น/ภาค" : `📚 ทั้งหมด: ${count} ซีซั่น/ภาค`;
}

function getGroupDoneText(group){
  const type = group.type || "";
  const count = (group.items || []).length;
  const done = (group.items || []).filter(isSeasonCompleted).length;

  if(type === "หนัง"){
    return done >= count ? "✅ ดูจบแล้ว" : "⏳ ยังดูไม่จบ";
  }

  return `✅ ดูจบ: ${done} / ${count}`;
}

function getAverageScore(group){
  const scores = (group.items || [])
    .map(i => Number(i.score))
    .filter(n => !Number.isNaN(n) && n > 0);
  if(scores.length === 0) return null;
  const avg = scores.reduce((sum, n) => sum + n, 0) / scores.length;
  return Math.round(avg * 10) / 10;
}

function groupCardHTML(group, mode){
  const latest = group.latest || group.items[0];
  const allRelatedItems = items.filter(i =>
    (i.title || "").trim().toLowerCase() ===
    (group.title || "").trim().toLowerCase()
  );
  const currentSeason = getCurrentSeason({ ...group, items: allRelatedItems.length ? allRelatedItems : group.items });
  const image = group.poster || latest.poster || "https://via.placeholder.com/400x600?text=No+Poster";
  const seasonCount = allRelatedItems.length || group.items.length;
  const doneCount = (allRelatedItems.length ? allRelatedItems : group.items).filter(isSeasonCompleted).length;
  const progressText = buildProgressText(currentSeason);
  const currentStatus = getSmartStatus(currentSeason);
  const currentSeasonName = getSeasonDisplayName(currentSeason);
  const percent = getProgressPercent(currentSeason);
  const avgScore = getAverageScore(group);
  const overallText = doneCount >= seasonCount
    ? "✅ ดูจบครบทุกซีซั่น/ภาคแล้ว"
    : `${getStatusIcon(currentStatus)} ${currentStatus}: ${escapeText(currentSeasonName)}`;
  const groupItems = allRelatedItems.length ? allRelatedItems : group.items;
  const shouldHighlight = pendingFocusItemId && groupItems.some(i => i.id === pendingFocusItemId);
  const groupIds = groupItems.map(i => i.id).filter(Boolean);
  const selectedAll = groupIds.length && groupIds.every(id => bulkDeleteSelectedIds.has(id));
  const bulkIds = encodeURIComponent(JSON.stringify(groupIds));
  const bulkSelectHTML = bulkDeleteMode ? `
    <label class="bulk-select-card">
      <input type="checkbox" ${selectedAll ? "checked" : ""} onchange="toggleBulkGroup('${bulkIds}', this.checked)">
      เลือกลบทั้งเรื่อง (${groupIds.length} รายการ)
    </label>` : "";

  // v14.7: แสดงสถานะ public/private ของทั้งเรื่อง + ปุ่มสลับทีเดียวทุกซีซั่น
  const publicCountInGroup = groupItems.filter(i => i.isPublic !== false).length;
  const groupAllPublic = mode === "my" && groupItems.length > 0 && publicCountInGroup === groupItems.length;
  const groupAllPrivate = mode === "my" && publicCountInGroup === 0;
  const groupPrivacyText = groupAllPublic
    ? "🌍 สาธารณะทั้งหมด"
    : groupAllPrivate
      ? "🔒 ส่วนตัวทั้งหมด"
      : `🌓 ปนกัน (สาธารณะ ${publicCountInGroup}/${groupItems.length} ซีซั่น)`;

  return `
    <div class="card group-card${shouldHighlight ? " just-added-card" : ""}${selectedAll ? " bulk-selected-card" : ""}" data-bulk-ids="${bulkIds}" data-bulk-title="${encodeURIComponent(group.title || "")}">
      ${bulkSelectHTML}
      <img class="poster" src="${escapeText(image)}" alt="โปสเตอร์ ${escapeText(group.title || '')}">
      <div class="info">
        <span class="badge">${group.type}</span>
        <h2>${group.favorite ? "💙 " : ""}${escapeText(group.title)}</h2>
        <p>${getGroupDisplayText(group)}</p>
        <p>${getGroupDoneText(group)}</p>
        <p>${overallText}</p>
        <p>${progressText}</p>
        ${getReleaseInfo(currentSeason) ? `<p>🗓️ เริ่มฉาย: ${escapeText(getReleaseInfo(currentSeason))}</p>` : ""}
        ${percent === null ? "" : `<div class="progress-box"><div class="progress" style="width:${percent}%"></div></div><p>📊 ความคืบหน้า: ${percent}%</p>`}
        <p>⭐ คะแนนเฉลี่ย: ${avgScore === null ? "-" : avgScore}/10</p>
        ${mode === "my" ? `<p>${groupPrivacyText}</p>` : ""}
        <div class="actions wjb-group-actions">
          <button onclick="openSeasonDetail('${encodeURIComponent(group.title)}')">ดูรายละเอียด</button>
          <button class="favorite wjb-favorite-btn ${group.favorite ? 'active' : ''}" onclick="toggleGroupFavorite('${encodeURIComponent(group.title)}')" aria-label="${group.favorite ? 'ลบจากรายการโปรด' : 'เพิ่มเป็นรายการโปรด'}">${group.favorite ? '❤️ รายการโปรด' : '🤍 เพิ่มโปรด'}</button>
          <button class="gray" onclick="editItem('${currentSeason.id}', '${encodeURIComponent(group.title)}')">แก้ไขซีซั่นนี้</button>
          ${mode === "my" ? `<button class="gray" onclick="toggleGroupPublic('${encodeURIComponent(group.title)}', event)">${groupAllPublic ? "🔒 ตั้งส่วนตัวทั้งหมด" : "🌍 ตั้งสาธารณะทั้งหมด"}</button>` : ""}
        </div>
      </div>
    </div>
  `;
}

function buildProgressText(item){
  if(!item) return "ยังไม่มีข้อมูล";
  if(item.type === "หนัง") return "🎬 หนัง";
  if(item.episodeMode === "ongoing"){
    return `📺 ดูถึงตอนที่ ${item.episode || "-"}\n🔄 กำลังฉาย`;
  }
  const ep = item.episode || "-";
  const total = item.total || "-";
  return `📺 ดูถึง: ${ep} / ${total} ตอน`;
}


function seasonDetailMetaHTML(item, status, percent){
  const lines = [
    `${getStatusIcon(status)} ${escapeText(status)}`,
    escapeText(buildProgressText(item)).replace(/\n/g, "<br>"),
  ];
  if(percent !== null) lines.push(`📊 ${percent}%`);
  if(getReleaseInfo(item)) lines.push(`🗓️ เริ่มฉาย: ${escapeText(getReleaseInfo(item))}`);
  return lines.filter(Boolean).map(line => `<p>${line}</p>`).join("");
}

window.openSeasonDetail = function(encodedTitle){
  const title = decodeURIComponent(encodedTitle);
  const list = $("seasonDetailList");
  $("seasonDetailTitle").innerText = title;
  const related = items
    .filter(i => (i.title || "").trim().toLowerCase() === title.trim().toLowerCase())
    .sort((a,b) => {
      const numA = getSeasonSortNumber(a);
      const numB = getSeasonSortNumber(b);
      if(numA !== numB) return numA - numB;
      return (a.createdMs||0) - (b.createdMs||0);
    });

  const detailType = related[0]?.type || "";
  const summaryText = detailType === "หนัง"
    ? (related.length > 1 ? `🎬 ภาพยนตร์ ${related.length} รายการ` : "🎬 ภาพยนตร์เดี่ยว")
    : `📚 ทั้งหมด ${related.length} ซีซั่น/ภาค`;

  list.innerHTML = `<div class="season-summary">${summaryText}</div>`;

  list.innerHTML += related.map(item => {
    const status = getSmartStatus(item);
    const percent = getProgressPercent(item);
    const isFocusedItem = pendingFocusItemId && item.id === pendingFocusItemId;
    return `
      <div id="season-row-${item.id}" class="season-row status-${status}${isFocusedItem ? " just-added-card" : ""}">
        <div class="season-main">
          <b>${escapeText(getSeasonDisplayName(item))}${isFocusedItem ? " <span class='new-item-badge'>รายการใหม่/ล่าสุด</span>" : ""}</b>
          ${seasonDetailMetaHTML(item, status, percent)}
          ${percent === null ? "" : `<div class="progress-box season-progress"><div class="progress" style="width:${percent}%"></div></div>`}
        </div>
        <div class="season-actions">
          <button class="favorite wjb-favorite-btn ${item.favorite ? 'active' : ''}" onclick="toggleFavorite('${item.id}')" aria-label="${item.favorite ? 'ลบจากรายการโปรด' : 'เพิ่มเป็นรายการโปรด'}">${item.favorite ? '❤️ โปรด' : '🤍 โปรด'}</button>
          <button class="gray" onclick="closeSeasonDetail(); editItem('${item.id}', '${encodeURIComponent(title)}')">แก้ไข</button>
          <button class="danger" onclick="deleteSeasonItem('${item.id}', '${encodeURIComponent(title)}', event)">ลบ</button>
        </div>
      </div>
    `;
  }).join("");

  list.innerHTML += `
    <div class="season-tools">
      <button onclick="searchRelatedSeasonsOnline('${encodeURIComponent(title)}')">🌐 ค้นหาซีซั่นจากออนไลน์</button>
      <button onclick="startAddSeason('${encodeURIComponent(title)}')">✍️ สร้างซีซั่นเอง</button>
      <div id="relatedSeasonResults" class="related-season-results" style="display:none"></div>
    </div>
  `;

  $("seasonDetailModal").style.display = "flex";
  document.querySelectorAll(".menu-toggle").forEach(btn => btn.style.display = "none");
};


window.searchRelatedSeasonsOnline = async function(encodedTitle){
  const title = decodeURIComponent(encodedTitle);
  const box = $("relatedSeasonResults");
  if(!box) return;

  box.style.display = "block";
  box.innerHTML = `<div class="smart-loading">กำลังค้นหาซีซั่น/ภาคที่เกี่ยวข้องกับ "${escapeText(title)}"...</div>`;

  try{
    const results = await Promise.allSettled([
      searchTmdbMulti(title),
      searchAnimeJikan(title),
      searchTvMaze(title),
      searchITunesMovie(title)
    ]);

    const merged = results
      .filter(r => r.status === "fulfilled")
      .flatMap(r => r.value)
      .filter(Boolean)
      .map(normalizeSmartSeason);

    const related = [];
    const seen = new Set();

    merged.forEach(item => {
      const name = item.title || item.season || "";
      const key = `${(name || "").toLowerCase()}-${item.source || ""}-${item.year || item.releaseInfo || ""}`;
      if(name && !seen.has(key)){
        seen.add(key);
        related.push(item);
      }
    });

    if(related.length === 0){
      box.innerHTML = `<div class="smart-empty">ยังไม่พบภาค/ซีซั่นจากออนไลน์ แต่พี่ยังเพิ่มเองได้ตามปกติ</div>`;
      return;
    }

    window.relatedSeasonResults = related.slice(0, 12);
    box.innerHTML = `
      <div class="related-title">เลือกภาค/ซีซั่นที่ต้องการเพิ่ม</div>
      ${window.relatedSeasonResults.map((item, index) => relatedSeasonHTML(item, index, title)).join("")}
    `;
  }catch(e){
    box.innerHTML = `<div class="smart-empty">ค้นหาไม่สำเร็จ ลองใหม่อีกครั้ง หรือเพิ่มเองได้ตามปกติ</div>`;
  }
};

function relatedSeasonHTML(item, index, parentTitle){
  const poster = item.poster || "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='100' height='140'><rect width='100%' height='100%' fill='%23182736'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' fill='%23ffffff' font-size='18'>WJB</text></svg>";
  const release = item.releaseInfo || item.year || "";
  const seasonName = getRelatedSeasonName(item, parentTitle);
  return `
    <div class="related-season-row">
      <img src="${escapeText(poster)}" alt="">
      <div class="related-info">
        <b>${escapeText(seasonName)}</b>
        <p>${escapeText(item.type || "อื่นๆ")}${release ? ` · 🗓️ ${escapeText(release)}` : ""} · ${escapeText(item.source || "Online")}</p>
        ${item.note ? `<p class="related-note">${escapeText(String(item.note).slice(0, 120))}</p>` : ""}
      </div>
      <button onclick="addRelatedSeason('${encodeURIComponent(parentTitle)}', ${index})">เพิ่ม</button>
    </div>
  `;
}

function getRelatedSeasonName(item, parentTitle){
  const title = (item.title || "").trim();
  const parent = (parentTitle || "").trim().toLowerCase();
  if(item.type === "หนัง" && title) return title;
  if(title && title.toLowerCase() !== parent) return title;
  return item.season || "ซีซั่น 1";
}

window.addRelatedSeason = async function(encodedParentTitle, index){
  if(!currentUser) return wjbToast("กรุณาเข้าสู่ระบบก่อน");
  const parentTitle = decodeURIComponent(encodedParentTitle);
  const item = (window.relatedSeasonResults || [])[index];
  if(!item) return;

  const seasonName = getRelatedSeasonName(item, parentTitle);
  const alreadyExists = items.some(i =>
    (i.title || "").trim().toLowerCase() === parentTitle.trim().toLowerCase() &&
    (getSeasonDisplayName(i) || "").trim().toLowerCase() === seasonName.trim().toLowerCase()
  );

  if(alreadyExists){
    wjbToast("มีซีซั่น/ภาคนี้อยู่ในลิสต์แล้ว");
    return;
  }

  const ref = await addDoc(collection(db, "watchItems"), {
    title: parentTitle,
    poster: item.poster || "",
    season: seasonName || "ซีซั่น 1",
    releaseInfo: item.releaseInfo || "",
    episode: "",
    total: item.total || "",
    episodeMode: item.total ? "manual" : "ongoing",
    type: item.type || "อนิเมะ",
    status: "อยากดู",
    score: "",
    note: item.note || `เพิ่มจากออนไลน์: ${item.source || "Online"}`,
    isPublic: true,
    ownerId: currentUser.uid,
    ownerName: currentUser.displayName || currentUser.email,
    ownerEmail: currentUser.email,
    date: new Date().toLocaleDateString("th-TH"),
    createdMs: Date.now(),
    favorite: false,
    updatedAt: serverTimestamp()
  });

  await logActivity("add_related_season", { itemId: ref.id, itemTitle: parentTitle, season: seasonName, source: item.source || "Online" });
  if ($("search")) $("search").value = "";
  await loadMyItems();
  focusSavedItem(ref.id, parentTitle, true);
};


window.startAddSeason = function(encodedTitle){
  const title = decodeURIComponent(encodedTitle);
  closeSeasonDetail();

  const related = items
    .filter(i => (i.title || "").trim().toLowerCase() === title.trim().toLowerCase())
    .sort((a,b)=>(b.createdMs||0)-(a.createdMs||0));

  const latestSeason = related[0] || null;

  editId = null;
  editReturnTitle = title;

  $("title").value = title;
  if ($("season")) $("season").value = "";
  if ($("releaseInfo")) $("releaseInfo").value = "";
  $("episode").value = "";
  $("total").value = "";

  // คัดลอกรูปปกอัตโนมัติจากซีซั่นล่าสุด
  smartPoster = latestSeason?.poster || "";
  $("score").value = "";
  $("note").value = "";
  $("isPublic").checked = true;
  if ($("episodeMode")) $("episodeMode").value = "manual";
  $("status").value = "อยากดู";

  $("saveBtn").innerText = "+ เพิ่มซีซั่น/ภาค";
  if ($("cancelEditBtn")) $("cancelEditBtn").style.display = "block";

  toggleEpisodeFields();
  backToAdd();

  setTimeout(() => {
    scrollEditFormToDetails(true);
  }, 250);
};

window.deleteSeasonItem = async function(id, encodedReturnTitle = null, evt = null){
  const returnTitle = encodedReturnTitle ? decodeURIComponent(encodedReturnTitle) : null;
  const item = items.find(i => i.id === id);
  const label = item ? `${item.title || ""} ${getSeasonDisplayName(item) || ""}`.trim() : "รายการนี้";

  if(!(await wjbConfirm(`ต้องการลบ "${label}" ใช่ไหม?`, {danger:true, okText:"ลบ"}))) return;

  const done = window.wjbBusy ? window.wjbBusy(evt?.currentTarget, "กำลังลบ...") : () => {};
  try{
    logActivity("delete_item", { itemId:id, itemTitle: label });
    // v15.0: ลบใน local ทันที + ต่อคิวลบขึ้น Firestore แบบ batch (ไม่ await เน็ตตรง ๆ)
    WJBSync.queueDelete("watchItems", id);
    items = items.filter(i => i.id !== id);
    WJBSync.setLocalItems(currentUser.uid, items);
    showItems();

    if(returnTitle){
      const stillHasItems = items.some(i => (i.title || "").trim().toLowerCase() === returnTitle.trim().toLowerCase());
      if(stillHasItems){
        setTimeout(() => openSeasonDetail(encodeURIComponent(returnTitle)), 150);
      }else{
        closeSeasonDetail();
      }
    }
  } finally {
    done();
  }
};

window.closeSeasonDetail = function(){
  $("seasonDetailModal").style.display = "none";
  document.querySelectorAll(".menu-toggle").forEach(btn => btn.style.display = "");
};

function showPublicItems() {
  setBulkDeleteUI();
  const list = $("list");
  const search = $("search").value.toLowerCase();
  const filtered = publicItems.filter(item => item.title.toLowerCase().includes(search));
  const grouped = groupPublicItemsByTitleOwner(filtered);

  list.innerHTML = `<section class="category"><h2>🌍 รายการสาธารณะจากคนอื่น</h2><div class="grid">${grouped.map(group => publicGroupCardHTML(group)).join("")}</div></section>`;

  if (grouped.length === 0) {
    list.innerHTML = `<div class="empty">ยังไม่มีรายการสาธารณะให้สำรวจ</div>`;
  }
}

// Groups public items by title AND owner, so multiple seasons of the same
// title from the SAME uploader become one card, while two different users
// who happen to add the same title are still kept as separate cards.
function groupPublicItemsByTitleOwner(sourceItems){
  const map = new Map();
  sourceItems.forEach(item => {
    const key = `${(item.title || "").trim().toLowerCase()}::${item.ownerId || ""}`;
    if(!map.has(key)){
      map.set(key, {
        title: item.title || "ไม่ระบุชื่อ",
        type: item.type || "อนิเมะ",
        poster: item.poster || "",
        items: [],
        favorite: false,
        latest: item
      });
    }
    const group = map.get(key);
    group.items.push(item);
    if(item.favorite) group.favorite = true;
    if((item.createdMs || 0) > (group.latest?.createdMs || 0)) group.latest = item;
    if(!group.poster && item.poster) group.poster = item.poster;
  });
  return Array.from(map.values()).sort((a,b)=>(b.latest.createdMs||0)-(a.latest.createdMs||0));
}

function publicGroupDisplayText(group){
  const type = group.type || "";
  const count = (group.items || []).length;
  if(type === "หนัง"){
    return count > 1 ? `🎬 ภาพยนตร์ ${count} รายการ` : "🎬 ภาพยนตร์เดี่ยว";
  }
  return count <= 1 ? "📚 1 ซีซั่น/ภาค" : `📚 ทั้งหมด: ${count} ซีซั่น/ภาค`;
}

// v14.4: กันการเพิ่มเรื่อง/ซีซั่นเดิมซ้ำเข้าลิสต์ของฉัน
function isSourceAlreadyInMyList(source){
  if(!source) return false;
  const title = String(source.title || "").trim().toLowerCase();
  const season = String(source.season || "").trim().toLowerCase();
  const type = source.type || "";
  return (items || []).some(existing =>
    existing.copiedFrom === source.id ||
    (
      String(existing.title || "").trim().toLowerCase() === title &&
      String(existing.season || "").trim().toLowerCase() === season &&
      (!type || existing.type === type)
    )
  );
}

function copyToMyListButtonHTML(source){
  if(isSourceAlreadyInMyList(source)){
    return `<button class="trend-added-btn" disabled>✅ เพิ่มแล้ว</button>`;
  }
  return `<button onclick="copyToMyList('${source.id}')">+ เพิ่มเข้าลิสต์ฉัน</button>`;
}

function publicSeasonRowHTML(item){
  const status = getSmartStatus(item);
  const percent = getProgressPercent(item);
  return `
    <div class="season-row status-${status}">
      <div class="season-main">
        <b>${escapeText(getSeasonDisplayName(item))}</b>
        ${seasonDetailMetaHTML(item, status, percent)}
        ${percent === null ? "" : `<div class="progress-box season-progress"><div class="progress" style="width:${percent}%"></div></div>`}
      </div>
      <div class="season-actions">
        ${copyToMyListButtonHTML(item)}
      </div>
    </div>
  `;
}

function publicGroupCardHTML(group){
  const latest = group.latest || group.items[0];
  const image = group.poster || latest.poster || "https://via.placeholder.com/400x600?text=No+Poster";
  const seasonCount = group.items.length;
  const currentSeason = getCurrentSeason(group);
  const progressText = buildProgressText(currentSeason);
  const currentStatus = getSmartStatus(currentSeason);
  const currentSeasonName = getSeasonDisplayName(currentSeason);
  const percent = getProgressPercent(currentSeason);
  const avgScore = getAverageScore(group);
  const doneCount = group.items.filter(isSeasonCompleted).length;
  const overallText = doneCount >= seasonCount
    ? "✅ ดูจบครบทุกซีซั่น/ภาคแล้ว"
    : `${getStatusIcon(currentStatus)} ${currentStatus}: ${escapeText(currentSeasonName)}`;
  const ownerName = escapeText(latest.ownerName || "ไม่ระบุ");
  const seasonRows = [...group.items]
    .sort((a,b)=>(a.createdMs||0)-(b.createdMs||0))
    .map(publicSeasonRowHTML)
    .join("");

  return `
    <div class="card group-card">
      <img class="poster" src="${escapeText(image)}" alt="โปสเตอร์ ${escapeText(group.title || '')}">
      <div class="info">
        <span class="badge">${group.type}</span>
        <span class="owner">โดย ${ownerName}</span>
        <h2>${group.favorite ? "💙 " : ""}${escapeText(group.title)}</h2>
        <p>${publicGroupDisplayText(group)}</p>
        <p>✅ ดูจบ: ${doneCount} / ${seasonCount}</p>
        <p>${overallText}</p>
        <p>${progressText}</p>
        ${getReleaseInfo(currentSeason) ? `<p>🗓️ เริ่มฉาย: ${escapeText(getReleaseInfo(currentSeason))}</p>` : ""}
        ${percent === null ? "" : `<div class="progress-box"><div class="progress" style="width:${percent}%"></div></div><p>📊 ความคืบหน้า: ${percent}%</p>`}
        <p>⭐ คะแนนเฉลี่ย: ${avgScore === null ? "-" : avgScore}/10</p>
        ${seasonCount > 1 ? `
        <details class="public-season-list">
          <summary>ดูทุกซีซั่น (${seasonCount})</summary>
          ${seasonRows}
        </details>` : ""}
        <div class="actions">
          ${copyToMyListButtonHTML(currentSeason)}
          <button class="gray" onclick="openPublicProfile('${escAttrJs(latest.ownerId || "")}', '${escAttrJs(ownerName)}')">ดูเจ้าของ</button>
        </div>
      </div>
    </div>
  `;
}

window.openTrailerSearch = function(title){
  const query = `${title || ""} ตัวอย่าง trailer`.trim();
  const url = "https://www.youtube.com/results?search_query=" + encodeURIComponent(query);
  window.open(url, "_blank", "noopener,noreferrer");
};

function escapeText(text) {
  return String(text).replace(/[&<>"]/g, (m) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;"
  }[m]));
}

// ใช้เมื่อต้องแทรกข้อความ (title/ชื่อผู้ใช้ ฯลฯ) ลงใน onclick="fn('...')"
// ต้อง escape ทั้งชั้น JS string (backslash, single quote, ขึ้นบรรทัดใหม่)
// และชั้น HTML attribute (& < > ") เพราะ onclick อยู่ใน attribute ที่ครอบด้วย double quote
function escAttrJs(text){
  return String(text ?? "")
    .replace(/\\/g, "\\\\")
    .replace(/'/g, "\\'")
    .replace(/\n/g, "\\n")
    .replace(/\r/g, "\\r")
    .replace(/[&<>"]/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[m]));
}

function updateStats() {
  if (typeof groupItemsByTitle !== 'function' || !items) return;
  const groups = groupItemsByTitle(items);

  if ($("totalCount")) $("totalCount").innerText = groups.length;
  if ($("watchingCount")) {
    $("watchingCount").innerText = groups.filter(g =>
      g.items && g.items.some(i => typeof getSmartStatus === 'function' && getSmartStatus(i) === "กำลังดู")
    ).length;
  }
  if ($("doneCount")) {
    $("doneCount").innerText = groups.filter(g =>
      g.items && g.items.some(i => typeof isSeasonCompleted === 'function' && isSeasonCompleted(i))
    ).length;
  }
  if ($("favCount")) $("favCount").innerText = groups.filter(g => g.favorite).length;
  if ($("pendingCount")) {
    $("pendingCount").innerText = groups.filter(g =>
      g.items && g.items.some(i => typeof getSmartStatus === 'function' && getSmartStatus(i) === "ดองไว้")
    ).length;
  }
  if ($("wishCount")) {
    $("wishCount").innerText = groups.filter(g =>
      g.items && g.items.some(i => typeof getSmartStatus === 'function' && getSmartStatus(i) === "อยากดู")
    ).length;
  }
}



// v8.8: when editing a season/item, jump directly to the detail fields instead of the top search/title area.
function scrollEditFormToDetails(focusSeason = false){
  const target = document.getElementById("wjbFormDetailsStart") || document.getElementById("season") || document.getElementById("releaseInfo") || document.getElementById("formBox");
  if(!target) return;
  try{
    target.scrollIntoView({ behavior:"smooth", block:"start" });
  }catch(_e){
    target.scrollIntoView();
  }
  setTimeout(() => {
    const seasonInput = document.getElementById("season");
    if(seasonInput && (focusSeason || window.editId)){
      try{ seasonInput.focus({ preventScroll:true }); }catch(_e){ seasonInput.focus(); }
    }
  }, 260);
}

window.editItem = function(id, encodedReturnTitle = null) {
  editReturnTitle = encodedReturnTitle ? decodeURIComponent(encodedReturnTitle) : null;
  const item = items.find(i => i.id === id);
  if (!item) return;

  $("title").value = item.title || "";
  if ($("season")) $("season").value = getSeasonDisplayName(item);
  if ($("releaseInfo")) $("releaseInfo").value = getReleaseInfo(item);
  $("episode").value = item.episode || "";
  $("total").value = item.total || "";
  $("type").value = item.type || "อนิเมะ";
  $("status").value = item.status || "กำลังดู";
  $("score").value = item.score || "";
  $("note").value = item.note || "";
  $("isPublic").checked = item.isPublic !== false;
  if ($("episodeMode")) $("episodeMode").value = item.episodeMode || (item.total ? "manual" : "ongoing");
  toggleEpisodeFields();

  editId = id;
  $("saveBtn").innerText = "บันทึกการแก้ไข";
  if ($("cancelEditBtn")) $("cancelEditBtn").style.display = "block";

  backToAdd({ keepScroll: true });
  setTimeout(() => {
    scrollEditFormToDetails();
  }, 180);
};

window.toggleGroupFavorite = async function(encodedTitle){
  const title = decodeURIComponent(encodedTitle);
  const groupItems = items.filter(i => (i.title || "").trim().toLowerCase() === title.trim().toLowerCase());
  if(!groupItems.length) return;

  // v14.10: เดิมปุ่มโปรดของการ์ดกลุ่มยิง toggleFavorite(currentSeason.id) ซึ่ง currentSeason
  // คำนวณจากซีซั่นทั้งหมดของเรื่องนั้น (ไม่ใช่แค่ซีซั่นในหมวดสถานะที่การ์ดนี้กำลังแสดง) เลยมีโอกาส
  // ได้ id ของซีซั่นอื่นที่ไม่ตรงกับการ์ดที่ผู้ใช้กำลังกด (เช่น การ์ดที่เพิ่งสร้างซีซั่นเอง สถานะ "อยากดู"
  // แต่ currentSeason ดันชี้ไปซีซั่นที่ "กำลังดู" อยู่แทน) ทำให้กดแล้วเด้ง toast ว่าเพิ่มแล้ว
  // แต่หัวใจไม่ขึ้นบนการ์ดที่กดจริง ๆ ตอนนี้เปลี่ยนให้ปุ่มโปรดทำงานกับ "ทั้งเรื่อง" แทน
  const nextFavorite = !groupItems.some(i => i.favorite);

  // v15.0: อัปเดต local ทันที + ต่อคิว batch แทนยิง updateDoc ทีละตัว
  for(const item of groupItems){
    if(!!item.favorite === nextFavorite) continue;
    const patch = { favorite: nextFavorite, updatedAtMs: Date.now() };
    WJBSync.queueUpdate("watchItems", item.id, patch);
    const idx = items.findIndex(i => i.id === item.id);
    if (idx > -1) items[idx] = { ...items[idx], ...patch };
  }
  WJBSync.setLocalItems(currentUser.uid, items);
  logActivity("toggle_favorite", { itemTitle: title, favorite: nextFavorite, seasonCount: groupItems.length });
  if(typeof window.wjbFavoriteToast === "function"){
    window.wjbFavoriteToast(nextFavorite ? `❤️ เพิ่ม ${title} ในรายการโปรดแล้ว` : `🤍 นำ ${title} ออกจากรายการโปรดแล้ว`);
  }
  showItems();
};

window.toggleFavorite = async function(id) {
  const item = items.find(i => i.id === id);
  if (!item) return;
  const nextFavorite = !item.favorite;
  const patch = { favorite: nextFavorite, updatedAtMs: Date.now() };
  WJBSync.queueUpdate("watchItems", id, patch);
  Object.assign(item, patch);
  WJBSync.setLocalItems(currentUser.uid, items);
  logActivity("toggle_favorite", { itemId:id, itemTitle:item.title || "", favorite: nextFavorite });
  if(typeof window.wjbFavoriteToast === "function"){
    window.wjbFavoriteToast(nextFavorite ? `❤️ เพิ่ม ${item.title || "รายการนี้"} ในรายการโปรดแล้ว` : `🤍 นำ ${item.title || "รายการนี้"} ออกจากรายการโปรดแล้ว`);
  }
  showItems();
  const seasonModal = $("seasonDetailModal");
  if(seasonModal && seasonModal.style.display !== "none" && item.title){
    openSeasonDetail(encodeURIComponent(item.title));
  }
};

window.toggleGroupPublic = async function(encodedTitle, evt = null){
  const title = decodeURIComponent(encodedTitle);
  const groupItems = items.filter(i => (i.title || "").trim().toLowerCase() === title.trim().toLowerCase());
  if(!groupItems.length) return;

  const allPublic = groupItems.every(i => i.isPublic !== false);
  const nextPublic = !allPublic; // ถ้าตอนนี้สาธารณะครบแล้ว ให้เปลี่ยนเป็นส่วนตัวทั้งหมด ไม่งั้นเปลี่ยนเป็นสาธารณะทั้งหมด (รวมถึงกรณีปนกัน)

  if(!(await wjbConfirm(`ต้องการเปลี่ยน "${title}" ทั้งหมด ${groupItems.length} ซีซั่น/ภาค เป็น${nextPublic ? "🌍 สาธารณะ" : "🔒 ส่วนตัว"}ใช่ไหม?`))) return;

  const done = window.wjbBusy ? window.wjbBusy(evt?.currentTarget, "กำลังบันทึก...") : () => {};
  try{
    // v15.0: อัปเดต local ทันที + ต่อคิว batch แทนยิง updateDoc ทีละตัว
    for(const item of groupItems){
      if(item.isPublic === nextPublic) continue;
      const patch = { isPublic: nextPublic, updatedAtMs: Date.now() };
      WJBSync.queueUpdate("watchItems", item.id, patch);
      const idx = items.findIndex(i => i.id === item.id);
      if (idx > -1) items[idx] = { ...items[idx], ...patch };
    }
    WJBSync.setLocalItems(currentUser.uid, items);
    logActivity("toggle_group_privacy", { itemTitle: title, isPublic: nextPublic, seasonCount: groupItems.length });
    showItems();
  }catch(e){
    wjbToast("เปลี่ยนไม่สำเร็จ: " + e.message);
  } finally {
    done();
  }
};

window.copyToMyList = async function(id) {
  if (!currentUser) {
    wjbToast("กรุณาเข้าสู่ระบบก่อน");
    return;
  }

  const source = publicItems.find(i => i.id === id);
  if (!source) return;

  if (isSourceAlreadyInMyList(source)) {
    const msg = `"${source.title}${source.season ? " · " + source.season : ""}" อยู่ในลิสต์ของคุณแล้วครับ`;
    if (typeof wjbFavoriteToast === "function") {
      wjbFavoriteToast(msg);
    } else {
      wjbToast(msg);
    }
    if (currentTab === "explore") showPublicItems();
    return;
  }

  // v15.0: สร้าง id ฝั่ง client + เขียน local ทันที แล้วต่อคิว sync แบบ batch
  const newId = WJBSync.newDocId("watchItems");
  const newItemData = {
    title: source.title,
    poster: source.poster || "",
    season: source.season || "",
    releaseInfo: source.releaseInfo || "",
    episode: "",
    total: source.total || "",
    episodeMode: source.episodeMode || "manual",
    type: source.type || "อนิเมะ",
    status: "อยากดู",
    score: "",
    note: `เพิ่มมาจากลิสต์ของ ${source.ownerName || "ผู้ใช้คนอื่น"}`,
    isPublic: false,
    ownerId: currentUser.uid,
    ownerName: currentUser.displayName || currentUser.email,
    ownerEmail: currentUser.email,
    date: new Date().toLocaleDateString("th-TH"),
    createdMs: Date.now(),
    copiedFrom: id,
    favorite: false,
    updatedAtMs: Date.now()
  };
  WJBSync.queueSet("watchItems", newId, newItemData);
  items.unshift({ id: newId, ...newItemData });
  items.sort((a, b) => (b.createdMs || 0) - (a.createdMs || 0));
  WJBSync.setLocalItems(currentUser.uid, items);

  logActivity("copy_public_item", { itemId: newId, itemTitle: source.title, copiedFrom: id, sourceOwner: source.ownerName || "" });

  if (typeof wjbFavoriteToast === "function") {
    wjbFavoriteToast(`✅ เพิ่ม "${source.title}" เข้าลิสต์ของฉันแล้ว`);
  } else {
    wjbToast("เพิ่มเข้าลิสต์ของฉันแล้ว");
  }

  if (currentTab === "explore") {
    showPublicItems();
  } else {
    showItems();
  }
};

function clearForm() {
  $("title").value = "";
  $("poster").value = "";
  if ($("season")) $("season").value = "";
  if ($("releaseInfo")) $("releaseInfo").value = "";
  $("episode").value = "";
  $("total").value = "";
  $("score").value = "";
  $("note").value = "";
  $("isPublic").checked = true;
  if ($("episodeMode")) $("episodeMode").value = "manual";
  smartPoster = "";
  if ($("smartSuggestBox")) $("smartSuggestBox").style.display = "none";
  if ($("smartSuggestList")) $("smartSuggestList").innerHTML = "";
  toggleEpisodeFields();
}

window.exportData = function() {
  const data = JSON.stringify(items);
  const blob = new Blob([data], { type: "application/json" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "watch-jettaphon-backup.json";
  link.click();
};

window.importData = function() {
  const file = $("importFile").files[0];
  if (!file || !currentUser) return;

  const reader = new FileReader();
  reader.onload = async function(e) {
    try {
      const imported = JSON.parse(e.target.result);
      for (const item of imported) {
        await addDoc(collection(db, "watchItems"), {
          ...item,
          ownerId: currentUser.uid,
          ownerName: currentUser.displayName || currentUser.email,
          ownerEmail: currentUser.email,
          isPublic: item.isPublic !== false,
          createdMs: Date.now(),
          updatedAt: serverTimestamp()
        });
      }
      await logActivity("import_data", { count: Array.isArray(imported) ? imported.length : 0 });
      await loadMyItems();
      wjbToast("นำเข้าข้อมูลสำเร็จ");
    } catch (error) {
      wjbToast("ไฟล์ไม่ถูกต้อง");
    }
  };
  reader.readAsText(file);
};


window.openStatView = function(filter){
  if(!currentUser) return;
  window.statTypeFilter = "all";

  currentTab = "my";
  window.currentStatFilter = filter;
  window.statTypeFilter = "all";
  $("formBox").style.display = "none";
  $("backupBox").style.display = "none";
  $("viewBar").style.display = "grid";
  if ($("typeFilterBar")) $("typeFilterBar").style.display = "grid";

  let title = "🎬 ทั้งหมด";
  if(filter === "กำลังดู") title = "📺 กำลังดู";
  if(filter === "ดูจบแล้ว") title = "✅ ดูจบแล้ว";
  if(filter === "favorite") title = "💙 รายการโปรด";
  if(filter === "ดองไว้") title = "🕒 ดองไว้";
  if(filter === "อยากดู") title = "⭐ อยากดู";

  $("viewTitle").innerText = title;

  showFilteredStatItems(filter);
  setTimeout(() => {
    $("viewBar").scrollIntoView({ behavior: "smooth", block: "start" });
  }, 100);
};

window.backToAdd = function(options = {}){
  currentTab = "my";
  $("formBox").style.display = "grid";
  $("backupBox").style.display = "grid";
  $("viewBar").style.display = "none";
  if ($("typeFilterBar")) $("typeFilterBar").style.display = "none";
  window.statTypeFilter = "all";
  showItems();

  if(!options.keepScroll){
    setTimeout(() => {
      $("formBox").scrollIntoView({ behavior: "smooth", block: "start" });
    }, 100);
  }
};

function setTypeButtons(){
  const map = {
    all: "typeAllBtn",
    "อนิเมะ": "typeAnimeBtn",
    "หนัง": "typeMovieBtn",
    "ซีรีส์": "typeSeriesBtn",
    "อื่นๆ": "typeOtherBtn"
  };
  Object.entries(map).forEach(([type,id])=>{
    if($(id)) $(id).className = (window.statTypeFilter || "all") === type ? "" : "gray";
  });
}

window.setTypeFilter = function(type){
  window.statTypeFilter = type;
  setTypeButtons();
  showFilteredStatItems(window.currentStatFilter || "all");
};

function showFilteredStatItems(filter){
  window.currentStatFilter = filter;
  const list = $("list");
  updateMyListCompactUI();
  const search = $("search").value.toLowerCase();

  let filtered = items.filter(item => item.title.toLowerCase().includes(search));

  if(filter !== "all"){
    if(filter === "favorite"){
      filtered = filtered.filter(item => item.favorite);
    }else{
      filtered = filtered.filter(item => item.status === filter);
    }
  }

  const filteredBase = [...filtered];

  if((window.statTypeFilter || "all") !== "all"){
    filtered = filtered.filter(item => item.type === window.statTypeFilter);
  }

  filtered.sort((a, b) => (b.createdMs || 0) - (a.createdMs || 0));

  list.innerHTML = `
    <section class="category">
      <h2>${$("viewTitle").innerText}</h2>
      ${typeFilterBar(filter, filteredBase)}
      <div class="grid">
        ${groupItemsByTitle(filtered).map(group => groupCardHTML(group, "my")).join("")}
      </div>
    </section>
  `;

  if(filtered.length === 0){
    list.innerHTML = `
      <section class="category">
        <h2>${$("viewTitle").innerText}</h2>
        ${typeFilterBar(filter, filteredBase)}
        <div class="empty">ยังไม่มีรายการในหัวข้อนี้</div>
      </section>
    `;
  }
}



// Auto Save Draft V1: กันข้อมูลในฟอร์มหายเมื่อเผลอรีเฟรช/ปิดเว็บ
const WJB_DRAFT_KEY = "wjb_add_form_draft_v1";
let draftRestoreChecked = false;

function getDraftData(){
  return {
    title: $("title")?.value || "",
    season: $("season")?.value || "",
    releaseInfo: $("releaseInfo")?.value || "",
    episode: $("episode")?.value || "",
    total: $("total")?.value || "",
    episodeMode: $("episodeMode")?.value || "manual",
    type: $("type")?.value || "อนิเมะ",
    status: $("status")?.value || "กำลังดู",
    score: $("score")?.value || "",
    note: $("note")?.value || "",
    isPublic: $("isPublic") ? $("isPublic").checked : true
  };
}

function hasDraftContent(data){
  return !!(
    data.title || data.season || data.releaseInfo || data.episode ||
    data.total || data.score || data.note
  );
}

function saveDraft(){
  if(!currentUser || editId) return;
  const data = getDraftData();
  if(hasDraftContent(data)){
    wjbStorageSetJSON(WJB_DRAFT_KEY + "_" + currentUser.uid, data);
  }
}

function clearDraft(){
  if(currentUser){
    wjbStorageRemove(WJB_DRAFT_KEY + "_" + currentUser.uid);
  }
}

function restoreDraftIfNeeded(){
  if(!currentUser || draftRestoreChecked) return;
  draftRestoreChecked = true;
  const data = wjbStorageGetJSON(WJB_DRAFT_KEY + "_" + currentUser.uid, null);
  if(!data) return;

  try{
    if(!hasDraftContent(data)) return;

    setTimeout(async () => {
      if(await wjbConfirm("พบข้อมูลที่บันทึกไว้ชั่วคราว ต้องการกู้คืนหรือไม่?", {okText:"กู้คืน"})){
        if($("title")) $("title").value = data.title || "";
        if($("season")) $("season").value = data.season || "";
        if($("releaseInfo")) $("releaseInfo").value = data.releaseInfo || "";
        if($("episode")) $("episode").value = data.episode || "";
        if($("total")) $("total").value = data.total || "";
        if($("episodeMode")) $("episodeMode").value = data.episodeMode || "manual";
        if($("type")) $("type").value = data.type || "อนิเมะ";
        if($("status")) $("status").value = data.status || "กำลังดู";
        if($("score")) $("score").value = data.score || "";
        if($("note")) $("note").value = data.note || "";
        if($("isPublic")) $("isPublic").checked = data.isPublic !== false;
        toggleEpisodeFields();
        // v14.1: กดตกลงแล้วพาไปหน้ากรอกฟอร์มที่ข้อมูลถูกกู้คืนทันที ไม่ต้องเลื่อนหาเอง
        try{
          if(typeof wjbCloseAllOverlays === "function") wjbCloseAllOverlays();
          if(typeof backToAdd === "function") backToAdd();
          if(typeof wjbJumpToFormDetails === "function") wjbJumpToFormDetails("title");
        }catch(_navErr){}
      }else{
        clearDraft();
      }
    }, 500);
  }catch(e){
    clearDraft();
  }
}

function setupDraftAutosave(){
  const ids = ["title","season","releaseInfo","episode","total","episodeMode","type","status","score","note","isPublic"];
  ids.forEach(id => {
    const el = $(id);
    if(el && !el.dataset.draftBound){
      el.dataset.draftBound = "1";
      el.addEventListener("input", saveDraft);
      el.addEventListener("change", saveDraft);
    }
  });
}

// Free Search Hub v5.3: ค้นหาฟรีจาก WJB Memory, Jikan, AniList, Kitsu, TVMaze, iTunes และ Wiki แบบไม่ต้องใช้ key
window.handleSmartSearchInput = function(){
  const q = $("title") ? $("title").value.trim() : "";
  clearTimeout(smartSearchTimer);
  if($("smartSuggestCollapsed")) $("smartSuggestCollapsed").style.display = "none";
  if($("wjbTitleContinueNotice")) $("wjbTitleContinueNotice").style.display = "none";

  if(q.length < 2){
    if($("smartSuggestBox")) $("smartSuggestBox").style.display = "none";
    return;
  }

  smartSearchTimer = setTimeout(() => {
    smartSearch(q);
  }, 550);
};

async function smartSearch(keyword){
  const box = $("smartSuggestBox");
  const list = $("smartSuggestList");
  if(!box || !list) return;

  const seq = ++smartSearchSeq;
  const cacheKey = normalizeSearchText(keyword);
  const cached = smartSearchCache.get(cacheKey);
  if(cached && Date.now() - cached.ts < 15 * 60 * 1000){
    box.style.display = "block";
    window.smartResults = cached.results;
    list.innerHTML = cached.results.length
      ? cached.results.map((item, index) => smartResultHTML(item, index)).join("")
      : `<div class="smart-empty">ไม่พบข้อมูลจากแหล่งฟรี ลองชื่ออังกฤษ/ญี่ปุ่น/ชื่ออื่น หรือกรอกเองแล้ว WJB จะจำไว้ให้ครั้งหน้า</div>`;
    return;
  }

  box.style.display = "block";
  list.innerHTML = `<div class="smart-loading">กำลังค้นหา "${escapeText(keyword)}"...</div>`;

  try{
    const results = await Promise.allSettled([
      searchLocalWJBMemory(keyword),
      searchAnimeJikan(keyword),
      searchAniListAnime(keyword),
      searchKitsuAnime(keyword),
      searchTvMaze(keyword),
      searchITunesMovie(keyword),
      searchWikipediaFree(keyword),
      searchTmdbMulti(keyword)
    ]);

    const merged = results
      .filter(r => r.status === "fulfilled")
      .flatMap(r => r.value)
      .filter(Boolean)
      .map(normalizeSmartSeason);

    const unique = mergeSmartResults(merged);

    if(seq !== smartSearchSeq || normalizeSearchText($("title")?.value || "") !== cacheKey) return;

    if(unique.length === 0){
      smartSearchCache.set(cacheKey, { ts:Date.now(), results:[] });
      list.innerHTML = `<div class="smart-empty">ไม่พบข้อมูลจากแหล่งฟรี ลองชื่ออังกฤษ/ญี่ปุ่น/ชื่ออื่น หรือกรอกเองแล้ว WJB จะจำไว้ให้ครั้งหน้า</div>`;
      return;
    }

    const sorted = smartSortResults(unique, keyword).slice(0, 12);
    smartSearchCache.set(cacheKey, { ts:Date.now(), results:sorted });
    list.innerHTML = sorted.map((item, index) => smartResultHTML(item, index)).join("");
    window.smartResults = sorted;
  }catch(e){
    list.innerHTML = `<div class="smart-empty">ค้นหาไม่สำเร็จ แต่ยังเพิ่มเองได้ตามปกติ</div>`;
  }
}



function normalizeSearchText(text){
  return String(text || "")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

function sourcePriority(source){
  if(String(source).includes("WJB")) return 0;
  if(String(source).includes("TMDB")) return 1;
  if(String(source).includes("Jikan")) return 2;
  if(String(source).includes("AniList")) return 3;
  if(String(source).includes("Kitsu")) return 4;
  if(String(source).includes("TVMaze")) return 5;
  if(String(source).includes("iTunes")) return 6;
  return 9;
}

function smartMergeKey(item){
  const title = normalizeSearchText(item.title || item.altTitle || "");
  const alt = normalizeSearchText(item.altTitle || "");
  const year = String(item.year || item.releaseInfo || "").match(/\d{4}/)?.[0] || "";
  const type = String(item.type || "").includes("หนัง") ? "movie" : (String(item.type || "").includes("ซีรีส์") ? "series" : (String(item.type || "").includes("อนิเมะ") ? "anime" : "other"));
  const baseTitle = title.replace(/(the|a|an)/g, "").replace(/\s+/g, " ").trim();
  return `${baseTitle || alt}|${year}|${type}`;
}

function mergeSmartResults(merged){
  const unique = [];
  const seen = new Map();
  merged.filter(Boolean).forEach(item => {
    const key = smartMergeKey(item);
    if(!seen.has(key)){
      seen.set(key, unique.length);
      unique.push(item);
      return;
    }
    const idx = seen.get(key);
    const old = unique[idx];
    const mergedAlt = [old.altTitle, item.altTitle]
      .filter(Boolean)
      .join(" / ")
      .split(" / ")
      .filter((v, i, arr) => v && arr.indexOf(v) === i)
      .join(" / ");
    unique[idx] = {
      ...old,
      poster: old.poster || item.poster || "",
      total: old.total || item.total || "",
      year: old.year || item.year || "",
      releaseInfo: old.releaseInfo || item.releaseInfo || "",
      note: old.note || item.note || "",
      score: old.score || item.score || "",
      popularity: old.popularity || item.popularity || item.members || "",
      members: old.members || item.members || "",
      favorites: old.favorites || item.favorites || "",
      rank: old.rank || item.rank || "",
      format: old.format || item.format || "",
      altTitle: mergedAlt,
      source: String(old.source || "").includes(item.source) ? old.source : `${old.source}+${item.source}`
    };
  });
  return unique;
}

function smartSortResults(arr, keyword){
  const q = normalizeSearchText(keyword);
  return [...arr].sort((a,b)=>{
    const at = normalizeSearchText(a.title || "");
    const bt = normalizeSearchText(b.title || "");
    const ae = at === q ? -3 : (at.includes(q) ? -1 : 0);
    const be = bt === q ? -3 : (bt.includes(q) ? -1 : 0);
    if(ae !== be) return ae - be;
    return sourcePriority(a.source) - sourcePriority(b.source);
  });
}

async function searchLocalWJBMemory(keyword){
  const q = normalizeSearchText(keyword);
  if(!q) return [];
  const pool = [...(items || []), ...(publicItems || []), ...(isAdmin ? (adminItems || []) : [])];
  const seen = new Set();
  return pool
    .filter(i => normalizeSearchText(`${i.title || ""} ${i.altTitle || ""} ${i.note || ""}`).includes(q))
    .filter(i => {
      const key = `${normalizeSearchText(i.title)}|${normalizeSearchText(i.season)}|${i.ownerId || ""}`;
      if(seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .slice(0, 6)
    .map(i => ({
      source: "WJB Memory",
      title: i.title || "",
      altTitle: i.altTitle || "",
      type: i.type || "อื่นๆ",
      poster: i.poster || "",
      season: i.type === "หนัง" ? "" : (i.season || "ซีซั่น 1"),
      releaseInfo: i.releaseInfo || "",
      total: i.total || "",
      year: String(i.releaseInfo || "").match(/\d{4}/)?.[0] || "",
      note: i.note || "ข้อมูลนี้มาจากฐาน WJB ที่เคยบันทึกไว้"
    }));
}

async function searchAniListAnime(keyword){
  const query = `query ($search: String) { Page(page: 1, perPage: 5) { media(search: $search, type: ANIME) { id title { romaji english native } coverImage { large } seasonYear episodes description(asHtml: false) format averageScore popularity favourites } } }`;
  const res = await fetch("https://graphql.anilist.co", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Accept": "application/json" },
    body: JSON.stringify({ query, variables: { search: keyword } })
  });
  if(!res.ok) return [];
  const data = await res.json();
  return (((data.data || {}).Page || {}).media || []).map(a => ({
    source: "AniList",
    title: a.title?.english || a.title?.romaji || a.title?.native || "",
    altTitle: [a.title?.romaji, a.title?.native].filter(Boolean).join(" / "),
    type: "อนิเมะ",
    poster: a.coverImage?.large || "",
    season: "ซีซั่น 1",
    releaseInfo: a.seasonYear ? `ปี ${a.seasonYear}` : "",
    total: a.episodes || "",
    year: a.seasonYear || "",
    note: a.description ? stripHTML(a.description).slice(0, 240) : "",
    score: a.averageScore || "",
    popularity: a.popularity || "",
    favorites: a.favourites || "",
    format: a.format || "Anime"
  }));
}

async function searchKitsuAnime(keyword){
  const url = `https://kitsu.io/api/edge/anime?filter[text]=${encodeURIComponent(keyword)}&page[limit]=5`;
  const res = await fetch(url, { headers: { "Accept": "application/vnd.api+json" } });
  if(!res.ok) return [];
  const data = await res.json();
  return (data.data || []).map(row => {
    const a = row.attributes || {};
    const titles = a.titles || {};
    return {
      source: "Kitsu",
      title: titles.en || titles.en_jp || titles.ja_jp || a.canonicalTitle || "",
      altTitle: [a.canonicalTitle, titles.ja_jp].filter(Boolean).join(" / "),
      type: "อนิเมะ",
      poster: a.posterImage?.large || a.posterImage?.medium || "",
      season: "ซีซั่น 1",
      releaseInfo: a.startDate ? `ปี ${String(a.startDate).slice(0,4)}` : "",
      total: a.episodeCount || "",
      year: a.startDate ? String(a.startDate).slice(0,4) : "",
      note: a.synopsis ? a.synopsis.slice(0, 240) : "",
      score: a.averageRating || "",
      popularity: a.popularityRank || "",
      rank: a.ratingRank || "",
      format: a.subtype || "Anime"
    };
  });
}

async function searchWikipediaFree(keyword){
  // ใช้ Wikipedia API แบบไม่มี key เพื่อช่วยจับชื่อไทย/ชื่ออื่น ถ้า API หนังหลักหาไม่เจอ
  const langs = ["th", "en"];
  const all = [];
  for(const lang of langs){
    try{
      const url = `https://${lang}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(keyword)}&format=json&origin=*&srlimit=3`;
      const res = await fetch(url);
      if(!res.ok) continue;
      const data = await res.json();
      (data.query?.search || []).forEach(row => {
        all.push({
          source: lang === "th" ? "Wikipedia TH" : "Wikipedia EN",
          title: row.title || "",
          altTitle: "",
          type: "อื่นๆ",
          poster: "",
          season: "ซีซั่น 1",
          releaseInfo: "",
          total: "",
          year: "",
          note: row.snippet ? stripHTML(row.snippet).slice(0, 240) : "ข้อมูลจาก Wikipedia"
        });
      });
    }catch(_e){}
  }
  return all;
}

window.setWJBTmdbFreeKey = function(){
  wjbToast("WJB อยู่ในโหมดฟรี 100% จึงปิดการใส่ API key ทุกชนิดไว้ครับ");
};

async function searchTmdbMulti(keyword){
  const key = getWJBTmdbFreeKey();
  if(!key) return [];
  const url = `https://api.themoviedb.org/3/search/multi?api_key=${encodeURIComponent(key)}&query=${encodeURIComponent(keyword)}&language=th-TH&include_adult=false&page=1`;
  const res = await fetch(url);
  if(!res.ok) return [];
  const data = await res.json();

  return (data.results || [])
    .filter(x => x.media_type === "movie" || x.media_type === "tv")
    .slice(0, 6)
    .map(x => {
      const isMovie = x.media_type === "movie";
      const title = x.title || x.name || x.original_title || x.original_name || "";
      const original = x.original_title || x.original_name || "";
      const year = (x.release_date || x.first_air_date || "").slice(0, 4);
      return {
        source: "TMDB",
        title,
        altTitle: original && original !== title ? original : "",
        type: isMovie ? "หนัง" : "ซีรีส์",
        poster: x.poster_path ? `https://image.tmdb.org/t/p/w500${x.poster_path}` : "",
        season: isMovie ? "" : "ซีซั่น 1",
        releaseInfo: year ? `ปี ${year}` : "",
        total: "",
        year,
        note: x.overview ? x.overview.slice(0, 240) : "",
        score: x.vote_average || "",
        popularity: x.popularity || "",
        format: isMovie ? "Movie" : "TV"
      };
    });
}

function normalizeSmartSeason(item){
  const release = item.releaseInfo || (isReleaseLikeSeasonName(item.season) ? item.season : "");
  const seasonName = item.type === "หนัง" ? "" : (isReleaseLikeSeasonName(item.season) ? "ซีซั่น 1" : (item.season || "ซีซั่น 1"));
  return {...item, season: seasonName, releaseInfo: release};
}


async function searchAnimeJikan(keyword){
  const url = `https://api.jikan.moe/v4/anime?q=${encodeURIComponent(keyword)}&limit=5`;
  const res = await fetch(url);
  if(!res.ok) return [];
  const data = await res.json();

  return (data.data || []).map(a => ({
    source: "Jikan",
    title: a.title_english || a.title || "",
    altTitle: a.title_japanese || "",
    type: "อนิเมะ",
    poster: a.images?.jpg?.large_image_url || a.images?.jpg?.image_url || "",
    season: "ซีซั่น 1",
    releaseInfo: a.season && a.year ? `${a.season} ${a.year}` : (a.year ? `ปี ${a.year}` : ""),
    total: a.episodes || "",
    year: a.year || "",
    note: a.synopsis ? a.synopsis.slice(0, 240) : "",
    score: a.score || "",
    popularity: a.members || "",
    members: a.members || "",
    rank: a.rank || "",
    format: a.type || "Anime"
  }));
}

async function searchTvMaze(keyword){
  const url = `https://api.tvmaze.com/search/shows?q=${encodeURIComponent(keyword)}`;
  const res = await fetch(url);
  if(!res.ok) return [];
  const data = await res.json();

  return (data || []).slice(0, 5).map(row => {
    const s = row.show || {};
    return {
      source: "TVMaze",
      title: s.name || "",
      altTitle: "",
      type: "ซีรีส์",
      poster: s.image?.original || s.image?.medium || "",
      season: "ซีซั่น 1",
      releaseInfo: s.premiered ? `เริ่มฉาย ${String(s.premiered).slice(0,4)}` : "",
      total: "",
      year: s.premiered ? String(s.premiered).slice(0,4) : "",
      note: s.summary ? stripHTML(s.summary).slice(0, 240) : "",
      score: s.rating?.average || "",
      popularity: s.weight || "",
      format: s.type || "Series"
    };
  });
}

async function searchITunesMovie(keyword){
  const url = `https://itunes.apple.com/search?term=${encodeURIComponent(keyword)}&media=movie&limit=5`;
  const res = await fetch(url);
  if(!res.ok) return [];
  const data = await res.json();

  return (data.results || []).map(m => ({
    source: "iTunes",
    title: m.trackName || "",
    altTitle: "",
    type: "หนัง",
    poster: m.artworkUrl100 ? m.artworkUrl100.replace("100x100bb", "600x900bb") : "",
    season: "",
    releaseInfo: m.releaseDate ? `ปี ${String(m.releaseDate).slice(0,4)}` : "",
    total: "",
    year: m.releaseDate ? String(m.releaseDate).slice(0,4) : "",
    note: m.longDescription ? m.longDescription.slice(0, 240) : "",
    format: "Movie"
  }));
}

function compactNumber(n){
  const num = Number(n || 0);
  if(!Number.isFinite(num) || num <= 0) return "";
  if(num >= 1000000) return `${(num / 1000000).toFixed(num >= 10000000 ? 0 : 1)}M`;
  if(num >= 1000) return `${(num / 1000).toFixed(num >= 10000 ? 0 : 1)}K`;
  return String(Math.round(num));
}

function smartTypeClass(type){
  const t = String(type || "");
  if(t.includes("อนิเมะ")) return "anime";
  if(t.includes("หนัง")) return "movie";
  if(t.includes("ซีรีส์")) return "series";
  return "other";
}

function inferFormatLabel(item){
  const fmt = String(item.format || item.mediaType || "").replace(/_/g, " ").trim();
  if(fmt) return fmt;
  if(String(item.type || "").includes("หนัง")) return "Movie";
  if(String(item.type || "").includes("ซีรีส์")) return "Series";
  if(String(item.type || "").includes("อนิเมะ")) return "Anime";
  return "Media";
}

function smartDisplayScore(item){
  const raw = Number(item.score || item.rating || item.averageScore || 0);
  if(!Number.isFinite(raw) || raw <= 0) return "";
  const ten = raw > 10 ? raw / 10 : raw;
  return ten.toFixed(ten >= 9.95 ? 0 : 1).replace(".0", "");
}

function wjbScore(item){
  const base = Number(smartDisplayScore(item) || 0);
  const pop = Number(item.popularity || item.members || item.favorites || item.followers || 0);
  const rank = Number(item.rank || 0);
  let score = base || 7.0;
  if(pop > 0) score += Math.min(0.8, Math.log10(pop + 1) / 10);
  if(rank > 0) score += Math.max(0, (5000 - Math.min(rank, 5000)) / 10000);
  if(String(item.source || '').toLowerCase().includes('wjb')) score += 0.15;
  score = Math.max(0, Math.min(9.9, score));
  return score.toFixed(1).replace('.0','');
}

function wjbStars(score){
  const n = Number(score || 0);
  if(!Number.isFinite(n) || n <= 0) return "";
  const filled = Math.max(0, Math.min(5, Math.round(n / 2)));
  return "★".repeat(filled) + "☆".repeat(5 - filled);
}

function wjbSourcePills(source){
  const text = String(source || "WJB");
  const parts = text.split(/[+,/]/).map(x => x.trim()).filter(Boolean).slice(0,3);
  const icon = (name)=>{
    const n = name.toLowerCase();
    if(n.includes('anilist')) return '🅐';
    if(n.includes('jikan')) return '🌐';
    if(n.includes('tmdb')) return '🎞️';
    if(n.includes('tvmaze')) return '📺';
    if(n.includes('kitsu')) return '🦊';
    return '◇';
  };
  return (parts.length ? parts : ['WJB']).map(x => `<span class="wjb-v11-source-pill">${icon(x)} ${escapeText(x)}</span>`).join('');
}

function smartResultHTML(item, index){
  const poster = item.poster || "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='100' height='140'><rect width='100%' height='100%' fill='%23182736'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' fill='%23ffffff' font-size='18'>WJB</text></svg>";
  const title = escapeText(item.title || "ไม่ระบุชื่อ");
  const score = smartDisplayScore(item);
  const wScore = wjbScore(item);
  const scoreHTML = score ? `<span class="wjb-v10-score">⭐${score}</span>` : `<span class="wjb-v10-score wjb-score-only">WJB ${wScore}</span>`;
  const type = escapeText(item.type || "อื่นๆ");
  const typeClass = smartTypeClass(item.type);
  const format = escapeText(inferFormatLabel(item));
  const year = escapeText(item.releaseInfo || item.year || "ไม่ระบุปี");
  const total = item.total ? `<span class="wjb-v10-stat">🎬 ${escapeText(item.total)} ตอน</span>` : "";
  const popularity = item.popularity || item.members || item.favorites || item.followers;
  const pop = compactNumber(popularity);
  const popHTML = pop ? `<span class="wjb-v10-stat">👥 ${escapeText(pop)}</span>` : "";
  const rank = item.rank ? `<span class="wjb-v10-stat wjb-v11-popular">🔥 #${escapeText(item.rank)} Popular</span>` : "";
  const note = item.note ? `<p class="wjb-v10-note">${escapeText(String(item.note).slice(0, 150))}</p>` : (item.altTitle ? `<p class="wjb-v10-note">${escapeText(item.altTitle)}</p>` : "");
  return `
    <div class="smart-result wjb-v10-result wjb-v11-result" role="button" tabindex="0" onclick="openSmartDetail(${index})" onkeydown="if(event.key==='Enter'){openSmartDetail(${index})}">
      <img src="${escapeText(poster)}" alt="" onclick="event.stopPropagation(); openSmartDetail(${index})">
      <div class="wjb-v10-result-body">
        <div class="wjb-v10-title-row"><b>${title}</b>${scoreHTML}</div>
        <div class="wjb-v10-meta">
          <span class="wjb-v10-badge ${typeClass}">${typeClass === 'movie' ? 'MOVIE' : typeClass === 'series' ? 'TV' : type}</span>
          <span class="wjb-v10-pill">${format}</span>
          <span class="wjb-v10-pill">${year}</span>
        </div>
        <div class="wjb-v10-stats">${rank}${popHTML}${total}</div>
        ${note}
        <div class="wjb-v11-stars" aria-label="rating stars">${wjbStars(score || wScore)} <span>WJB ${wScore}</span></div>
        <div class="wjb-v10-source">${wjbSourcePills(item.source)}</div>
        <div class="wjb-v10-actions wjb-v11-actions">
          <button type="button" class="wjb-v10-action-primary" onclick="event.stopPropagation(); selectSmartResult(${index});">เลือก</button>
          <button type="button" class="wjb-v10-action-secondary wjb-v11-icon-action" title="เพิ่มเข้าลิสต์" onclick="event.stopPropagation(); addSmartResultToList(${index});">❤</button>
          <button type="button" class="wjb-v10-action-secondary" onclick="event.stopPropagation(); openSmartDetail(${index});">ⓘ รายละเอียด</button>
        </div>
      </div>
    </div>
  `;
}

function applySmartItemToForm(item){
  if(!item) return;
  $("title").value = item.title || "";
  if($("type")) $("type").value = item.type || "อื่นๆ";
  if($("season")) $("season").value = item.season || (item.type === "หนัง" ? "" : "ซีซั่น 1");
  if($("releaseInfo")) $("releaseInfo").value = item.releaseInfo || "";
  if($("total")) $("total").value = item.total || "";
  if($("note") && !$("note").value) $("note").value = item.note || "";

  smartPoster = item.poster || getStoredPoster(item) || "";

  if($("episodeMode")){
    $("episodeMode").value = item.total ? "manual" : "ongoing";
  }

  toggleEpisodeFields();

  if($("smartSuggestBox")) $("smartSuggestBox").style.display = "none";
  try{ backToAdd(); }catch(_e){}
  try{ wjbJumpToFormDetails("season"); }catch(_e){}
}

window.selectSmartResult = function(index){
  const item = (window.smartResults || [])[index];
  if(!item) return;
  applySmartItemToForm(item);
};
window.addSmartResultToList = async function(index){
  const item = (window.smartResults || [])[index];
  if(!item) return;
  await addSmartItemToList(item);
};

async function addSmartItemToList(item){
  if(!item) return;
  if(!currentUser){
    wjbToast("กรุณาเข้าสู่ระบบก่อนเพิ่มเข้าลิสต์");
    return;
  }

  // v10.2 Clean Core Fix: clear old form data first so search results never inherit
  // stale episode/status/score/note values from the previously edited item.
  const fieldsToClear = ["title","season","releaseInfo","episode","total","score","note"];
  fieldsToClear.forEach((id)=>{
    const el = $(id);
    if(el) el.value = "";
  });
  if($("type")) $("type").value = item.type || "อื่นๆ";
  if($("status")) $("status").value = "อยากดู";

  applySmartItemToForm(item);
  if($("status")) $("status").value = "อยากดู";
  if($("episode")) $("episode").value = "0";
  if($("score")) $("score").value = smartDisplayScore(item) || "";
  if($("note")) $("note").value = item.note || "";

  await window.addItem();
}

// สร้าง markup ของแผ่นรายละเอียด (ใช้ร่วมกันทั้งผลค้นหา Smart Search และการ์ดในกระดานเตือนออนไลน์)
// useAttr/addAttr คือโค้ด JS ที่จะใส่ใน onclick ของปุ่ม "ใช้ข้อมูล" / "เพิ่มเข้าลิสต์" ตามแหล่งข้อมูลต้นทาง
function wjbBuildDetailSheet(item, useAttr, addAttr){
  const old = document.getElementById("wjbSmartDetailSheet");
  if(old) old.remove();
  const score = smartDisplayScore(item);
  const wScore = wjbScore(item);
  const poster = item.poster || "";
  const pop = compactNumber(item.popularity || item.members || item.favorites || item.followers || 0);
  const sheet = document.createElement("div");
  sheet.id = "wjbSmartDetailSheet";
  sheet.className = "wjb-smart-sheet-backdrop wjb-v11-sheet-backdrop";
  sheet.innerHTML = `
    <div class="wjb-smart-sheet wjb-v11-sheet" role="dialog" aria-modal="true">
      <div class="wjb-v11-grabber"></div>
      <button class="wjb-smart-sheet-close" type="button" onclick="closeSmartDetail()">×</button>
      <div class="wjb-smart-sheet-head wjb-v11-sheet-head">
        ${poster ? `<img src="${escapeText(poster)}" alt="">` : `<div class="wjb-smart-sheet-poster">WJB</div>`}
        <div>
          <h3>${escapeText(item.title || "ไม่ระบุชื่อ")}</h3>
          <p>${escapeText([item.releaseInfo || item.year, inferFormatLabel(item), item.total ? item.total + ' ตอน' : ''].filter(Boolean).join(" • "))}</p>
          <div class="wjb-v10-source wjb-v11-sheet-source">${wjbSourcePills(item.source)}</div>
          <div class="wjb-v11-rating-row">
            ${score ? `<div class="wjb-v11-main-score"><span>⭐</span><b>${score}</b><small>/10</small></div>` : ""}
            <div class="wjb-v11-wjb-score"><small>WJB SCORE</small><b>${wScore}</b><em>${Number(wScore) >= 8.5 ? 'ยอดเยี่ยม 👑' : 'แนะนำ'}</em></div>
          </div>
        </div>
      </div>
      <div class="wjb-v11-star-line">${wjbStars(score || wScore)}</div>
      <div class="wjb-v11-metrics">
        ${item.rank ? `<div><b>#${escapeText(item.rank)}</b><span>Popular</span></div>` : ""}
        ${pop ? `<div><b>${escapeText(pop)}</b><span>ผู้ติดตาม</span></div>` : ""}
        ${item.total ? `<div><b>${escapeText(item.total)}</b><span>ความยาว</span></div>` : ""}
      </div>
      ${item.altTitle ? `<p class="wjb-smart-sheet-alt">${escapeText(item.altTitle)}</p>` : ""}
      <h4 class="wjb-v11-section-title">เรื่องย่อ</h4>
      <p class="wjb-smart-sheet-note">${escapeText(item.note || "ยังไม่มีรายละเอียดจากแหล่งข้อมูลนี้")}</p>
      <div class="wjb-v11-tags">
        <span>${escapeText(item.type || 'Media')}</span>
        <span>${escapeText(inferFormatLabel(item))}</span>
        <span>${escapeText(item.releaseInfo || item.year || 'ไม่ระบุปี')}</span>
      </div>
      <div class="wjb-smart-sheet-actions wjb-v11-sheet-actions">
        <button type="button" onclick="${useAttr}">▶ ใช้ข้อมูล</button>
        <button type="button" onclick="${addAttr}">＋ เพิ่มเข้าลิสต์</button>
      </div>
      <div class="wjb-v11-mini-actions">
        <button type="button" onclick="navigator.share ? navigator.share({title:'${escAttrJs(item.title || 'WJB')}'}).catch(()=>{}) : wjbToast('แชร์จาก Safari ได้ที่ปุ่ม Share ด้านล่าง')">⇧<span>แชร์</span></button>
        <button type="button" onclick="closeSmartDetail()">◉<span>ปิด</span></button>
        <button type="button" onclick="openTrailerSearch('${escAttrJs(item.title || '')}')">🎬<span>ดูตัวอย่าง</span></button>
      </div>
    </div>`;
  sheet.addEventListener("click", e => { if(e.target === sheet) closeSmartDetail(); });
  document.body.appendChild(sheet);
}

window.openSmartDetail = function(index){
  const item = (window.smartResults || [])[index];
  if(!item) return;
  wjbBuildDetailSheet(
    item,
    `selectSmartResult(${index}); closeSmartDetail();`,
    `addSmartResultToList(${index}); closeSmartDetail();`
  );
};

window.closeSmartDetail = function(){
  const sheet = document.getElementById("wjbSmartDetailSheet");
  if(sheet) sheet.remove();
};


// WJB v5.5: ยืนยันชื่อเรื่องแล้วซ่อนผลค้นหาออนไลน์ เพื่อกรอกข้อมูลต่อโดยไม่ต้องเลื่อนยาว
window.useTitleAndContinue = function(){
  const titleInput = $("title");
  if(!titleInput) return;
  const title = titleInput.value.trim();
  if(!title){
    titleInput.focus();
    return;
  }

  const box = $("smartSuggestBox");
  const collapsed = $("smartSuggestCollapsed");
  const notice = $("wjbTitleContinueNotice");
  if(box) box.style.display = "none";
  if(collapsed) collapsed.style.display = "grid";
  if(notice) notice.style.display = "block";

  const next = $("season") || $("releaseInfo") || $("poster") || $("type");
  if(next){
    setTimeout(() => {
      next.scrollIntoView({ behavior:"smooth", block:"center" });
      if(typeof next.focus === "function") next.focus({ preventScroll:true });
    }, 80);
  }
};

window.searchTitleOnlineAgain = function(){
  const titleInput = $("title");
  const q = titleInput ? titleInput.value.trim() : "";
  const collapsed = $("smartSuggestCollapsed");
  const notice = $("wjbTitleContinueNotice");
  const box = $("smartSuggestBox");
  if(collapsed) collapsed.style.display = "none";
  if(notice) notice.style.display = "none";
  if(!q){
    if(titleInput) titleInput.focus();
    return;
  }
  if(box) box.style.display = "block";
  smartSearch(q);
};

function stripHTML(html){
  const div = document.createElement("div");
  div.innerHTML = html || "";
  return div.textContent || div.innerText || "";
}


window.toggleMenu=function(){
 const box=document.getElementById('userBox');
 box.classList.toggle('open');
}
// v13.7 menu-drawer-stability.js already handles closing the drawer on outside
// click (with extra cleanup for touch state + nav guards). The old duplicate
// listener here was firing on every single click in the app in addition to
// that one, doing redundant work each time.


window.changeUsername = async function(){
  if(!currentUser) return;

  const newName = await wjbPromptModal({
    title: "เปลี่ยนชื่อผู้ใช้",
    placeholder: "ชื่อผู้ใช้ใหม่",
    value: $("userName")?.innerText || currentUser.displayName || "",
    okText: "เปลี่ยนชื่อ"
  });
  if(!newName || newName.trim() === "") return;

  const username = newName.trim();

  try{
    const usernameKey = normalizeUsernameKey(username);
    const oldUsername = $("userName")?.innerText || currentUser.displayName || "";
    const oldKey = normalizeUsernameKey(oldUsername);
    const nameSnap = await getDoc(doc(db, "usernames", usernameKey));

    if(nameSnap.exists() && nameSnap.data().uid !== currentUser.uid){
      wjbToast("ชื่อผู้ใช้นี้ถูกใช้แล้ว");
      return;
    }

    await updateProfile(currentUser, { displayName: username });

    await setDoc(
      doc(db, "users", currentUser.uid),
      {
        uid: currentUser.uid,
        username,
        displayName: username,
        email: currentUser.email,
        updatedAt: serverTimestamp()
      },
      { merge: true }
    );

    await ensureUsernameIndex(currentUser.uid, username, currentUser.email);
    if(oldKey && oldKey !== usernameKey){
      try{ await deleteDoc(doc(db, "usernames", oldKey)); }catch(_e){}
    }

    $("userName").innerText = username;
    await logActivity("change_username", { username });
    wjbToast("เปลี่ยนชื่อผู้ใช้สำเร็จ");
  }catch(e){
    wjbToast(e.message);
  }
};

window.changePassword = async function() {
  const p = await wjbPromptModal({
    title: "เปลี่ยนรหัสผ่าน",
    hint: "รหัสผ่านใหม่ (อย่างน้อย 6 ตัว)",
    placeholder: "รหัสผ่านใหม่",
    inputType: "password",
    okText: "เปลี่ยนรหัสผ่าน"
  });
  if (!p || p.length < 6) return;
  try {
    const { updatePassword } = await import("https://www.gstatic.com/firebasejs/12.0.0/firebase-auth.js");
    await updatePassword(auth.currentUser, p); 
    await logActivity("change_password", {});
    wjbToast('เปลี่ยนรหัสผ่านสำเร็จ');
  } catch (e) {
    wjbToast('กรุณาเข้าสู่ระบบใหม่ก่อนเปลี่ยนรหัสผ่าน หรือเกิดข้อผิดพลาด: ' + e.message);
  }
};


// Clean settings functions
window.openSettings=function(){document.getElementById('settingsModal').style.display='flex';}
window.closeSettings=function(){document.getElementById('settingsModal').style.display='none';}
window.toggleTheme=function(){
 document.body.classList.toggle('light-mode');
 wjbStorageSet('theme',document.body.classList.contains('light-mode')?'light':'dark');
}
if(wjbStorageGet('theme')==='light'){
 document.body.classList.add('light-mode');
}

window.chooseAvatar=function(){
 document.getElementById('avatarModal').style.display='flex';
}
window.closeAvatarModal=function(){
 document.getElementById('avatarModal').style.display='none';
}
window.selectAvatar=async function(url){
 if(!currentUser) return;
 try{
   await updateDoc(doc(db,'users',currentUser.uid),{avatar:url});
   wjbStorageSet('avatar_'+currentUser.uid,url);
   const menuAvatar=document.getElementById('menuAvatar');
   if(menuAvatar) menuAvatar.src=url;
   await logActivity("change_avatar", {});
   wjbToast('เปลี่ยน Avatar สำเร็จ');
   closeAvatarModal();
 }catch(e){wjbToast(e.message)}
}


// v11.5: Cancel edit should return to the item/season the user was editing,
// the same way Save does. This prevents losing the user's scroll position.
window.cancelEdit = function(){
  const cancelItemId = editId;
  const cancelItem = cancelItemId ? items.find(i => i.id === cancelItemId) : null;
  const cancelReturnTitle = editReturnTitle || cancelItem?.title || null;

  editId = null;
  editReturnTitle = null;
  clearForm();
  $("saveBtn").innerText = "+ เพิ่มรายการ";
  if ($("cancelEditBtn")) $("cancelEditBtn").style.display = "none";

  setTimeout(() => {
    if (cancelItemId && cancelReturnTitle) {
      focusSavedItem(cancelItemId, cancelReturnTitle, true);
    } else if (cancelReturnTitle) {
      currentTab = "my";
      showItems();
      setTimeout(() => openSeasonDetail(encodeURIComponent(cancelReturnTitle)), 220);
    } else {
      currentTab = "my";
      showItems();
    }
  }, 80);
};


window.statTypeFilter = "all";
window.currentStatFilter = "all";

window.setStatTypeFilter = function(type){
  window.statTypeFilter = type;
  showFilteredStatItems(window.currentStatFilter || "all");
};

function typeFilterBar(filter, filteredBase){
  const types = ["all","อนิเมะ","หนัง","ซีรีส์","อื่นๆ"];
  const labels = {all:"ทั้งหมด", "อนิเมะ":"อนิเมะ", "หนัง":"หนัง", "ซีรีส์":"ซีรีส์", "อื่นๆ":"อื่นๆ"};
  return `<div class="type-filter-bar">
    ${types.map(t=>{
      const count = t==="all" ? filteredBase.length : filteredBase.filter(i=>i.type===t).length;
      const active = (window.statTypeFilter || "all") === t ? "active" : "";
      return `<button class="type-filter ${active}" onclick="setStatTypeFilter('${t}')">${labels[t]} (${count})</button>`;
    }).join("")}
  </div>`;
}


window.toggleEpisodeFields = function(){
  const type = $("type") ? $("type").value : "";
  const mode = $("episodeMode") ? $("episodeMode").value : "manual";
  const episode = $("episode");
  const total = $("total");
  const episodeMode = $("episodeMode");

  if(type === "หนัง"){
    if(episode) episode.style.display = "none";
    if(total) total.style.display = "none";
    if(episodeMode) episodeMode.style.display = "none";
    return;
  }

  if(episode) episode.style.display = "block";
  if(episodeMode) episodeMode.style.display = "block";

  if(mode === "ongoing"){
    if(total) total.style.display = "none";
  }else{
    if(total) total.style.display = "block";
  }
};
window.toggleEpisodeFields();

window.openPublicProfile = function(ownerId, ownerName){
  const list = (publicItems || []).filter(i => i.ownerId === ownerId);
  const fav = list.filter(i => i.favorite).length;
  const safeName = escapeText(ownerName || "ไม่ระบุ");

  document.getElementById('publicProfileContent').innerHTML = `
    <h2>👤 ${safeName}</h2>
    <p>🎬 รายการทั้งหมด: ${list.length}</p>
    <p>📺 กำลังดู: ${list.filter(i => i.status === 'กำลังดู').length}</p>
    <p>✅ ดูจบแล้ว: ${list.filter(i => i.status === 'ดูจบแล้ว').length}</p>
    <p>⭐ โปรด: ${fav}</p>
  `;

  document.getElementById('publicProfileModal').style.display = 'flex';
};
window.closePublicProfile=function(){document.getElementById('publicProfileModal').style.display='none';}


window.addEventListener('click', function(e){
  const modal = document.getElementById('seasonDetailModal');
  if(modal && e.target === modal){
    closeSeasonDetail();
  }
});
function getHallDisplayName(item){
  const title = escapeText(item?.title || "ไม่ระบุชื่อ");
  const season = getSeasonDisplayName(item);
  const hasSeason = item?.type !== "หนัง" && season && String(season).trim() !== "";
  return hasSeason ? `${title} - ${escapeText(season)}` : title;
}

window.openHallOfFame = function(){
 const modal=document.getElementById('hallModal');
 const box=document.getElementById('hallContent');
 const arr=[...(items||[])];

 const scored=arr.filter(i=>Number(i.score)>0)
   .sort((a,b)=>Number(b.score||0)-Number(a.score||0))
   .slice(0,10);

 const totalEp=arr.reduce((s,i)=>s+(Number(i.episode)||0),0);
 const avg=scored.length?(scored.reduce((s,i)=>s+Number(i.score||0),0)/scored.length).toFixed(1):"0.0";
 const completed=arr.filter(i=>(i.status||'')==='ดูจบแล้ว').length;
 const favoriteCount=arr.filter(i=>!!i.favorite).length;
 const achievementCount = arr.length + completed + favoriteCount + scored.filter(i=>Number(i.score)>=9).length;

 const watchedTop=arr
   .filter(i=>Number(i.episode)>0)
   .sort((a,b)=>Number(b.episode||0)-Number(a.episode||0))
   .slice(0,5);
 const topItem = watchedTop[0] || scored[0] || arr[0] || null;
 const topName = topItem ? getHallDisplayName(topItem) : 'ยังไม่มีข้อมูล';
 const topPoster = topItem?.poster || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="160" height="160"><rect width="100%" height="100%" fill="%23182736"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="%23ffffff" font-size="34">WJB</text></svg>';
 const topScore = topItem && Number(topItem.score)>0 ? Number(topItem.score).toFixed(1) : avg;

 const rankMedal = ['🥇','🥈','🥉','4','5'];
 const topRows = watchedTop.length ? watchedTop.map((i,index)=>{
   const poster = i.poster || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><rect width="100%" height="100%" fill="%23182736"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="%23ffffff" font-size="18">WJB</text></svg>';
   const score = Number(i.score)>0 ? Number(i.score).toFixed(1) : '-';
   const ep = Number(i.episode||0);
   return `<div class="hall-rank-row">
     <div class="hall-rank-badge">${rankMedal[index]||index+1}</div>
     <img class="hall-rank-poster" src="${escapeText(poster)}" alt="" loading="lazy">
     <div class="hall-rank-info"><b>${getHallDisplayName(i)}</b><span>${escapeText(i.type||'รายการ')} • ดูแล้ว ${ep} ตอน</span></div>
     <div class="hall-rank-score">⭐ ${score}</div>
   </div>`;
 }).join('') : `<div class="hall-empty">ยังไม่มีข้อมูลการรับชม</div>`;

 const topScores = scored.length ? scored.slice(0,5).map((i,index)=>{
   const medal=index===0?'🥇':index===1?'🥈':index===2?'🥉':'⭐';
   return `<div class="hall-score-chip"><span>${medal}</span><b>${getHallDisplayName(i)}</b><em>${Number(i.score||0).toFixed(1)}</em></div>`;
 }).join('') : '';

 box.innerHTML=`
 <section class="hall-hero-card">
   <div class="hall-title-row"><h3>🏆 Hall of Fame</h3><span>ดูทั้งหมด ›</span></div>
   <div class="hall-main-grid">
     <div class="hall-stat-grid">
       <div class="hall-stat-card"><span>📺</span><small>ดูทั้งหมด</small><b>${totalEp}</b><em>ตอน</em></div>
       <div class="hall-stat-card"><span>⭐</span><small>คะแนนเฉลี่ย</small><b>${avg}</b><em>จาก 10</em></div>
       <div class="hall-stat-card"><span>🔥</span><small>ดูจบแล้ว</small><b>${completed}</b><em>รายการ</em></div>
       <div class="hall-stat-card"><span>🏅</span><small>Achievement</small><b>${achievementCount}</b><em>แต้ม</em></div>
     </div>
     <div class="hall-top-user">
       <div class="hall-crown">👑 Top Item</div>
       <img src="${escapeText(topPoster)}" alt="" loading="lazy">
       <b>${topName}</b>
       <span>ดูแล้ว ${topItem ? Number(topItem.episode||0) : 0} ตอน</span>
       <strong>⭐ ${topScore}</strong>
     </div>
   </div>
   <div class="hall-section-head"><b>📊 Most Watched Top 5</b></div>
   <div class="hall-rank-list">${topRows}</div>
   ${topScores ? `<div class="hall-section-head hall-score-head"><b>🏆 Top Scores</b></div><div class="hall-score-list">${topScores}</div>` : ''}
 </section>`;
 modal.style.display='flex';
};
window.closeHallOfFame = function(){
 document.getElementById('hallModal').style.display='none';
};

// ===== Trending Explorer: สำรวจอนิเมะ หนัง ซีรีส์ ที่กำลังน่าสนใจ =====
let trendingType = "all";
let trendingPlatform = "all";
let trendingPage = { anime: 0, movie: 0, series: 0 };
let trendingItems = [];
let trendingLoading = false;
let trendingAddedKeys = new Set();
let trendingSearchKeyword = "";
let trendingCompactView = false;
let tmdbProviderCache = {};

const TRENDING_PLATFORMS = {
  all: { label: "ทุกแหล่ง", names: [] },
  netflix: { label: "Netflix", names: ["Netflix"] },
  disney: { label: "Disney+", names: ["Disney Plus", "Disney+", "Hotstar", "Disney Plus Hotstar"] },
  trueid: { label: "TrueID", names: ["TrueID", "True ID"] },
  wetv: { label: "WeTV", names: ["WeTV", "Tencent Video", "Tencent Video WeTV", "Tencent"] },
  iqiyi: { label: "iQIYI", names: ["iQIYI", "iQiyi"] },
  viu: { label: "VIU", names: ["VIU", "Viu"] },
  prime: { label: "Prime Video", names: ["Amazon Prime Video", "Prime Video"] },
  max: { label: "HBO / Max", names: ["Max", "HBO Max", "HBO Go"] },
  apple: { label: "Apple TV+", names: ["Apple TV", "Apple TV Plus"] },
  crunchyroll: { label: "Crunchyroll", names: ["Crunchyroll"] }
};
const TRENDING_PLATFORM_ORDER = ["netflix", "disney", "trueid", "wetv", "iqiyi", "viu", "prime", "max", "apple", "crunchyroll"];

window.openTrendingExplorer = async function(){
  const modal = $("trendingModal");
  if(modal) modal.style.display = "flex";
  if(!trendingItems.length){
    await refreshTrendingExplorer();
  }else{
    renderTrendingExplorer();
  }
};

window.closeTrendingExplorer = function(){
  const modal = $("trendingModal");
  if(modal) modal.style.display = "none";
};

window.setTrendingSearch = function(value){
  trendingSearchKeyword = String(value || "").trim().toLowerCase();
  renderTrendingExplorer();
};

window.toggleTrendingCompactView = function(){
  trendingCompactView = !trendingCompactView;
  const btn = $("trendCompactBtn");
  if(btn){
    btn.innerText = trendingCompactView ? "🖼️ มุมมองรูปใหญ่" : "📋 มุมมองย่อ";
    btn.className = trendingCompactView ? "" : "gray";
  }
  renderTrendingExplorer();
};

window.jumpToTrendingRank = function(){
  const value = Number($("trendJumpInput")?.value || 0);
  if(!value || value < 1) return wjbToast("กรอกอันดับที่ต้องการ เช่น 50");
  const target = document.getElementById(`trend-card-${value}`);
  if(target){
    target.scrollIntoView({ behavior:"smooth", block:"center" });
    target.classList.add("trend-jump-highlight");
    setTimeout(() => target.classList.remove("trend-jump-highlight"), 1800);
    return;
  }
  wjbToast("ยังโหลดไม่ถึงอันดับนี้ครับ กดโหลดเพิ่มก่อน แล้วลองอีกครั้ง");
};

window.scrollTrendingTop = function(){
  const box = document.querySelector(".trending-box");
  if(box) box.scrollTo({ top:0, behavior:"smooth" });
};

window.setTrendingType = async function(type){
  trendingType = type || "all";
  ["All","Anime","Movie","Series"].forEach(name => {
    const btn = $(`trend${name}Btn`);
    if(btn) btn.classList.add("gray");
  });
  const activeMap = { all:"trendAllBtn", anime:"trendAnimeBtn", movie:"trendMovieBtn", series:"trendSeriesBtn" };
  if($(activeMap[trendingType])) $(activeMap[trendingType]).classList.remove("gray");
  await refreshTrendingExplorer();
};

window.setTrendingPlatform = async function(platform){
  trendingPlatform = platform || "all";
  ["AllPlatform","Netflix","Disney","Trueid","Wetv","Iqiyi","Viu","Prime","Max","Apple","Crunchyroll"].forEach(name => {
    const btn = $(`trend${name}Btn`);
    if(btn) btn.classList.add("gray");
  });
  const activeMap = {
    all:"trendAllPlatformBtn",
    netflix:"trendNetflixBtn",
    disney:"trendDisneyBtn",
    trueid:"trendTrueidBtn",
    wetv:"trendWetvBtn",
    iqiyi:"trendIqiyiBtn",
    viu:"trendViuBtn",
    prime:"trendPrimeBtn",
    max:"trendMaxBtn",
    apple:"trendAppleBtn",
    crunchyroll:"trendCrunchyrollBtn"
  };
  if($(activeMap[trendingPlatform])) $(activeMap[trendingPlatform]).classList.remove("gray");
  await refreshTrendingExplorer();
};

window.refreshTrendingExplorer = async function(){
  trendingItems = [];
  trendingPage = { anime: 0, movie: 0, series: 0 };
  const content = $("trendingContent");
  const platformText = TRENDING_PLATFORMS[trendingPlatform]?.label || "ออนไลน์";
  if(content) content.innerHTML = `<div class="trend-loading">กำลังโหลดเทรนด์จาก ${platformText}...</div>`;
  await loadMoreTrending();
};

window.loadMoreTrending = async function(){
  if(trendingLoading) return;
  trendingLoading = true;
  const btn = $("trendLoadMoreBtn");
  if(btn){ btn.disabled = true; btn.innerText = "กำลังโหลด..."; }

  try{
    const tasks = [];
    if(trendingPlatform === "all"){
      if(trendingType === "all" || trendingType === "anime") tasks.push(fetchTrendingAnime(++trendingPage.anime));
      for(const platformKey of TRENDING_PLATFORM_ORDER){
        if(trendingType === "all" || trendingType === "movie") tasks.push(fetchPlatformTrendingTmdb("movie", trendingPage.movie + 1, platformKey));
        if(trendingType === "all" || trendingType === "series") tasks.push(fetchPlatformTrendingTmdb("tv", trendingPage.series + 1, platformKey));
        if(trendingType === "all" || trendingType === "anime") tasks.push(fetchPlatformTrendingTmdb("tv", trendingPage.anime + 1, platformKey, { animeOnly:true }));
      }
      if(trendingType === "all" || trendingType === "movie") trendingPage.movie++;
      if(trendingType === "all" || trendingType === "series") trendingPage.series++;
      if(trendingType === "all" || trendingType === "anime") trendingPage.anime++;
    }else{
      if(trendingType === "all" || trendingType === "movie") tasks.push(fetchPlatformTrendingTmdb("movie", ++trendingPage.movie, trendingPlatform));
      if(trendingType === "all" || trendingType === "series") tasks.push(fetchPlatformTrendingTmdb("tv", ++trendingPage.series, trendingPlatform));
      if(trendingType === "all" || trendingType === "anime") tasks.push(fetchPlatformTrendingTmdb("tv", ++trendingPage.anime, trendingPlatform, { animeOnly:true }));
    }

    const results = await Promise.allSettled(tasks);
    const next = results.filter(r => r.status === "fulfilled").flatMap(r => r.value || []);
    mergeTrendingItems(next);
    renderTrendingExplorer();
  }catch(e){
    if($("trendingContent")) $("trendingContent").innerHTML = `<div class="empty">โหลดข้อมูลเทรนด์ไม่สำเร็จ ลองกดรีเฟรชอีกครั้ง</div>`;
  }finally{
    trendingLoading = false;
    if(btn){ btn.disabled = false; btn.innerText = "โหลดเพิ่ม"; btn.style.display = "block"; }
  }
};

function mergeTrendingItems(next){
  const seen = new Set(trendingItems.map(x => `${x.source}-${x.platform || ""}-${x.kind}-${String(x.title || "").toLowerCase()}-${x.year || ""}`));
  const added = [];
  next.forEach(x => {
    const key = `${x.source}-${x.platform || ""}-${x.kind}-${String(x.title || "").toLowerCase()}-${x.year || ""}`;
    if(!seen.has(key) && x.title){
      const rememberedPoster = getStoredPoster(x);
      if(rememberedPoster && !x.poster) x.poster = rememberedPoster;
      seen.add(key);
      trendingItems.push(x);
      added.push(x);
    }
  });
  trendingItems = trendingItems.slice(0, 1000);
  schedulePosterEnrichment(added);
}

async function fetchTrendingAnime(page = 1){
  const url = `https://api.jikan.moe/v4/top/anime?filter=bypopularity&page=${page}&limit=25`;
  const res = await fetch(url);
  if(!res.ok) return [];
  const data = await res.json();
  return (data.data || []).map((a, idx) => ({
    source: "Jikan",
    platform: "ออนไลน์",
    kind: "anime",
    type: "อนิเมะ",
    title: a.title_english || a.title || "",
    altTitle: a.title_japanese || "",
    poster: a.images?.jpg?.large_image_url || a.images?.jpg?.image_url || "",
    year: a.year || "",
    releaseInfo: a.season && a.year ? `${a.season} ${a.year}` : (a.year ? `ปี ${a.year}` : ""),
    total: a.episodes || "",
    note: a.synopsis ? String(a.synopsis).slice(0, 260) : "",
    rawPopularity: Math.max(1, 1000000 - (((page - 1) * 25 + idx) * 9000) + (Number(a.members) || 0) / 20),
    ratingScore: a.score ? `${Number(a.score).toFixed(1)}/10` : "ไม่พบคะแนน",
    ratingCount: a.members ? `${Number(a.members).toLocaleString("th-TH")} คนสนใจ` : "",
    rankText: a.rank ? `อันดับคะแนน #${a.rank}` : ""
  }));
}

async function fetchTrendingTmdb(mediaType, page = 1){
  const key = getWJBTmdbFreeKey();
  if(!key) return [];
  const url = `https://api.themoviedb.org/3/trending/${mediaType}/week?api_key=${encodeURIComponent(key)}&language=th-TH&page=${page}`;
  const res = await fetch(url);
  if(!res.ok) return [];
  const data = await res.json();
  return mapTmdbResults(data.results || [], mediaType, "ออนไลน์");
}

async function getTmdbProviderIds(platformKey, mediaType){
  if(platformKey === "all") return [];
  const cacheKey = `${platformKey}-${mediaType}`;
  if(tmdbProviderCache[cacheKey]) return tmdbProviderCache[cacheKey];
  const platform = TRENDING_PLATFORMS[platformKey];
  if(!platform || !platform.names.length) return [];
  const key = getWJBTmdbFreeKey();
  if(!key) return [];
  const url = `https://api.themoviedb.org/3/watch/providers/${mediaType}?api_key=${encodeURIComponent(key)}&watch_region=TH&language=th-TH`;
  const res = await fetch(url);
  if(!res.ok) return [];
  const data = await res.json();
  const names = platform.names.map(n => n.toLowerCase());
  const ids = (data.results || [])
    .filter(p => names.some(n => String(p.provider_name || "").toLowerCase().includes(n)))
    .map(p => p.provider_id);
  tmdbProviderCache[cacheKey] = [...new Set(ids)];
  return tmdbProviderCache[cacheKey];
}

async function fetchPlatformTrendingTmdb(mediaType, page = 1, platformKey = "netflix", options = {}){
  const key = getWJBTmdbFreeKey();
  if(!key) return getFallbackPlatformTrending(platformKey, mediaType, page, options);
  const ids = await getTmdbProviderIds(platformKey, mediaType);
  if(!ids.length) return getFallbackPlatformTrending(platformKey, mediaType, page, options);
  const extra = options.animeOnly ? "&with_genres=16&with_original_language=ja" : "";
  const url = `https://api.themoviedb.org/3/discover/${mediaType}?api_key=${encodeURIComponent(key)}&language=th-TH&watch_region=TH&with_watch_providers=${ids.join("|")}&sort_by=popularity.desc&include_adult=false&page=${page}${extra}`;
  const res = await fetch(url);
  if(!res.ok) return getFallbackPlatformTrending(platformKey, mediaType, page, options);
  const data = await res.json();
  const platformLabel = TRENDING_PLATFORMS[platformKey]?.label || platformKey;
  const mapped = mapTmdbResults(data.results || [], mediaType, platformLabel, options.animeOnly);
  return mapped.length ? mapped : getFallbackPlatformTrending(platformKey, mediaType, page, options);
}

const PLATFORM_FALLBACK_TRENDING = {
  netflix: [
    { title:"Wednesday", type:"ซีรีส์", year:"2022", score:8.1, note:"WJB สำรอง: ซีรีส์กระแสสูง เหมาะกับสายลึกลับ/โรงเรียน/แฟนตาซี" },
    { title:"Stranger Things", type:"ซีรีส์", year:"2016", score:8.6, note:"WJB สำรอง: ไซไฟวัยรุ่น/ลึกลับ ดูยาวและมีฐานแฟนมาก" },
    { title:"Kingdom", type:"ซีรีส์", year:"2019", score:8.3, note:"WJB สำรอง: ซอมบี้พีเรียดเกาหลี กระชับและเข้มข้น" },
    { title:"One Piece", type:"ซีรีส์", year:"2023", score:8.2, note:"WJB สำรอง: ผจญภัยแฟนตาซีจากมังงะดัง" },
    { title:"Demon Slayer", type:"อนิเมะ", year:"2019", score:8.6, note:"WJB สำรอง: อนิเมะแอ็กชันกระแสสูง" },
    { title:"Jujutsu Kaisen", type:"อนิเมะ", year:"2020", score:8.5, note:"WJB สำรอง: อนิเมะต่อสู้/คำสาป กระแสดี" },
    { title:"Extraction", type:"หนัง", year:"2020", score:7.0, note:"WJB สำรอง: หนังแอ็กชันดูง่าย" },
    { title:"The Old Guard", type:"หนัง", year:"2020", score:6.7, note:"WJB สำรอง: แอ็กชันแฟนตาซี" }
  ],
  disney: [
    { title:"Loki", type:"ซีรีส์", year:"2021", score:8.2, note:"WJB สำรอง: ซูเปอร์ฮีโร่/มัลติเวิร์ส ดูต่อเนื่องสนุก" },
    { title:"The Mandalorian", type:"ซีรีส์", year:"2019", score:8.6, note:"WJB สำรอง: ไซไฟผจญภัยในจักรวาลอวกาศ" },
    { title:"Moving", type:"ซีรีส์", year:"2023", score:8.5, note:"WJB สำรอง: เกาหลีพลังพิเศษ/ดราม่า/แอ็กชัน" },
    { title:"A Shop for Killers", type:"ซีรีส์", year:"2024", score:8.0, note:"WJB สำรอง: แอ็กชันเกาหลีเข้มข้น" },
    { title:"Inside Out", type:"หนัง", year:"2015", score:8.1, note:"WJB สำรอง: แอนิเมชันครอบครัว ดูง่าย" },
    { title:"Soul", type:"หนัง", year:"2020", score:8.0, note:"WJB สำรอง: แอนิเมชันอบอุ่น แนวชีวิต" }
  ],
  trueid: [
    { title:"บุพเพสันนิวาส", type:"ซีรีส์", year:"2018", score:8.4, note:"WJB สำรอง: ละครไทยพีเรียดยอดนิยม กระแสสูง" },
    { title:"พรหมลิขิต", type:"ซีรีส์", year:"2023", score:8.0, note:"WJB สำรอง: ภาคต่อสายละครไทยพีเรียด" },
    { title:"ฉลาดเกมส์โกง", type:"หนัง", year:"2017", score:8.0, note:"WJB สำรอง: หนังไทยแนวระทึก/วัยเรียน" },
    { title:"หลานม่า", type:"หนัง", year:"2024", score:8.3, note:"WJB สำรอง: หนังไทยดราม่าครอบครัว" },
    { title:"ธี่หยด", type:"หนัง", year:"2023", score:7.3, note:"WJB สำรอง: หนังไทยสยองขวัญ" },
    { title:"สัปเหร่อ", type:"หนัง", year:"2023", score:7.8, note:"WJB สำรอง: หนังไทยดราม่าคอมเมดี้" },
    { title:"แฟนฉัน", type:"หนัง", year:"2003", score:7.9, note:"WJB สำรอง: หนังไทยคลาสสิก" },
    { title:"องค์บาก", type:"หนัง", year:"2003", score:7.1, note:"WJB สำรอง: หนังแอ็กชันไทย" }
  ],
  wetv: [
    { title:"The Untamed", type:"ซีรีส์", year:"2019", score:8.4, note:"WJB สำรอง: ซีรีส์จีนกำลังภายใน/แฟนตาซี กระแสสูง" },
    { title:"You Are My Glory", type:"ซีรีส์", year:"2021", score:8.3, note:"WJB สำรอง: โรแมนติกจีนยอดนิยม" },
    { title:"Love Like the Galaxy", type:"ซีรีส์", year:"2022", score:8.2, note:"WJB สำรอง: พีเรียดโรแมนซ์จีน เรื่องยาว" },
    { title:"Who Rules The World", type:"ซีรีส์", year:"2022", score:8.0, note:"WJB สำรอง: จอมยุทธ์/โรแมนซ์/การเมือง" },
    { title:"Reset", type:"ซีรีส์", year:"2022", score:8.1, note:"WJB สำรอง: วนลูปเวลา/ระทึกขวัญ" },
    { title:"The Long Ballad", type:"ซีรีส์", year:"2021", score:8.0, note:"WJB สำรอง: พีเรียดย้อนยุคจีน" },
    { title:"Falling Into Your Smile", type:"ซีรีส์", year:"2021", score:7.9, note:"WJB สำรอง: อีสปอร์ตโรแมนซ์จีน" },
    { title:"Ancient Love Poetry", type:"ซีรีส์", year:"2021", score:7.8, note:"WJB สำรอง: เทพเซียน โรแมนซ์ แฟนตาซีจีน" }
  ],
  iqiyi: [
    { title:"Love Between Fairy and Devil", type:"ซีรีส์", year:"2022", score:8.5, note:"WJB สำรอง: เทพเซียนโรแมนซ์จีน" },
    { title:"Story of Yanxi Palace", type:"ซีรีส์", year:"2018", score:8.6, note:"WJB สำรอง: พีเรียดวังหลวงจีน" },
    { title:"The Bad Kids", type:"ซีรีส์", year:"2020", score:8.4, note:"WJB สำรอง: อาชญากรรม/ลึกลับ" },
    { title:"The Long Night", type:"ซีรีส์", year:"2020", score:8.5, note:"WJB สำรอง: สืบสวนจีนเข้มข้น" },
    { title:"Mysterious Lotus Casebook", type:"ซีรีส์", year:"2023", score:8.4, note:"WJB สำรอง: จอมยุทธ์ผสมสืบสวน" },
    { title:"Strange Tales of Tang Dynasty", type:"ซีรีส์", year:"2022", score:8.2, note:"WJB สำรอง: สืบสวนพีเรียดจีน" },
    { title:"Under the Skin", type:"ซีรีส์", year:"2022", score:8.0, note:"WJB สำรอง: สืบสวนร่วมสมัยจีน" }
  ],
  viu: [
    { title:"Taxi Driver", type:"ซีรีส์", year:"2021", score:8.4, note:"WJB สำรอง: เกาหลีแก้แค้น/แอ็กชัน" },
    { title:"Again My Life", type:"ซีรีส์", year:"2022", score:7.8, note:"WJB สำรอง: เกาหลีแฟนตาซี/กฎหมาย/ย้อนเวลา" },
    { title:"The Penthouse", type:"ซีรีส์", year:"2020", score:8.0, note:"WJB สำรอง: ดราม่าเข้มข้น/แก้แค้น" },
    { title:"Dr. Romantic", type:"ซีรีส์", year:"2016", score:8.4, note:"WJB สำรอง: หมอ/ดราม่า/อบอุ่น" },
    { title:"Running Man", type:"ซีรีส์", year:"2010", score:8.5, note:"WJB สำรอง: วาไรตี้เกาหลีดูเพลิน" }
  ],
  prime: [
    { title:"The Boys", type:"ซีรีส์", year:"2019", score:8.7, note:"WJB สำรอง: ซูเปอร์ฮีโร่สายดาร์ก/เสียดสี" },
    { title:"Invincible", type:"อนิเมะ", year:"2021", score:8.7, note:"WJB สำรอง: แอนิเมชันซูเปอร์ฮีโร่สำหรับผู้ใหญ่" },
    { title:"Reacher", type:"ซีรีส์", year:"2022", score:8.0, note:"WJB สำรอง: แอ็กชันสืบสวน ดูง่าย" },
    { title:"Fallout", type:"ซีรีส์", year:"2024", score:8.3, note:"WJB สำรอง: ไซไฟหลังโลกล่มสลาย" },
    { title:"The Tomorrow War", type:"หนัง", year:"2021", score:6.6, note:"WJB สำรอง: แอ็กชันไซไฟ" }
  ],
  max: [
    { title:"Game of Thrones", type:"ซีรีส์", year:"2011", score:8.8, note:"WJB สำรอง: แฟนตาซีการเมือง/สงคราม" },
    { title:"House of the Dragon", type:"ซีรีส์", year:"2022", score:8.4, note:"WJB สำรอง: แฟนตาซีตระกูลมังกร" },
    { title:"The Last of Us", type:"ซีรีส์", year:"2023", score:8.7, note:"WJB สำรอง: ดราม่าเอาตัวรอดหลังโลกเปลี่ยน" },
    { title:"Chernobyl", type:"ซีรีส์", year:"2019", score:9.3, note:"WJB สำรอง: ดราม่าประวัติศาสตร์เข้มข้น" },
    { title:"Dune", type:"หนัง", year:"2021", score:8.0, note:"WJB สำรอง: ไซไฟมหากาพย์" }
  ],
  apple: [
    { title:"Ted Lasso", type:"ซีรีส์", year:"2020", score:8.8, note:"WJB สำรอง: คอมเมดี้อบอุ่นใจ" },
    { title:"Severance", type:"ซีรีส์", year:"2022", score:8.7, note:"WJB สำรอง: ไซไฟ/ลึกลับ/ออฟฟิศ" },
    { title:"Silo", type:"ซีรีส์", year:"2023", score:8.1, note:"WJB สำรอง: ไซไฟลึกลับในโลกปิด" },
    { title:"Foundation", type:"ซีรีส์", year:"2021", score:7.6, note:"WJB สำรอง: ไซไฟอวกาศ" },
    { title:"CODA", type:"หนัง", year:"2021", score:8.0, note:"WJB สำรอง: ดราม่าครอบครัว/เพลง" }
  ],
  crunchyroll: [
    { title:"Solo Leveling", type:"อนิเมะ", year:"2024", score:8.4, note:"WJB สำรอง: แอ็กชันแฟนตาซี พระเอกพัฒนาเร็ว" },
    { title:"Demon Slayer", type:"อนิเมะ", year:"2019", score:8.6, note:"WJB สำรอง: อนิเมะแอ็กชันกระแสสูง" },
    { title:"Jujutsu Kaisen", type:"อนิเมะ", year:"2020", score:8.5, note:"WJB สำรอง: ต่อสู้/คำสาป/โรงเรียน" },
    { title:"Attack on Titan", type:"อนิเมะ", year:"2013", score:9.0, note:"WJB สำรอง: แอ็กชันดาร์กแฟนตาซี" },
    { title:"Frieren: Beyond Journey's End", type:"อนิเมะ", year:"2023", score:9.0, note:"WJB สำรอง: แฟนตาซีผจญภัย/อบอุ่น/ลึกซึ้ง" },
    { title:"One Piece", type:"อนิเมะ", year:"1999", score:8.7, note:"WJB สำรอง: ผจญภัยยาว ดูได้เรื่อย ๆ" }
  ]
};

function getFallbackPlatformTrending(platformKey, mediaType, page = 1, options = {}){
  const list = PLATFORM_FALLBACK_TRENDING[platformKey] || [];
  if(!list.length) return [];
  const desiredKind = options.animeOnly ? "anime" : (mediaType === "movie" ? "movie" : "series");
  const filtered = list.filter(item => {
    const kind = item.type === "หนัง" ? "movie" : (item.type === "อนิเมะ" ? "anime" : "series");
    return desiredKind === kind;
  });
  const start = (page - 1) * 20;
  const selected = filtered.slice(start, start + 20);
  const platformLabel = TRENDING_PLATFORMS[platformKey]?.label || platformKey;
  return selected.map((item, idx) => {
    const globalIndex = start + idx;
    const score = Number(item.score) || 7;
    return {
      source: "WJB สำรอง",
      platform: platformLabel,
      kind: item.type === "หนัง" ? "movie" : (item.type === "อนิเมะ" ? "anime" : "series"),
      type: item.type || "ซีรีส์",
      title: item.title,
      altTitle: "",
      poster: getStoredPoster(item) || "",
      year: item.year || "",
      releaseInfo: item.year ? `ปี ${item.year}` : "",
      total: "",
      note: item.note || `รายการแนะนำสำรองสำหรับ ${platformLabel} เนื่องจาก TMDB อาจไม่มี provider ประเทศไทยครบ`,
      rawPopularity: Math.max(1, 1000 - (globalIndex * 25) + (score * 10)),
      ratingScore: `${score.toFixed(1)}/10`,
      ratingCount: "ข้อมูลแนะนำสำรอง",
      rankText: `คะแนนแนะนำ ${score.toFixed(1)}/10`,
      isFallback: true
    };
  });
}

function mapTmdbResults(results, mediaType, platformLabel = "ออนไลน์", animeOnly = false){
  return (results || []).map(x => {
    const isMovie = mediaType === "movie";
    const title = x.title || x.name || x.original_title || x.original_name || "";
    const year = String(x.release_date || x.first_air_date || "").slice(0,4);
    return {
      source: "TMDB",
      platform: platformLabel,
      kind: animeOnly ? "anime" : (isMovie ? "movie" : "series"),
      type: animeOnly ? "อนิเมะ" : (isMovie ? "หนัง" : "ซีรีส์"),
      title,
      altTitle: (x.original_title || x.original_name || "") !== title ? (x.original_title || x.original_name || "") : "",
      poster: x.poster_path ? `https://image.tmdb.org/t/p/w500${x.poster_path}` : "",
      year,
      releaseInfo: year ? `ปี ${year}` : "",
      total: "",
      note: x.overview ? String(x.overview).slice(0, 260) : "",
      rawPopularity: Number(x.popularity) || 0,
      ratingScore: x.vote_average ? `${Number(x.vote_average).toFixed(1)}/10` : "ไม่พบคะแนน",
      ratingCount: x.vote_count ? `${Number(x.vote_count).toLocaleString("th-TH")} โหวต` : "",
      rankText: x.vote_average ? `คะแนน ${Number(x.vote_average).toFixed(1)}/10` : ""
    };
  });
}


function getTrendingItemKey(item){
  return `${item?.source || ""}-${item?.platform || ""}-${item?.kind || ""}-${String(item?.title || "").trim().toLowerCase()}-${item?.year || ""}`;
}

function isTrendingItemAlreadyAdded(item){
  const title = String(item?.title || "").trim().toLowerCase();
  const type = item?.type || "";
  if(!title) return false;
  return (items || []).some(existing =>
    String(existing.title || "").trim().toLowerCase() === title &&
    (!type || existing.type === type)
  );
}

function showTrendingAddedToast(title){
  let toast = document.getElementById("trendingAddedToast");
  const box = document.querySelector(".trending-box");
  if(!toast && box){
    toast = document.createElement("div");
    toast.id = "trendingAddedToast";
    toast.className = "trend-added-toast";
    box.insertBefore(toast, box.firstChild.nextSibling);
  }
  if(!toast) return;
  toast.innerHTML = `✅ เพิ่ม <b>${escapeText(title || "รายการนี้")}</b> เข้าลิสต์แล้ว — เลื่อนต่อจากตำแหน่งเดิมได้เลย`;
  toast.style.display = "block";
  clearTimeout(window.__trendToastTimer);
  window.__trendToastTimer = setTimeout(() => {
    if(toast) toast.style.display = "none";
  }, 3500);
}

function renderTrendingExplorer(){
  const content = $("trendingContent");
  if(!content) return;
  const basePool = trendingItems.filter(x => trendingType === "all" || x.kind === trendingType);
  const sorted = getSortedTrendingVisible();
  content.classList.toggle("compact-trending", trendingCompactView);

  const countBox = $("trendResultCount");
  if(countBox){
    const searchText = trendingSearchKeyword ? ` · ค้นหา: “${escapeText(trendingSearchKeyword)}”` : "";
    countBox.innerHTML = `แสดง ${sorted.length.toLocaleString("th-TH")} รายการ จากที่โหลดแล้ว ${basePool.length.toLocaleString("th-TH")} รายการ${searchText}`;
  }

  if(!basePool.length){
    const platformText = TRENDING_PLATFORMS[trendingPlatform]?.label || "แหล่งนี้";
    const help = trendingPlatform === "all"
      ? "กด “โหลดเพิ่ม” หรือ “รีเฟรช”"
      : `ยังไม่พบข้อมูลจาก ${platformText} ในฐานข้อมูล TMDB ประเทศไทย อาจเป็นเพราะแพลตฟอร์มนี้ไม่ได้เปิดข้อมูล provider ใน TMDB ครบทุกเรื่อง`;
    content.innerHTML = `<div class="empty">${help}</div>`;
    return;
  }

  if(!sorted.length){
    content.innerHTML = `<div class="empty">ไม่พบเรื่องที่ค้นหาในรายการที่โหลดแล้ว ลองเปลี่ยนคำค้น หรือกดโหลดเพิ่ม</div>`;
    return;
  }

  const maxScore = Math.max(...sorted.map(x => Number(x.rawPopularity) || 1), 1);
  content.innerHTML = sorted.map((item, index) => trendingCardHTML(item, index, maxScore)).join("");
  if($("trendLoadMoreBtn")) $("trendLoadMoreBtn").style.display = basePool.length >= 20 ? "block" : "none";
}


const WJB_POSTER_MEMORY_KEY = "wjb_poster_memory_v1";
let wjbPosterEnriching = false;
let wjbPosterAutoTimer = null;

function normalizePosterLookupText(text){
  return String(text || "").toLowerCase().replace(/[^a-z0-9\u0E00-\u0E7F]+/g, " ").trim();
}

const WJB_POSTER_MEMORY_MAX_ENTRIES = 100; // กันข้อมูลบวมไม่จำกัดใน localStorage

function getPosterMemory(){
  return wjbStorageGetJSON(WJB_POSTER_MEMORY_KEY, {}) || {};
}

function savePosterMemory(memory){
  wjbStorageSetJSON(WJB_POSTER_MEMORY_KEY, wjbCapObjectEntries(memory || {}, WJB_POSTER_MEMORY_MAX_ENTRIES));
}

function getPosterKey(item){
  const title = normalizePosterLookupText(item?.title || "");
  const year = String(item?.year || item?.releaseInfo || "").match(/\d{4}/)?.[0] || "";
  return `${title}|${year}`;
}

function getStoredPoster(item){
  const memory = getPosterMemory();
  const key = getPosterKey(item);
  const titleOnly = normalizePosterLookupText(item?.title || "") + "|";
  return memory[key] || memory[titleOnly] || "";
}

function rememberPoster(item, poster){
  if(!poster) return;
  const key = getPosterKey(item);
  if(!key || key === "|") return;
  const memory = getPosterMemory();
  memory[key] = poster;
  savePosterMemory(memory);
}

function isLikelySameTitle(a, b){
  const x = normalizePosterLookupText(a);
  const y = normalizePosterLookupText(b);
  if(!x || !y) return false;
  if(x === y) return true;
  if(x.length >= 5 && y.includes(x)) return true;
  if(y.length >= 5 && x.includes(y)) return true;
  const xs = new Set(x.split(/\s+/).filter(t => t.length > 2));
  const ys = y.split(/\s+/).filter(t => t.length > 2);
  if(!xs.size || !ys.length) return false;
  const hit = ys.filter(t => xs.has(t)).length;
  return hit >= Math.min(2, Math.max(1, Math.ceil(Math.min(xs.size, ys.length) * 0.6)));
}

async function searchWikipediaPoster(keyword){
  const langs = ["en", "th"];
  for(const lang of langs){
    try{
      const url = `https://${lang}.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(keyword)}&gsrlimit=3&prop=pageimages&piprop=thumbnail&pithumbsize=600&format=json&origin=*`;
      const res = await fetch(url);
      if(!res.ok) continue;
      const data = await res.json();
      const pages = Object.values(data.query?.pages || {});
      const found = pages.find(p => p.thumbnail?.source && isLikelySameTitle(keyword, p.title)) || pages.find(p => p.thumbnail?.source);
      if(found?.thumbnail?.source) return found.thumbnail.source;
    }catch(_e){}
  }
  return "";
}

async function findPosterForItem(item){
  const stored = getStoredPoster(item);
  if(stored) return stored;
  const title = item?.title || "";
  if(!title) return "";
  const year = String(item?.year || item?.releaseInfo || "").match(/\d{4}/)?.[0] || "";
  const type = item?.type || "";
  const candidates = [];

  async function collect(fn){
    try{
      const rows = await fn(title);
      (rows || []).forEach(r => {
        if(r?.poster && (!year || !r.year || String(r.year) === year || isLikelySameTitle(title, r.title) || isLikelySameTitle(title, r.altTitle))){
          candidates.push(r);
        }
      });
    }catch(_e){}
  }

  if(type === "อนิเมะ"){
    await collect(searchAnimeJikan);
    await collect(searchAniListAnime);
    await collect(searchKitsuAnime);
  }

  if(type === "ซีรีส์" || type === "อื่นๆ"){
    await collect(searchTvMaze);
  }

  if(type === "หนัง" || type === "อื่นๆ"){
    await collect(searchITunesMovie);
  }

  // TMDB ถูกปิดตามกฎ Free 100% / No user API key
  await collect(searchTmdbMulti);

  const best = candidates.find(r => isLikelySameTitle(title, r.title) || isLikelySameTitle(title, r.altTitle)) || candidates[0];
  if(best?.poster){
    rememberPoster(item, best.poster);
    return best.poster;
  }

  const wikiPoster = await searchWikipediaPoster(title);
  if(wikiPoster){
    rememberPoster(item, wikiPoster);
    return wikiPoster;
  }
  return "";
}

async function enrichMissingTrendingPosters(list){
  if(wjbPosterEnriching) return false;
  const targets = (list || trendingItems || [])
    .filter(x => x && !x.poster && (x.isFallback || x.source === "WJB สำรอง"))
    .slice(0, 8);
  if(!targets.length) return false;
  wjbPosterEnriching = true;
  let changed = false;
  try{
    for(const item of targets){
      const poster = await findPosterForItem(item);
      if(poster && !item.poster){
        item.poster = poster;
        item.posterSource = "Poster Finder";
        changed = true;
      }
      await new Promise(r => setTimeout(r, 220));
    }
  }finally{
    wjbPosterEnriching = false;
  }
  return changed;
}

function schedulePosterEnrichment(list){
  clearTimeout(wjbPosterAutoTimer);
  wjbPosterAutoTimer = setTimeout(async () => {
    const changed = await enrichMissingTrendingPosters(list);
    if(changed) renderTrendingExplorer();
  }, 350);
}

window.findPosterForTrendingItem = async function(index){
  const item = getSortedTrendingVisible()[index];
  if(!item) return;
  const poster = await findPosterForItem(item);
  if(poster){
    item.poster = poster;
    item.posterSource = "Poster Finder";
    renderTrendingExplorer();
  }else{
    wjbToast("ยังหารูปจากแหล่งฟรีไม่เจอครับ ใช้ปก WJB สำรองไปก่อน หรือเพิ่ม URL รูปเองได้");
  }
};

window.addManualPosterForTrendingItem = async function(index){
  const item = getSortedTrendingVisible()[index];
  if(!item) return;
  const url = await wjbPromptModal({
    title: "วางลิงก์รูปโปสเตอร์",
    hint: "ระบบจะจำไว้ในเครื่องนี้และใช้ตอนเพิ่มเข้าลิสต์",
    placeholder: "https://...",
    value: item.poster || getStoredPoster(item) || "",
    okText: "บันทึกลิงก์"
  });
  if(url === null) return;
  const poster = url.trim();
  if(!poster) return;
  item.poster = poster;
  item.posterSource = "Poster Memory";
  rememberPoster(item, poster);
  renderTrendingExplorer();
};

function getWJBPosterPlaceholder(item){
  const label = encodeURIComponent((item?.platform || item?.type || "WJB").slice(0, 12));
  const title = encodeURIComponent(String(item?.title || "WJB").slice(0, 18));
  return `data:image/svg+xml;charset=UTF-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='240' height='340' viewBox='0 0 240 340'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop stop-color='%230ea5e9'/%3E%3Cstop offset='1' stop-color='%231e3a8a'/%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='240' height='340' rx='26' fill='url(%23g)'/%3E%3Crect x='18' y='18' width='204' height='304' rx='22' fill='rgba(15,23,42,.42)' stroke='rgba(255,255,255,.24)'/%3E%3Ctext x='120' y='135' font-size='42' text-anchor='middle' fill='white'%3EWJB%3C/text%3E%3Ctext x='120' y='180' font-size='18' text-anchor='middle' fill='white'%3E${label}%3C/text%3E%3Ctext x='120' y='215' font-size='14' text-anchor='middle' fill='rgba(255,255,255,.82)'%3E${title}%3C/text%3E%3C/svg%3E`;
}

function trendingCardHTML(item, index, maxScore){
  const percent = Math.max(1, Math.min(100, Math.round(((Number(item.rawPopularity) || 1) / maxScore) * 100)));
  const poster = item.poster || getStoredPoster(item) || getWJBPosterPlaceholder(item);
  const posterTools = (!item.poster && (item.isFallback || item.source === "WJB สำรอง"))
    ? `<button class="gray mini" onclick="findPosterForTrendingItem(${index})">ค้นรูปฟรี</button><button class="gray mini" onclick="addManualPosterForTrendingItem(${index})">ใส่รูปเอง</button>`
    : "";
  const alt = item.altTitle ? `<p class="trend-alt">${escapeText(item.altTitle)}</p>` : "";
  const note = item.note ? `<p class="trend-desc">${escapeText(item.note)}</p>` : "";
  const year = item.releaseInfo || item.year || "ไม่ระบุปี";
  const safeTitle = escapeText(item.title || "ไม่ระบุชื่อ");
  const platformText = item.platform && item.platform !== "ออนไลน์" ? item.platform : "ออนไลน์ / รวมแหล่ง";
  const platformBadge = `<span class="trend-platform">${escapeText(platformText)}</span>`;
  const ratingText = item.ratingScore || (item.rankText ? item.rankText.replace("คะแนน ", "") : "ไม่พบคะแนน");
  const ratingCount = item.ratingCount ? ` · ${escapeText(item.ratingCount)}` : "";
  const rawText = Math.round(Number(item.rawPopularity) || 0).toLocaleString("th-TH");
  const isAdded = trendingAddedKeys.has(getTrendingItemKey(item)) || isTrendingItemAlreadyAdded(item);
  return `
    <div id="trend-card-${index + 1}" class="trend-card${trendingCompactView ? " trend-card-compact" : ""}">
      <div class="trend-rank">#${index + 1}</div>
      <img class="trend-poster" src="${escapeText(poster)}" alt="">
      <div class="trend-info">
        <div class="trend-topline"><span class="badge">${escapeText(item.type)}</span>${platformBadge}<span>${escapeText(item.source)}</span></div>
        <h3>${safeTitle}</h3>
        ${alt}
        <p class="muted">${escapeText(year)}</p>
        <div class="trend-meta-grid">
          <div><small>ค้นหา/นิยม</small><b>${percent}%</b></div>
          <div><small>ช่องทาง</small><b>${escapeText(platformText)}</b></div>
          <div><small>คะแนนคนดู</small><b>${escapeText(ratingText)}</b></div>
        </div>
        <div class="trend-score-row"><b>ดัชนีความนิยม ${percent}%</b><span>${rawText}${ratingCount}</span></div>
        <div class="trend-progress"><div style="width:${percent}%"></div></div>
        ${note}
        <div class="trend-actions">
          <button onclick="useTrendingItem(${index})">เลือกไปกรอกฟอร์ม</button>
          ${isAdded ? `<button class="trend-added-btn" disabled>✅ เพิ่มแล้ว</button>` : `<button class="gray" onclick="quickAddTrendingItem(${index})">+ เพิ่มเข้าลิสต์</button>`}
          ${posterTools}
        </div>
      </div>
    </div>`;
}

function getSortedTrendingVisible(){
  let pool = trendingItems.filter(x => trendingType === "all" || x.kind === trendingType);
  if(trendingSearchKeyword){
    pool = pool.filter(x => `${x.title || ""} ${x.altTitle || ""} ${x.platform || ""} ${x.type || ""}`.toLowerCase().includes(trendingSearchKeyword));
  }
  const sf = (typeof getWJBSmartFilters === "function") ? getWJBSmartFilters() : {};
  if(sf.hideAdded){
    pool = pool.filter(x => !(trendingAddedKeys.has(getTrendingItemKey(x)) || isTrendingItemAlreadyAdded(x)));
  }
  if(sf.onlyNoPoster){
    pool = pool.filter(x => !x.poster);
  }
  if(sf.onlyNoScore){
    pool = pool.filter(x => {
      const rating = String(x.ratingScore || x.rankText || x.score || "").trim();
      return !rating || rating.includes("ไม่พบคะแนน") || rating === "-";
    });
  }
  return [...pool].sort((a,b)=>(b.rawPopularity || 0) - (a.rawPopularity || 0)).slice(0, 1000);
}

window.useTrendingItem = function(index){
  const item = getSortedTrendingVisible()[index];
  if(!item) return;
  closeTrendingExplorer();
  if($('title')) $('title').value = item.title || "";
  if($('type')) $('type').value = item.type || "อนิเมะ";
  if($('season')) $('season').value = item.type === "หนัง" ? "" : "ซีซั่น 1";
  if($('releaseInfo')) $('releaseInfo').value = item.releaseInfo || "";
  if($('total')) $('total').value = item.total || "";
  if($('episode')) $('episode').value = "";
  if($('status')) $('status').value = "อยากดู";
  if($('score')) $('score').value = "";
  if($('note')) $('note').value = item.note || `เลือกจากหน้าเทรนด์ WJB (${item.source})`;
  if($('episodeMode')) $('episodeMode').value = item.total ? "manual" : "ongoing";
  smartPoster = item.poster || "";
  toggleEpisodeFields();
  backToAdd();
  setTimeout(() => {
    try{ wjbJumpToFormDetails("season"); }catch(_e){
      try{ window.scrollTo({ top: $('wjbFormDetailsStart')?.offsetTop || $('formBox')?.offsetTop || 0, behavior: 'smooth' }); }catch(__e){}
    }
  }, 180);
};

window.quickAddTrendingItem = async function(index){
  if(!currentUser){ wjbToast("กรุณาเข้าสู่ระบบก่อน"); return; }
  const item = getSortedTrendingVisible()[index];
  if(!item) return;

  const scrollBox = document.querySelector(".trending-box");
  const oldScrollTop = scrollBox ? scrollBox.scrollTop : 0;
  const itemKey = getTrendingItemKey(item);

  if(trendingAddedKeys.has(itemKey) || isTrendingItemAlreadyAdded(item)){
    trendingAddedKeys.add(itemKey);
    renderTrendingExplorer();
    if(scrollBox) setTimeout(() => { scrollBox.scrollTop = oldScrollTop; }, 0);
    showTrendingAddedToast(item.title || "รายการนี้");
    return;
  }

  try{
    if(!item.poster){
      const foundPoster = getStoredPoster(item) || await findPosterForItem(item);
      if(foundPoster) item.poster = foundPoster;
    }
    const ref = await addDoc(collection(db, "watchItems"), {
      title: item.title || "",
      poster: item.poster || getStoredPoster(item) || "",
      season: item.type === "หนัง" ? "" : "ซีซั่น 1",
      releaseInfo: item.releaseInfo || "",
      episode: "",
      total: item.total || "",
      episodeMode: item.total ? "manual" : "ongoing",
      type: item.type || "อื่นๆ",
      status: "อยากดู",
      score: "",
      note: item.note || `เพิ่มจากหน้าเทรนด์ WJB (${item.source})`,
      isPublic: true,
      ownerId: currentUser.uid,
      ownerName: currentUser.displayName || currentUser.email,
      ownerEmail: currentUser.email,
      date: new Date().toLocaleDateString("th-TH"),
      createdMs: Date.now(),
      favorite: false,
      source: item.source || "Trending",
      trendScore: Math.round(Number(item.rawPopularity) || 0),
      trendPlatform: item.platform || "",
      updatedAt: serverTimestamp()
    });

    await logActivity("add_item", { itemId: ref.id, itemTitle: item.title, type: item.type, source: item.source || "Trending", platform: item.platform || "" });
    trendingAddedKeys.add(itemKey);
    if($("search")) $("search").value = "";
    await loadMyItems();

    // ไม่ปิดหน้าเทรนด์ ไม่เด้งไปลิสต์ใหม่ และคืนตำแหน่ง scroll เดิม
    renderTrendingExplorer();
    setTimeout(() => {
      const freshScrollBox = document.querySelector(".trending-box");
      if(freshScrollBox) freshScrollBox.scrollTop = oldScrollTop;
      showTrendingAddedToast(item.title || "รายการนี้");
    }, 0);
  }catch(e){
    wjbToast("เพิ่มรายการไม่สำเร็จ: " + e.message);
  }
};


// ===== WJB Personal AI v1 + AI Brain v2 =====
let personalAITab = "forYou";
let personalAICandidates = [];

function aiTextOf(item = {}){
  return [
    item.title, item.altTitle, item.type, item.note, item.releaseInfo, item.platform,
    item.source, item.rankText, item.ratingScore
  ].filter(Boolean).join(" ").toLowerCase();
}

const AI_FEATURES = {
  isekai: ["isekai","another world","different world","ต่างโลก","เกิดใหม่","reincarnat","reincarnation","transmigrat","転生"],
  opmc: ["overpowered","op mc","powerful","เทพ","โกง","แข็งแกร่ง","ไร้เทียมทาน","solo leveling","level up"],
  magic: ["magic","magical","เวท","เวทมนตร์","จอมเวท","mage","wizard","fantasy","แฟนตาซี"],
  adventure: ["adventure","journey","quest","ผจญภัย","เดินทาง","สำรวจ","ดันเจี้ยน","dungeon"],
  guild: ["guild","กิลด์","party","team","kingdom","สร้างเมือง","สร้างประเทศ","บริหาร","companions"],
  game: ["game","vr","virtual","เกม","ออนไลน์","level","player","sao","log horizon"],
  dark: ["dark","death","dead","kill","murder","revenge","ตาย","แก้แค้น","โหด","เลือด","สยอง","horror"],
  comedy: ["comedy","funny","ฮา","ตลก","เบาสมอง","parody","slice of life"],
  romance: ["romance","love","รัก","โรแมนซ์","แฟน","หัวใจ","relationship"],
  school: ["school","academy","student","โรงเรียน","นักเรียน","อคาเดมี","classroom"],
  action: ["action","battle","fight","war","ต่อสู้","สงคราม","แอคชั่น","พลัง","martial"],
  mystery: ["mystery","detective","case","secret","ลึกลับ","สืบสวน","คดี","ปริศนา","thriller"],
  timeLoop: ["time loop","loop","ย้อนเวลา","วนลูป","rewind","reset","กลับมา"],
  family: ["family","ครอบครัว","อบอุ่น","healing","heal","slice"],
  chinese: ["จีน","chinese","xianxia","wuxia","ยุทธภพ","เทพเซียน","ราชสำนัก"],
  korean: ["เกาหลี","korean","k-drama","chaebol"],
  thai: ["ไทย","thai","ละครไทย"],
  animeMood: ["anime","อนิเมะ","manga","jikan","ญี่ปุ่น","japanese"]
};

function extractAIStoryFeatures(item = {}){
  const text = aiTextOf(item);
  const features = {};
  Object.entries(AI_FEATURES).forEach(([key, words]) => {
    features[key] = words.some(w => text.includes(String(w).toLowerCase())) ? 1 : 0;
  });
  if(item.type === "อนิเมะ") features.animeMood = 1;
  if(item.type === "หนัง") features.movie = 1;
  if(item.type === "ซีรีส์") features.series = 1;
  return features;
}

function featureScore(a = {}, b = {}){
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  let match = 0;
  let total = 0;
  keys.forEach(k => {
    const av = Number(a[k] || 0);
    const bv = Number(b[k] || 0);
    if(av || bv){
      total++;
      if(av && bv) match++;
    }
  });
  if(!total) return 0;
  return Math.round((match / total) * 100);
}

function itemBaseWeight(item = {}){
  let w = 1;
  const score = Number(item.score || 0);
  if(score >= 9) w += 3;
  else if(score >= 8) w += 2;
  else if(score >= 7) w += 1;
  if(item.favorite) w += 2;
  if(item.status === "ดูจบแล้ว") w += 1.5;
  if(item.status === "กำลังดู") w += 1;
  if(item.status === "ดองไว้") w -= .4;
  return Math.max(.2, w);
}

function analyzePersonalTaste(){
  const taste = {};
  const source = (items || []).filter(Boolean);
  source.forEach(item => {
    const f = extractAIStoryFeatures(item);
    const w = itemBaseWeight(item);
    Object.entries(f).forEach(([k,v]) => {
      if(v) taste[k] = (taste[k] || 0) + w;
    });
  });
  return taste;
}

function getTopTasteWords(taste){
  const label = {
    isekai:"ต่างโลก/เกิดใหม่", opmc:"ตัวเอกเทพ", magic:"เวทมนตร์/แฟนตาซี", adventure:"ผจญภัย",
    guild:"สร้างทีม/กิลด์", game:"โลกเกม", dark:"ดาร์ก/ลุ้นระทึก", comedy:"ตลก",
    romance:"โรแมนซ์", school:"โรงเรียน", action:"ต่อสู้", mystery:"สืบสวน/ลึกลับ",
    timeLoop:"วนลูปเวลา", family:"อบอุ่นครอบครัว", chinese:"จีน/พีเรียดจีน", korean:"เกาหลี", thai:"ไทย", animeMood:"อนิเมะ"
  };
  return Object.entries(taste).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([k])=>label[k] || k);
}

function isCandidateAlreadyInMyList(candidate){
  const t = String(candidate?.title || "").trim().toLowerCase();
  if(!t) return false;
  return (items || []).some(i => String(i.title || "").trim().toLowerCase() === t);
}

async function ensurePersonalAICandidates(){
  if(personalAICandidates.length >= 30) return personalAICandidates;
  let pool = [...(trendingItems || [])];
  if(pool.length < 30){
    try{
      const results = await Promise.allSettled([
        fetchTrendingAnime(1),
        fetchPlatformTrendingTmdb("movie", 1, "netflix"),
        fetchPlatformTrendingTmdb("tv", 1, "netflix"),
        fetchPlatformTrendingTmdb("movie", 1, "disney"),
        fetchPlatformTrendingTmdb("tv", 1, "iqiyi"),
        fetchPlatformTrendingTmdb("tv", 1, "wetv"),
        fetchPlatformTrendingTmdb("movie", 1, "trueid")
      ]);
      pool = pool.concat(results.filter(r => r.status === "fulfilled").flatMap(r => r.value || []));
    }catch(_e){}
  }
  const seen = new Set();
  personalAICandidates = pool.filter(x => {
    const key = `${String(x.title||"").toLowerCase()}-${x.year||""}-${x.type||""}`;
    if(!x.title || seen.has(key)) return false;
    seen.add(key);
    return true;
  }).slice(0, 500);
  return personalAICandidates;
}

function scoreCandidateForUser(candidate, taste){
  const f = extractAIStoryFeatures(candidate);
  let score = 0;
  let reason = [];
  Object.entries(taste).forEach(([k,w]) => {
    if(f[k]) score += Math.min(35, w * 10);
  });
  const rawPop = Number(candidate.rawPopularity || candidate.trendScore || 0);
  if(rawPop) score += Math.min(18, Math.log10(rawPop + 10) * 4);
  const rating = parseFloat(String(candidate.ratingScore || "").replace("/10", ""));
  if(rating >= 8) score += 10;
  if(!isCandidateAlreadyInMyList(candidate)) score += 8;
  const top = getTopTasteWords(Object.fromEntries(Object.entries(f).filter(([,v])=>v))).slice(0,3);
  reason = top.length ? top : [candidate.type || "แนวที่ใกล้เคียง"];
  return { score: Math.max(1, Math.min(99, Math.round(score))), reason };
}

function aiRecommendationCard(item, index, score, reason, mode="personal"){
  const poster = item.poster || "https://via.placeholder.com/120x170?text=WJB";
  const year = item.releaseInfo || item.year || "ไม่ระบุปี";
  const platform = item.platform || item.trendPlatform || item.source || "ออนไลน์";
  const note = item.note ? `<p class="ai-desc">${escapeText(String(item.note).slice(0,180))}</p>` : "";
  return `
    <div class="ai-rec-card">
      <div class="ai-rec-rank">#${index + 1}</div>
      <img src="${escapeText(poster)}" alt="">
      <div class="ai-rec-info">
        <div class="ai-rec-top"><span class="badge">${escapeText(item.type || "แนะนำ")}</span><span>${escapeText(platform)}</span></div>
        <h3>${escapeText(item.title || "ไม่ระบุชื่อ")}</h3>
        <p class="muted">${escapeText(year)} · ${escapeText(item.ratingScore || item.rankText || "")}</p>
        <div class="ai-match"><b>${score}% match</b><span>${escapeText(reason.join(" + "))}</span></div>
        <div class="ai-match-bar"><div style="width:${score}%"></div></div>
        ${note}
        <div class="trend-actions">
          <button onclick="useAIRecommendation('${mode}', ${index})">เลือกไปกรอกฟอร์ม</button>
          <button class="gray" onclick="quickAddAIRecommendation('${mode}', ${index})">+ เพิ่มเข้าลิสต์</button>
        </div>
      </div>
    </div>`;
}

window.openPersonalAI = async function(){
  if(!currentUser) return wjbToast("กรุณาเข้าสู่ระบบก่อน");
  const modal = $("personalAIModal");
  if(modal) modal.style.display = "flex";
  const content = $("personalAIContent");
  if(content) content.innerHTML = `<div class="trend-loading">AI กำลังวิเคราะห์รสนิยมและเนื้อเรื่อง...</div>`;
  await ensurePersonalAICandidates();
  renderPersonalAITab(personalAITab || "forYou");
};

window.closePersonalAI = function(){
  const modal = $("personalAIModal");
  if(modal) modal.style.display = "none";
};

window.refreshPersonalAI = async function(){
  personalAICandidates = [];
  await openPersonalAI();
};

window.renderPersonalAITab = function(tab){
  personalAITab = tab;
  const btnMap = { forYou:"aiForYouBtn", similar:"aiSimilarBtn", mood:"aiMoodBtn" };
  Object.values(btnMap).forEach(id => { if($(id)) $(id).classList.add("gray"); });
  if($(btnMap[tab])) $(btnMap[tab]).classList.remove("gray");
  if(tab === "similar") return renderSimilarStoryAI();
  if(tab === "mood") return renderMoodAI();
  return renderForYouAI();
};

function renderForYouAI(){
  const content = $("personalAIContent");
  if(!content) return;
  const taste = analyzePersonalTaste();
  const topTaste = getTopTasteWords(taste);
  if(!items.length){
    content.innerHTML = `<div class="empty">ยังไม่มีข้อมูลในลิสต์ของฉัน ให้เพิ่ม/ให้คะแนนสัก 3-5 เรื่องก่อน AI จะรู้ใจมากขึ้น</div>`;
    return;
  }
  const scored = (personalAICandidates || [])
    .filter(c => !isCandidateAlreadyInMyList(c))
    .map(c => ({ item:c, ...scoreCandidateForUser(c, taste) }))
    .sort((a,b)=>b.score-a.score)
    .slice(0,20);
  window.aiForYouResults = scored.map(x => x.item);
  content.innerHTML = `
    <div class="ai-taste-box"><b>AI อ่านรสนิยมตอนนี้:</b><p>${topTaste.length ? topTaste.map(escapeText).join(" · ") : "ยังวิเคราะห์ได้ไม่พอ"}</p></div>
    ${scored.length ? scored.map((x,i)=>aiRecommendationCard(x.item,i,x.score,x.reason,"forYou")).join("") : `<div class="empty">ยังไม่มีรายการแนะนำ ลองเปิดหน้าเทรนด์และโหลดเพิ่มก่อน</div>`}
  `;
}

function renderSimilarStoryAI(){
  const content = $("personalAIContent");
  if(!content) return;
  const candidatesBase = [...(items || [])].sort((a,b)=>(b.createdMs||0)-(a.createdMs||0));
  if(!candidatesBase.length){
    content.innerHTML = `<div class="empty">ยังไม่มีเรื่องในลิสต์ให้ใช้เป็นต้นแบบ</div>`;
    return;
  }
  const selectedId = window.aiBaseItemId || candidatesBase[0].id;
  const baseItem = candidatesBase.find(i => i.id === selectedId) || candidatesBase[0];
  window.aiBaseItemId = baseItem.id;
  const baseFeatures = extractAIStoryFeatures(baseItem);
  const candidates = (personalAICandidates || [])
    .filter(c => !isCandidateAlreadyInMyList(c))
    .map(c => {
      const semantic = featureScore(baseFeatures, extractAIStoryFeatures(c));
      const trend = Math.min(10, Math.round(Math.log10((Number(c.rawPopularity)||1)+10)*2));
      return { item:c, score:Math.min(99, semantic + trend), reason:getTopTasteWords(extractAIStoryFeatures(c)).slice(0,3) };
    })
    .filter(x => x.score >= 35)
    .sort((a,b)=>b.score-a.score)
    .slice(0,20);
  window.aiSimilarResults = candidates.map(x => x.item);
  content.innerHTML = `
    <div class="ai-select-box">
      <label>เลือกเรื่องต้นแบบ</label>
      <select onchange="window.aiBaseItemId=this.value; renderSimilarStoryAI();">
        ${candidatesBase.slice(0,120).map(i=>`<option value="${escapeText(i.id)}" ${i.id===baseItem.id?"selected":""}>${escapeText(i.title || "ไม่ระบุ")} ${i.season ? "- " + escapeText(getSeasonDisplayName(i)) : ""}</option>`).join("")}
      </select>
      <p class="muted">AI จะเทียบจากเนื้อเรื่อง/โน้ต/ประเภท ไม่ใช่ชื่ออย่างเดียว</p>
    </div>
    ${candidates.length ? candidates.map((x,i)=>aiRecommendationCard(x.item,i,x.score,x.reason,"similar")).join("") : `<div class="empty">ยังไม่เจอเรื่องคล้ายมากพอ ลองโหลดเทรนด์เพิ่มหรือเลือกเรื่องต้นแบบอื่น</div>`}
  `;
}

function renderMoodAI(){
  const content = $("personalAIContent");
  if(!content) return;
  const taste = analyzePersonalTaste();
  const top = getTopTasteWords(taste);
  const pending = (items||[]).filter(i => i.status === "ดองไว้" || i.status === "อยากดู").sort((a,b)=>(b.createdMs||0)-(a.createdMs||0));
  const nearDone = (items||[]).filter(i => i.type !== "หนัง" && getProgressPercent(i) !== null && getProgressPercent(i) >= 70 && i.status !== "ดูจบแล้ว").sort((a,b)=>getProgressPercent(b)-getProgressPercent(a));
  const highScore = (items||[]).filter(i => Number(i.score) >= 8).sort((a,b)=>Number(b.score)-Number(a.score));
  const pick = nearDone[0] || pending[0] || highScore[0] || (items||[])[0];
  content.innerHTML = `
    <div class="ai-taste-box"><b>วันนี้ AI แนะนำแนว:</b><p>${top.length ? top.join(" · ") : "เพิ่มข้อมูลอีกนิด AI จะเดาแม่นขึ้น"}</p></div>
    <div class="ai-mood-grid">
      <div><b>ดูให้จบเร็ว</b><p>${nearDone[0] ? escapeText(nearDone[0].title) + " · " + getProgressPercent(nearDone[0]) + "%" : "ยังไม่มีเรื่องใกล้จบ"}</p></div>
      <div><b>กลับไปเคลียร์ลิสต์</b><p>${pending[0] ? escapeText(pending[0].title) : "ยังไม่มีเรื่องดอง/อยากดู"}</p></div>
      <div><b>เรื่องที่น่าดูจากคะแนน</b><p>${highScore[0] ? escapeText(highScore[0].title) + " ⭐ " + highScore[0].score : "ยังไม่มีคะแนนสูง"}</p></div>
    </div>
    ${pick ? `<div class="ai-next-watch"><h3>🎯 แนะนำให้ดูต่อ: ${escapeText(pick.title || "")}</h3><p>${escapeText(buildProgressText(pick)).replace(/\n/g,"<br>")}</p><button onclick="closePersonalAI(); focusSavedItem('${pick.id}', '${encodeURIComponent(pick.title || "")}', true)">ไปที่เรื่องนี้</button></div>` : `<div class="empty">ยังไม่มีข้อมูลพอสำหรับแนะนำวันนี้</div>`}
  `;
}

function getAIResult(mode, index){
  if(mode === "similar") return (window.aiSimilarResults || [])[index];
  return (window.aiForYouResults || [])[index];
}

window.useAIRecommendation = function(mode, index){
  const item = getAIResult(mode, index);
  if(!item) return;
  closePersonalAI();
  if($("title")) $("title").value = item.title || "";
  if($("type")) $("type").value = item.type || "อนิเมะ";
  if($("season")) $("season").value = item.type === "หนัง" ? "" : "ซีซั่น 1";
  if($("releaseInfo")) $("releaseInfo").value = item.releaseInfo || "";
  if($("episode")) $("episode").value = "";
  if($("total")) $("total").value = item.total || "";
  if($("status")) $("status").value = "อยากดู";
  if($("note")) $("note").value = item.note || `เลือกจาก WJB Personal AI (${item.source || "AI"})`;
  if($("episodeMode")) $("episodeMode").value = item.total ? "manual" : "ongoing";
  smartPoster = item.poster || "";
  toggleEpisodeFields();
  backToAdd();
};

window.quickAddAIRecommendation = async function(mode, index){
  if(!currentUser) return wjbToast("กรุณาเข้าสู่ระบบก่อน");
  const item = getAIResult(mode, index);
  if(!item) return;
  try{
    const ref = await addDoc(collection(db, "watchItems"), {
      title: item.title || "",
      poster: item.poster || "",
      season: item.type === "หนัง" ? "" : "ซีซั่น 1",
      releaseInfo: item.releaseInfo || "",
      episode: "",
      total: item.total || "",
      episodeMode: item.total ? "manual" : "ongoing",
      type: item.type || "อื่นๆ",
      status: "อยากดู",
      score: "",
      note: item.note || `เพิ่มจาก WJB Personal AI (${item.source || "AI"})`,
      isPublic: true,
      ownerId: currentUser.uid,
      ownerName: currentUser.displayName || currentUser.email,
      ownerEmail: currentUser.email,
      date: new Date().toLocaleDateString("th-TH"),
      createdMs: Date.now(),
      favorite: false,
      source: item.source || "Personal AI",
      trendPlatform: item.platform || "",
      aiRecommended: true,
      updatedAt: serverTimestamp()
    });
    await logActivity("add_item", { itemId: ref.id, itemTitle: item.title, type: item.type, source:"Personal AI" });
    wjbToast("เพิ่มจาก AI เข้าลิสต์แล้ว");
    await loadMyItems();
    renderPersonalAITab(personalAITab);
  }catch(e){
    wjbToast("เพิ่มรายการไม่สำเร็จ: " + e.message);
  }
};

// ===== WJB Guardian AI v1: สมองกลตรวจสุขภาพเว็บ =====
let guardianAutoTimer = null;
let guardianLastResults = [];
const WJB_GUARDIAN_KEY = "wjb_guardian_history_v1";

function guardianStatusLabel(status){
  return status === "ok" ? "ปกติ" : status === "warn" ? "ควรตรวจ" : "พบปัญหา";
}
function guardianStatusIcon(status){
  return status === "ok" ? "✅" : status === "warn" ? "⚠️" : "❌";
}
function guardianSeverityScore(status){
  return status === "error" ? 2 : status === "warn" ? 1 : 0;
}
function guardianAddResult(list, status, title, detail, fix = ""){
  list.push({ status, title, detail, fix, createdMs: Date.now() });
}
async function guardianSafeCheck(title, fn, list){
  try{
    const result = await fn();
    if(result) guardianAddResult(list, result.status || "ok", title, result.detail || "ปกติ", result.fix || "");
  }catch(e){
    guardianAddResult(list, "error", title, e.message || String(e), "ตรวจ Console / Firebase Rules / API key หรือรีเฟรชหน้าเว็บแล้วลองใหม่");
  }
}
function saveGuardianHistory(results){
  const old = wjbStorageGetJSON(WJB_GUARDIAN_KEY, []) || [];
  old.unshift({ createdMs: Date.now(), results });
  wjbStorageSetJSON(WJB_GUARDIAN_KEY, old.slice(0, 20));
}
function getGuardianHistory(){
  return wjbStorageGetJSON(WJB_GUARDIAN_KEY, []) || [];
}
function guardianExpectedElements(){
  return [
    ["authBox", "กล่องเข้าสู่ระบบ"], ["mainApp", "หน้าหลัก"], ["userBox", "เมนูผู้ใช้"],
    ["list", "พื้นที่รายการ"], ["title", "ช่องชื่อเรื่อง"], ["saveBtn", "ปุ่มเพิ่มรายการ"],
    ["trendingModal", "หน้าเทรนด์"], ["personalAIModal", "หน้า AI แนะนำ"], ["adminModal", "Admin Panel"],
    ["search", "ช่องค้นหา"], ["formBox", "ฟอร์มเพิ่มรายการ"]
  ];
}
async function runGuardianCoreChecks(){
  const results = [];

  await guardianSafeCheck("โครงหน้าเว็บ/ปุ่มสำคัญ", async () => {
    const missing = guardianExpectedElements().filter(([id]) => !$(id)).map(([,name]) => name);
    if(missing.length) return { status:"error", detail:`ไม่พบองค์ประกอบ: ${missing.join(", ")}`, fix:"ไฟล์ index.html อาจไม่ตรงกับ script.js หรืออัปโหลดไฟล์ไม่ครบ" };
    return { status:"ok", detail:"องค์ประกอบหลักครบ" };
  }, results);

  await guardianSafeCheck("สถานะ Login / Auth", async () => {
    if(!currentUser) return { status:"warn", detail:"ยังไม่ได้เข้าสู่ระบบ จึงตรวจ Firestore เชิงลึกไม่ได้", fix:"ล็อกอินก่อน แล้วกดตรวจอีกครั้ง" };
    return { status:"ok", detail:`ล็อกอินอยู่: ${currentUser.email || currentUser.uid}` };
  }, results);

  await guardianSafeCheck("LocalStorage / Draft / Cache", async () => {
    const key = "wjb_guardian_test";
    localStorage.setItem(key, "1");
    const ok = localStorage.getItem(key) === "1";
    localStorage.removeItem(key);
    return ok ? { status:"ok", detail:"บันทึกข้อมูลในเครื่องได้" } : { status:"warn", detail:"localStorage อาจถูกปิด", fix:"ตรวจโหมด Private หรือการตั้งค่า browser" };
  }, results);

  if(currentUser){
    await guardianSafeCheck("Firestore: users/{uid}", async () => {
      const snap = await getDoc(doc(db, "users", currentUser.uid));
      if(!snap.exists()) return { status:"warn", detail:"ไม่พบเอกสาร user ของบัญชีนี้", fix:"ล็อกอินใหม่หรือให้ระบบสร้าง users/{uid} อัตโนมัติ" };
      const d = snap.data();
      if(!d.email || !d.username) return { status:"warn", detail:"ข้อมูล user ยังไม่ครบ email/username", fix:"เข้าเมนูตั้งค่าแล้วบันทึกชื่อผู้ใช้อีกครั้ง" };
      return { status:"ok", detail:`พบ user profile: ${d.username || d.email}` };
    }, results);

    await guardianSafeCheck("Firestore: usernames index", async () => {
      const name = normalizeUsernameKey($("userName")?.innerText || currentUser.displayName || "");
      if(!name) return { status:"warn", detail:"ยังไม่พบชื่อผู้ใช้สำหรับสร้าง index", fix:"ตั้งชื่อผู้ใช้ก่อน" };
      const snap = await getDoc(doc(db, "usernames", name));
      if(!snap.exists()) return { status:"warn", detail:`ยังไม่มี usernames/${name}`, fix:"ล็อกอินด้วยอีเมล 1 ครั้ง หรือเปลี่ยนชื่อผู้ใช้เพื่อให้ระบบสร้าง index" };
      return { status:"ok", detail:`username login พร้อมใช้: ${name}` };
    }, results);

    await guardianSafeCheck("Firestore: watchItems อ่านรายการของฉัน", async () => {
      const snap = await getDocs(query(collection(db,"watchItems"), where("ownerId", "==", currentUser.uid), limit(5)));
      return { status:"ok", detail:`อ่านรายการของฉันได้ (${snap.size} รายการตัวอย่าง)` };
    }, results);

    await guardianSafeCheck("Firestore: Activity Log เขียนได้", async () => {
      await addDoc(collection(db,"activityLogs"), {
        action:"guardian_check",
        uid: currentUser.uid,
        email: currentUser.email || "",
        username: getCurrentUsername(),
        detail:{ source:"WJB Guardian AI", note:"health check" },
        createdAt: serverTimestamp(),
        createdMs: Date.now()
      });
      return { status:"ok", detail:"บันทึก health check ลง Activity Log ได้" };
    }, results);

    await guardianSafeCheck("สิทธิ์ Admin Panel", async () => {
      if(!isAdmin) return { status:"ok", detail:"บัญชีนี้เป็น user ธรรมดา จึงไม่ควรเห็น Admin Panel" };
      const usersSnap = await getDocs(query(collection(db,"users"), limit(3)));
      return { status:"ok", detail:`บัญชีแอดมินอ่าน users ได้ (${usersSnap.size} รายการตัวอย่าง)` };
    }, results);
  }

  await guardianSafeCheck("API TMDB", async () => {
    const key = getWJBTmdbFreeKey();
    if(!key) return { status:"ok", detail:"TMDB ถูกปิดตามโหมดฟรี 100% ใช้ Jikan/AniList/Kitsu/TVMaze/iTunes/Wiki/WJB Memory แทน", fix:"ไม่ต้องแก้ ระบบตั้งใจปิดเพื่อกันค่าใช้จ่าย" };
    const res = await fetch(`https://api.themoviedb.org/3/search/multi?api_key=${encodeURIComponent(key)}&query=one%20piece&language=th-TH&page=1`, { cache:"no-store" });
    if(!res.ok) return { status:"warn", detail:`TMDB ตอบกลับ ${res.status}`, fix:"ตรวจ API key / quota / internet" };
    const data = await res.json();
    return { status:"ok", detail:`TMDB ใช้งานได้ (${(data.results||[]).length} ผลลัพธ์)` };
  }, results);

  await guardianSafeCheck("API Jikan / Anime", async () => {
    const res = await fetch("https://api.jikan.moe/v4/anime?q=slime&limit=1", { cache:"no-store" });
    if(!res.ok) return { status:"warn", detail:`Jikan ตอบกลับ ${res.status}`, fix:"อาจติด rate limit ให้ลองใหม่ภายหลัง" };
    return { status:"ok", detail:"Jikan ใช้งานได้" };
  }, results);

  await guardianSafeCheck("ข้อมูลในลิสต์ / ความสมบูรณ์", async () => {
    const arr = Array.isArray(items) ? items : [];
    if(!currentUser) return { status:"warn", detail:"ยังไม่ล็อกอิน จึงวิเคราะห์ลิสต์ไม่ได้" };
    if(!arr.length) return { status:"warn", detail:"ยังไม่มีรายการในลิสต์", fix:"ลองเพิ่มรายการ 1 เรื่องเพื่อทดสอบระบบ" };
    const noPoster = arr.filter(i => !i.poster).length;
    const noScore = arr.filter(i => !i.score).length;
    const badOwner = arr.filter(i => i.ownerId !== currentUser.uid).length;
    if(badOwner) return { status:"error", detail:`มีรายการ ownerId ไม่ตรง ${badOwner} รายการ`, fix:"ตรวจ Rules และข้อมูล watchItems" };
    if(noPoster || noScore) return { status:"warn", detail:`พบข้อมูลยังไม่ครบ: ไม่มีรูป ${noPoster}, ไม่มีคะแนน ${noScore}`, fix:"ใช้หน้า Smart Library/แก้ไขหลายรายการเพื่อเติมข้อมูล" };
    return { status:"ok", detail:`ลิสต์สมบูรณ์ดี (${arr.length} รายการ)` };
  }, results);

  await guardianSafeCheck("ประสิทธิภาพหน้าเว็บ", async () => {
    const count = Array.isArray(items) ? items.length : 0;
    if(count > 500) return { status:"warn", detail:`รายการเยอะมาก ${count} รายการ`, fix:"ใช้มุมมองย่อ/ตัวกรอง/ค้นหา เพื่อลดการ render หนัก" };
    return { status:"ok", detail:`จำนวนรายการเหมาะสม (${count} รายการ)` };
  }, results);

  return results.sort((a,b)=>guardianSeverityScore(b.status)-guardianSeverityScore(a.status));
}

window.closeGuardianAI = function(){
  if($("guardianModal")) $("guardianModal").style.display = "none";
};
window.runGuardianCheck = async function(showAlert = true){
  const content = $("guardianContent");
  const summary = $("guardianSummary");
  if(summary) summary.innerHTML = "🔍 กำลังตรวจระบบ...";
  if(content) content.innerHTML = `<div class="guardian-loading">กำลังตรวจปุ่ม ระบบล็อกอิน ฐานข้อมูล และ API ออนไลน์...</div>`;
  const started = performance.now();
  const results = await runGuardianCoreChecks();
  const elapsed = Math.round(performance.now() - started);
  guardianLastResults = results;
  saveGuardianHistory(results);
  renderGuardianResults(results, elapsed);
  if(showAlert){
    const errors = results.filter(r=>r.status==="error").length;
    const warns = results.filter(r=>r.status==="warn").length;
    if(errors) wjbToast(`ตรวจเสร็จ: พบปัญหา ${errors} จุด และจุดควรตรวจ ${warns} จุด`);
    else if(warns) wjbToast(`ตรวจเสร็จ: ระบบใช้ได้ แต่มีจุดควรตรวจ ${warns} จุด`);
    else wjbToast("ตรวจเสร็จ: ระบบปกติดีครับ");
  }
};
function renderGuardianResults(results, elapsed = 0){
  const content = $("guardianContent");
  const summary = $("guardianSummary");
  const ok = results.filter(r=>r.status==="ok").length;
  const warn = results.filter(r=>r.status==="warn").length;
  const error = results.filter(r=>r.status==="error").length;
  if(summary){
    const status = error ? "error" : warn ? "warn" : "ok";
    summary.className = `guardian-summary ${status}`;
    summary.innerHTML = `<b>${guardianStatusIcon(status)} สรุปสุขภาพเว็บ</b><span>ปกติ ${ok} · ควรตรวจ ${warn} · พบปัญหา ${error} · ใช้เวลา ${elapsed}ms</span>`;
  }
  if(content){
    content.innerHTML = results.map(r => `
      <div class="guardian-row ${r.status}">
        <div class="guardian-row-head"><b>${guardianStatusIcon(r.status)} ${escapeText(r.title)}</b><span>${guardianStatusLabel(r.status)}</span></div>
        <p>${escapeText(r.detail || "")}</p>
        ${r.fix ? `<div class="guardian-fix">วิธีแก้: ${escapeText(r.fix)}</div>` : ""}
      </div>`).join("") + guardianHistoryHTML();
  }
}
function guardianHistoryHTML(){
  const history = getGuardianHistory().slice(0,5);
  if(!history.length) return "";
  return `<div class="guardian-history"><h3>ประวัติการตรวจล่าสุด</h3>${history.map(h=>{
    const e = h.results.filter(r=>r.status==="error").length;
    const w = h.results.filter(r=>r.status==="warn").length;
    const o = h.results.filter(r=>r.status==="ok").length;
    return `<div class="guardian-history-item">${new Date(h.createdMs).toLocaleString("th-TH")} · ✅ ${o} · ⚠️ ${w} · ❌ ${e}</div>`;
  }).join("")}</div>`;
}
function renderGuardianHistory(){
  const content = $("guardianContent");
  if(content && !guardianLastResults.length){
    content.innerHTML = guardianHistoryHTML() || `<div class="guardian-loading">ยังไม่มีประวัติการตรวจ</div>`;
  }
}
window.clearGuardianHistory = function(){
  wjbStorageRemove(WJB_GUARDIAN_KEY);
  guardianLastResults = [];
  renderGuardianHistory();
  if($("guardianSummary")) $("guardianSummary").innerHTML = "ล้างประวัติแล้ว กดตรวจตอนนี้เพื่อเริ่มใหม่";
};
window.toggleGuardianAutoCheck = function(){
  const btn = $("guardianAutoBtn");
  if(guardianAutoTimer){
    clearInterval(guardianAutoTimer);
    guardianAutoTimer = null;
    if(btn) btn.innerText = "⏱️ Auto Check: ปิด";
    wjbToast("ปิด Auto Check แล้ว");
    return;
  }
  guardianAutoTimer = setInterval(() => {
    if(currentUser) runGuardianCheck(false);
  }, 5 * 60 * 1000);
  if(btn) btn.innerText = "⏱️ Auto Check: เปิด";
  wjbToast("เปิด Auto Check แล้ว ระบบจะตรวจทุก 5 นาทีขณะเปิดหน้าเว็บ");
};

// ตรวจเบื้องต้นเงียบ ๆ หลัง login เพื่อจับปัญหาเร็วขึ้น แต่ไม่รบกวนผู้ใช้
setTimeout(() => {
  if(currentUser && !guardianLastResults.length){
    runGuardianCoreChecks().then(results => {
      guardianLastResults = results;
      saveGuardianHistory(results);
      const serious = results.some(r => r.status === "error");
      if(serious) console.warn("WJB Guardian พบปัญหา", results);
    }).catch(()=>{});
  }
}, 12000);

// ===== WJB Guardian AI v2: Health Dashboard + Safe Auto Fix =====
const WJB_GUARDIAN_V2 = "Guardian AI v2";
let guardianV2LastElapsed = 0;

function guardianCountByStatus(results){
  return {
    ok: results.filter(r => r.status === "ok").length,
    warn: results.filter(r => r.status === "warn").length,
    error: results.filter(r => r.status === "error").length
  };
}

function guardianOverallStatus(results){
  const c = guardianCountByStatus(results || []);
  if(c.error) return "error";
  if(c.warn) return "warn";
  return "ok";
}

function guardianQualityScore(results){
  if(!results || !results.length) return 0;
  const c = guardianCountByStatus(results);
  const score = Math.round(((c.ok + (c.warn * 0.45)) / results.length) * 100);
  return Math.max(0, Math.min(100, score));
}

function guardianItemIssues(){
  const arr = Array.isArray(items) ? items : [];
  const duplicateMap = new Map();
  const privacyMap = new Map();
  arr.forEach(i => {
    const key = `${String(i.title || "").trim().toLowerCase()}|${String(i.season || "").trim().toLowerCase()}|${i.type || ""}`;
    if(!key.startsWith("|")) duplicateMap.set(key, (duplicateMap.get(key) || 0) + 1);
    const titleKey = String(i.title || "").trim().toLowerCase();
    if(titleKey){
      if(!privacyMap.has(titleKey)) privacyMap.set(titleKey, new Set());
      privacyMap.get(titleKey).add(i.isPublic !== false ? "public" : "private");
    }
  });
  const statusMismatch = arr.filter(i => i.status && typeof getSmartStatus === "function" && getSmartStatus(i) !== i.status).length;
  const badProgress = arr.filter(i => {
    const ep = Number(i.episode || 0);
    const total = Number(i.total || 0);
    return total > 0 && ep > total;
  }).length;
  const doneButProgressNotFull = arr.filter(i => {
    if(i.status !== "ดูจบแล้ว" || i.type === "หนัง") return false;
    const ep = Number(i.episode || 0);
    const total = Number(i.total || 0);
    return total > 0 && ep < total;
  }).length;
  return {
    total: arr.length,
    noTitle: arr.filter(i => !String(i.title || "").trim()).length,
    noPoster: arr.filter(i => !i.poster).length,
    noScore: arr.filter(i => !i.score).length,
    badScore: arr.filter(i => i.score && (Number(i.score) < 0 || Number(i.score) > 10)).length,
    badOwner: currentUser ? arr.filter(i => i.ownerId !== currentUser.uid).length : 0,
    noCreatedMs: arr.filter(i => !i.createdMs).length,
    duplicateGroups: Array.from(duplicateMap.values()).filter(n => n > 1).length,
    statusMismatch,
    badProgress,
    doneButProgressNotFull,
    privacyMixedGroups: Array.from(privacyMap.values()).filter(set => set.size > 1).length
  };
}

async function runGuardianCoreChecksV2(){
  const results = await runGuardianCoreChecks();

  await guardianSafeCheck("Guardian AI v2 / Auto Fix", async () => {
    if(!$('guardianDashboard')) return { status:"warn", detail:"ยังไม่พบ Health Dashboard v2", fix:"ตรวจว่าอัปโหลดไฟล์ index.html ล่าสุดแล้วหรือยัง" };
    return { status:"ok", detail:"Health Dashboard และ Auto Fix พร้อมใช้งาน" };
  }, results);

  await guardianSafeCheck("ตรวจข้อมูลซ้ำ / ข้อมูลที่ควรเก็บกวาด", async () => {
    if(!currentUser) return { status:"warn", detail:"ยังไม่ล็อกอิน จึงตรวจข้อมูลซ้ำไม่ได้", fix:"ล็อกอินแล้วกดตรวจอีกครั้ง" };
    const issues = guardianItemIssues();
    if(!issues.total) return { status:"warn", detail:"ยังไม่มีรายการให้วิเคราะห์", fix:"เพิ่มรายการก่อนอย่างน้อย 1 เรื่อง" };
    const notes = [];
    if(issues.duplicateGroups) notes.push(`กลุ่มชื่อ/ซีซั่นซ้ำ ${issues.duplicateGroups}`);
    if(issues.badScore) notes.push(`คะแนนผิดช่วง ${issues.badScore}`);
    if(issues.noCreatedMs) notes.push(`ไม่มี createdMs ${issues.noCreatedMs}`);
    if(issues.noTitle) notes.push(`ไม่มีชื่อ ${issues.noTitle}`);
    if(issues.statusMismatch) notes.push(`status/smartStatus ควรตรวจ ${issues.statusMismatch}`);
    if(issues.badProgress) notes.push(`ตอนดูเกินจำนวนตอน ${issues.badProgress}`);
    if(issues.doneButProgressNotFull) notes.push(`ดูจบแล้วแต่ตอนยังไม่เต็ม ${issues.doneButProgressNotFull}`);
    if(issues.privacyMixedGroups) notes.push(`ซีซั่น public/private ปนกัน ${issues.privacyMixedGroups} เรื่อง`);
    if(notes.length) return { status:"warn", detail:notes.join(" · "), fix:"ใช้ Auto Fix/Data Doctor เพื่อซ่อม field พื้นฐาน ซิงก์สถานะ และตรวจรายการซ้ำก่อนลบ/รวมเอง" };
    return { status:"ok", detail:"ไม่พบข้อมูลซ้ำหรือ field สำคัญผิดปกติ" };
  }, results);

  await guardianSafeCheck("ตรวจความพร้อมสำหรับผู้ใช้จำนวนมาก", async () => {
    const count = Array.isArray(items) ? items.length : 0;
    const compactReady = typeof window.toggleMyCompactMode === "function" || document.body.classList.contains('my-compact-mode') || true;
    if(count > 300) return { status:"warn", detail:`มีรายการ ${count} เรื่อง ควรใช้มุมมองย่อ/ค้นหา/ตัวกรอง`, fix:"เปิด 📋 มุมมองย่อ และใช้ค้นหา/กรองเพื่อลดการเลื่อน" };
    return { status:"ok", detail:`พร้อมใช้งานกับลิสต์ปัจจุบัน (${count} รายการ)` };
  }, results);

  return results.sort((a,b)=>guardianSeverityScore(b.status)-guardianSeverityScore(a.status));
}

function renderGuardianDashboardV2(results, elapsed = 0){
  const dash = $('guardianDashboard');
  if(!dash) return;
  const c = guardianCountByStatus(results || []);
  const overall = guardianOverallStatus(results || []);
  const quality = guardianQualityScore(results || []);
  const itemIssues = guardianItemIssues();
  const apiProblems = (results || []).filter(r => /API|TMDB|Jikan/i.test(r.title || "") && r.status !== "ok").length;
  const dataProblems = (results || []).filter(r => /ข้อมูล|Firestore|usernames|watchItems|Activity/i.test(r.title || "") && r.status !== "ok").length;
  dash.innerHTML = `
    <div class="guardian-health-card ${overall}">
      <small>คะแนนสุขภาพ</small>
      <b>${quality}%</b>
      <span>${guardianStatusIcon(overall)} ${guardianStatusLabel(overall)}</span>
    </div>
    <div class="guardian-health-card">
      <small>ผลตรวจ</small>
      <b>${c.ok}/${(results || []).length}</b>
      <span>✅ ${c.ok} · ⚠️ ${c.warn} · ❌ ${c.error}</span>
    </div>
    <div class="guardian-health-card">
      <small>ข้อมูลในลิสต์</small>
      <b>${itemIssues.total}</b>
      <span>ไม่มีรูป ${itemIssues.noPoster} · ไม่มีคะแนน ${itemIssues.noScore} · สถานะควรตรวจ ${itemIssues.statusMismatch || 0}</span>
    </div>
    <div class="guardian-health-card">
      <small>จุดเสี่ยง</small>
      <b>${apiProblems + dataProblems}</b>
      <span>API ${apiProblems} · Data ${dataProblems} · ${elapsed}ms</span>
    </div>
  `;
}

window.runGuardianCheckV2 = async function(showAlert = true){
  const content = $('guardianContent');
  const summary = $('guardianSummary');
  const dash = $('guardianDashboard');
  if(summary) summary.innerHTML = "🔍 กำลังตรวจระบบแบบละเอียด...";
  if(dash) dash.innerHTML = `<div class="guardian-loading">กำลังสร้าง Health Dashboard...</div>`;
  if(content) content.innerHTML = `<div class="guardian-loading">กำลังตรวจ Auth, Firestore, Rules, API, ข้อมูลซ้ำ, Performance และจุดที่ Auto Fix ได้...</div>`;

  const started = performance.now();
  const results = await runGuardianCoreChecksV2();
  const elapsed = Math.round(performance.now() - started);
  guardianV2LastElapsed = elapsed;
  guardianLastResults = results;
  saveGuardianHistory(results);
  renderGuardianResults(results, elapsed);
  renderGuardianDashboardV2(results, elapsed);

  if(showAlert){
    const c = guardianCountByStatus(results);
    if(c.error) wjbToast(`ตรวจเสร็จ: พบปัญหา ${c.error} จุด และจุดควรตรวจ ${c.warn} จุด`);
    else if(c.warn) wjbToast(`ตรวจเสร็จ: ระบบใช้ได้ แต่มีจุดควรตรวจ ${c.warn} จุด`);
    else wjbToast("ตรวจเสร็จ: ระบบปกติดีครับ");
  }
};

window.openGuardianAI = async function(){
  const modal = $('guardianModal');
  if(modal) modal.style.display = "flex";
  renderGuardianHistory();
  if(!guardianLastResults.length) await window.runGuardianCheckV2(false);
  else renderGuardianDashboardV2(guardianLastResults, guardianV2LastElapsed);
};

function guardianAppendFixReport(lines){
  const content = $('guardianContent');
  if(!content) return;
  const html = `
    <div class="guardian-row ok guardian-fix-report">
      <div class="guardian-row-head"><b>🔧 Auto Fix Report</b><span>ซ่อมเสร็จ</span></div>
      ${lines.map(x => `<p>${escapeText(x)}</p>`).join("")}
    </div>`;
  content.insertAdjacentHTML('afterbegin', html);
}

async function guardianFixCurrentUserProfile(lines){
  if(!currentUser) return;
  const profileName = $('userName')?.innerText || currentUser.displayName || (currentUser.email ? currentUser.email.split('@')[0] : 'WJB User');
  await setDoc(doc(db, 'users', currentUser.uid), {
    uid: currentUser.uid,
    username: profileName,
    displayName: profileName,
    email: currentUser.email || '',
    role: isAdmin ? 'admin' : 'user',
    updatedAt: serverTimestamp()
  }, { merge:true });
  await ensureUsernameIndex(currentUser.uid, profileName, currentUser.email || '');
  lines.push(`ซ่อม/ยืนยัน users/${currentUser.uid} และ usernames/${normalizeUsernameKey(profileName)} แล้ว`);
}

async function guardianFixMyItems(lines){
  if(!currentUser || !Array.isArray(items) || !items.length) return;
  let fixed = 0;
  const allowedStatus = new Set(['กำลังดู','ดูจบแล้ว','ดองไว้','อยากดู']);
  const allowedType = new Set(['อนิเมะ','หนัง','ซีรีส์','อื่นๆ']);
  for(const item of items){
    const patch = {};
    if(!item.ownerId) patch.ownerId = currentUser.uid;
    if(!item.ownerName) patch.ownerName = currentUser.displayName || currentUser.email || getCurrentUsername();
    if(!item.ownerEmail) patch.ownerEmail = currentUser.email || '';
    if(item.isPublic === undefined) patch.isPublic = true;
    if(item.favorite === undefined) patch.favorite = false;
    if(!item.createdMs) patch.createdMs = Date.now();
    if(!item.date) patch.date = new Date().toLocaleDateString('th-TH');
    if(!allowedStatus.has(item.status)) patch.status = 'อยากดู';
    if(!allowedType.has(item.type)) patch.type = 'อื่นๆ';
    if(item.type !== 'หนัง' && !item.season) patch.season = 'ซีซั่น 1';
    if(!item.episodeMode && item.type !== 'หนัง') patch.episodeMode = item.total ? 'manual' : 'ongoing';
    if(item.score && Number(item.score) > 10) patch.score = '10';
    if(item.score && Number(item.score) < 0) patch.score = '0';

    const ep = Number(item.episode || 0);
    const total = Number(item.total || 0);
    if(total > 0 && ep > total) patch.episode = String(total);
    if(item.status === 'ดูจบแล้ว' && item.type !== 'หนัง' && total > 0 && ep < total) patch.episode = String(total);
    if(item.status !== 'ดูจบแล้ว' && typeof isSeasonCompleted === 'function' && isSeasonCompleted(item)) patch.status = 'ดูจบแล้ว';

    if(Object.keys(patch).length){
      patch.updatedAt = serverTimestamp();
      await setDoc(doc(db, 'watchItems', item.id), patch, { merge:true });
      fixed++;
    }
  }
  lines.push(fixed ? `Data Doctor ซ่อม field/สถานะ/episode พื้นฐานของรายการ ${fixed} รายการแล้ว` : 'Data Doctor ตรวจรายการแล้ว ไม่พบ field พื้นฐานที่ต้องซ่อม');
}

async function guardianFixAdminIndexes(lines){
  if(!isAdmin) return;
  const snap = await getDocs(query(collection(db, 'users'), limit(200)));
  let usersFixed = 0;
  for(const d of snap.docs){
    const u = d.data() || {};
    const rolePatch = {};
    if(!u.role) rolePatch.role = 'user';
    if(!u.uid) rolePatch.uid = d.id;
    if(Object.keys(rolePatch).length){
      await setDoc(doc(db, 'users', d.id), { ...rolePatch, updatedAt: serverTimestamp() }, { merge:true });
      usersFixed++;
    }
    const name = u.username || u.displayName || (u.email ? String(u.email).split('@')[0] : '');
    if(name && u.email){
      const key = normalizeUsernameKey(name);
      await setDoc(doc(db, 'usernames', key), {
        uid: u.uid || d.id,
        username: name,
        email: String(u.email).toLowerCase(),
        updatedAt: serverTimestamp()
      }, { merge:true });
    }
  }
  lines.push(`แอดมินซ่อม users role/uid และ username index ตัวอย่าง ${snap.size} ผู้ใช้แล้ว (${usersFixed} รายการมี patch)`);
}

window.runGuardianAutoFix = async function(){
  if(!currentUser){
    wjbToast('ต้องล็อกอินก่อนใช้ Auto Fix');
    return;
  }
  const ok = await wjbConfirm('Auto Fix / Data Doctor จะซ่อมเฉพาะข้อมูลที่ปลอดภัย เช่น users profile, username index, role=user ที่หาย, field รายการที่หาย, คะแนนเกินช่วง 0-10, ตอนดูเกินจำนวนตอน และซิงก์สถานะที่ชัดเจน\n\nระบบจะไม่ลบข้อมูล ไม่รวมรายการซ้ำ และไม่เปลี่ยน public/private ให้อัตโนมัติ ต้องการดำเนินการไหม?', {okText:"เริ่มซ่อม"});
  if(!ok) return;

  const lines = [];
  try{
    await guardianFixCurrentUserProfile(lines);
    await guardianFixMyItems(lines);
    await guardianFixAdminIndexes(lines);
    await logActivity('guardian_auto_fix', { fixes: lines });
    await loadMyItems();
    guardianAppendFixReport(lines);
    await window.runGuardianCheckV2(false);
    wjbToast('Auto Fix เสร็จแล้วครับ ตรวจซ้ำเรียบร้อย');
  }catch(e){
    wjbToast('Auto Fix ไม่สำเร็จ: ' + (e.message || e));
  }
};

// โหลดค่าระบบตั้งแต่เปิดเว็บ เพื่อใช้ปิดสมัคร/แสดงประกาศได้ก่อนล็อกอิน
loadSystemSettings().catch(() => applySystemSettings());


// ===== WJB Brain: offline/local assistant (No OpenAI, No Netlify AI Function) =====
let brotherAIHistory = [];

function getBrotherAIStats(){
  const groupCount = typeof groupItemsByTitle === "function" ? groupItemsByTitle(items || []).length : (items || []).length;
  return {
    totalGroups: groupCount,
    totalSeasonsOrItems: (items || []).length,
    watching: (items || []).filter(i => typeof getSmartStatus === "function" && getSmartStatus(i) === "กำลังดู").length,
    done: (items || []).filter(i => typeof isSeasonCompleted === "function" && isSeasonCompleted(i)).length,
    wishlist: (items || []).filter(i => i.status === "อยากดู").length,
    pending: (items || []).filter(i => i.status === "ดองไว้").length,
    missingPoster: (items || []).filter(i => !i.poster).length,
    missingScore: (items || []).filter(i => !i.score).length,
    publicItems: (items || []).filter(i => i.isPublic !== false).length
  };
}

function getBrotherAIDataDoctorSummary(){
  const arr = Array.isArray(items) ? items : [];
  const statusMismatch = arr.filter(i => i.status && typeof getSmartStatus === "function" && getSmartStatus(i) !== i.status).length;
  const scoreMissing = arr.filter(i => !i.score).length;
  const badProgress = arr.filter(i => {
    const ep = Number(i.episode || 0);
    const total = Number(i.total || 0);
    return total > 0 && ep > total;
  }).length;
  const privacyMixedTitles = new Set();
  const map = new Map();
  arr.forEach(i => {
    const key = String(i.title || "").trim().toLowerCase();
    if(!key) return;
    if(!map.has(key)) map.set(key, new Set());
    map.get(key).add(i.isPublic !== false ? "public" : "private");
  });
  map.forEach((set, key) => { if(set.size > 1) privacyMixedTitles.add(key); });
  return {
    statusMismatch,
    scoreMissing,
    badProgress,
    privacyMixedGroups: privacyMixedTitles.size,
    note: "smartStatus เป็นสถานะที่คำนวณจาก progress เพื่อช่วยแสดงผล ไม่ใช่ field หลักในฐานข้อมูล; ถ้าต่างจาก status ให้ถือเป็นจุดควรตรวจ ไม่ใช่ admin โหลดเสีย"
  };
}

function getBrotherAIContext(){
  const sampleItems = (items || []).slice(0, 60).map(i => {
    const computedSmartStatus = typeof getSmartStatus === "function" ? getSmartStatus(i) : (i.status || "");
    return {
      title: i.title || "",
      type: i.type || "",
      season: typeof getSeasonDisplayName === "function" ? getSeasonDisplayName(i) : (i.season || ""),
      status: i.status || "",
      smartStatus: computedSmartStatus,
      statusNeedsReview: !!(i.status && computedSmartStatus && i.status !== computedSmartStatus),
      score: i.score || "",
      episode: i.episode || "",
      total: i.total || "",
      releaseInfo: i.releaseInfo || "",
      isPublic: i.isPublic !== false,
      hasPoster: !!i.poster,
      note: String(i.note || "").slice(0, 180)
    };
  });

  return {
    app: "Watch Jettaphon / WJB",
    role: isAdmin ? "admin" : "user",
    user: currentUser ? {
      uid: currentUser.uid,
      email: currentUser.email || "",
      displayName: getCurrentUsername()
    } : null,
    stats: getBrotherAIStats(),
    dataDoctorSummary: getBrotherAIDataDoctorSummary(),
    currentTab,
    systemSettings: typeof systemSettings !== "undefined" ? systemSettings : {},
    adminSummary: isAdmin ? {
      usersLoaded: (adminUsers || []).length,
      adminItemsLoaded: (adminItems || []).length,
      adminLogsLoaded: (adminLogs || []).length,
      recentLogs: (adminLogs || []).slice(0, 20).map(l => ({
        action: l.action,
        itemTitle: l.itemTitle || "",
        username: l.username || "",
        createdMs: l.createdMs || 0
      }))
    } : null,
    contextNotes: [
      "Admin Summary จะถูกโหลดก่อนส่งให้ AI ถ้าเป็นแอดมิน",
      "smartStatus เป็นค่าคำนวณจากตอน/จำนวนตอน อาจต่างจาก status เพื่อบอกจุดควรตรวจ",
      "ให้แยกปัญหา admin โหลดจริงออกจากปัญหา AI context ไม่ครบ"
    ],
    sampleItems
  };
}

// ===== WJB Free-Only Cost Guard =====
function wjbCostGuardSummary(){
  return {
    openAI: "disabled",
    netlifyFunctionsAI: "disabled",
    paidApis: "disabled",
    tmdbApiKey: "disabled-free-lock",
    freeSources: WJB_FREE_SEARCH_SOURCES
  };
}

// ===== WJB No-OpenAI Local Brain Override =====
// โหมดนี้ตัด OpenAI API ออกทั้งหมด: ไม่เรียก Netlify Function, ไม่ใช้ OPENAI_API_KEY, ไม่รับ API key จากผู้ใช้, ไม่เสียเครดิต
function wjbLocalBrainBuildReport(message = ""){
  const ctx = typeof getBrotherAIContext === "function" ? getBrotherAIContext() : {};
  const stats = ctx.stats || {};
  const doctor = ctx.dataDoctorSummary || {};
  const settings = ctx.systemSettings || {};
  const arr = Array.isArray(items) ? items : [];
  const adminSummary = ctx.adminSummary || null;
  const msg = String(message || "").toLowerCase();

  const missingPoster = arr.filter(i => !i.poster).slice(0, 10).map(i => i.title || "ไม่ทราบชื่อ");
  const missingScore = arr.filter(i => !i.score).slice(0, 10).map(i => `${i.title || "ไม่ทราบชื่อ"}${i.season ? " / " + i.season : ""}`);
  const badProgress = arr.filter(i => {
    const ep = Number(i.episode || 0);
    const total = Number(i.total || 0);
    return total > 0 && ep > total;
  }).slice(0, 10).map(i => `${i.title || "ไม่ทราบชื่อ"}: ${i.episode}/${i.total}`);

  const statusMismatch = arr.filter(i => {
    if(!i.status || typeof getSmartStatus !== "function") return false;
    return getSmartStatus(i) !== i.status;
  }).slice(0, 10).map(i => `${i.title || "ไม่ทราบชื่อ"}: status=${i.status}, smart=${getSmartStatus(i)}`);

  const healthIssues = [];
  if((stats.missingPoster || 0) > 0) healthIssues.push(`มีรายการไม่มีรูป ${stats.missingPoster} รายการ`);
  if((stats.missingScore || 0) > 0) healthIssues.push(`มีรายการยังไม่ใส่คะแนน ${stats.missingScore} รายการ`);
  if((doctor.statusMismatch || 0) > 0) healthIssues.push(`มี status/smartStatus ไม่ตรงกัน ${doctor.statusMismatch} รายการ`);
  if((doctor.badProgress || 0) > 0) healthIssues.push(`มีตอนดูเกินจำนวนตอนทั้งหมด ${doctor.badProgress} รายการ`);
  if((doctor.privacyMixedGroups || 0) > 0) healthIssues.push(`มีเรื่องเดียวกันแต่ public/private ปนกัน ${doctor.privacyMixedGroups} กลุ่ม`);

  if(msg.includes("พัฒนา") || msg.includes("ต่อ") || msg.includes("roadmap")){
    return `🧠 WJB Brain ฟรี 100% — แผนพัฒนาต่อแบบไม่เสียเครดิต\n\nแนะนำลำดับถัดไป:\n1. ✅ Data Doctor v3: เพิ่มปุ่มซ่อม score/status/episode แบบเลือกยืนยันแล้ว\n2. ✅ Duplicate Finder: เพิ่มตัวหาเรื่องซ้ำ พร้อมรวม/ลบแบบยืนยันแล้ว\n3. ✅ Smart Filter: เพิ่มซ่อนเรื่องที่เพิ่มแล้ว/ไม่มีคะแนน/ไม่มีรูปแล้ว\n4. ✅ Offline/Local Brain: เพิ่มคำตอบสำเร็จรูปและกฎวิเคราะห์มากขึ้นแล้ว\n5. ✅ Cost Guard: ตัดการเรียก OpenAI/Netlify Function AI ออกแล้ว\n\nสถานะตอนนี้:\n- รายการทั้งหมด: ${stats.totalSeasonsOrItems ?? arr.length}\n- กลุ่มเรื่อง: ${stats.totalGroups ?? "ไม่ทราบ"}\n- จุดควรตรวจ: ${healthIssues.length ? healthIssues.join(" / ") : "ยังไม่พบจุดเสี่ยงใหญ่"}`;
  }

  if(msg.includes("ลิสต์") || msg.includes("ข้อมูล") || msg.includes("doctor") || msg.includes("คะแนน")){
    return `📚 วิเคราะห์ลิสต์แบบไม่ใช้ OpenAI\n\nสรุปข้อมูล:\n- รายการทั้งหมด: ${stats.totalSeasonsOrItems ?? arr.length}\n- กลุ่มเรื่อง: ${stats.totalGroups ?? "ไม่ทราบ"}\n- กำลังดู: ${stats.watching ?? 0}\n- ดูจบ: ${stats.done ?? 0}\n- อยากดู: ${stats.wishlist ?? 0}\n- ดองไว้: ${stats.pending ?? 0}\n\nจุดควรเติม:\n- ไม่มีรูป: ${stats.missingPoster ?? 0}${missingPoster.length ? "\n  ตัวอย่าง: " + missingPoster.join(", ") : ""}\n- ยังไม่ใส่คะแนน: ${stats.missingScore ?? 0}${missingScore.length ? "\n  ตัวอย่าง: " + missingScore.join(", ") : ""}\n- ตอนดูเกินจำนวนตอน: ${doctor.badProgress ?? 0}${badProgress.length ? "\n  ตัวอย่าง: " + badProgress.join(", ") : ""}\n\nคำแนะนำ:\n1. เปิด Guardian AI → ตรวจตอนนี้\n2. ใช้ Data Doctor ซ่อมเฉพาะรายการที่ปลอดภัย\n3. รายการที่คะแนนว่าง ให้พี่ชายตัดสินใจเอง ไม่ควร auto-fill คะแนนแทนผู้ใช้`;
  }

  if(msg.includes("admin") || msg.includes("แอดมิน")){
    return `👑 ตรวจส่วนแอดมินแบบ Local Brain\n\nสถานะแอดมินจากบริบทปัจจุบัน:\n${adminSummary ? `- usersLoaded: ${adminSummary.usersLoaded}\n- adminItemsLoaded: ${adminSummary.adminItemsLoaded}\n- adminLogsLoaded: ${adminSummary.adminLogsLoaded}` : "- บัญชีนี้ไม่ได้อยู่ในโหมดแอดมิน หรือยังไม่ได้เปิด Admin Panel"}\n\nจากภาพที่พี่ชายเคยเช็ก: Admin Panel โหลดข้อมูลได้แล้ว จึงถือว่าระบบแอดมินหลักปกติ\n\nสิ่งที่ควรเช็กต่อ:\n1. User ธรรมดาไม่เห็นปุ่มแอดมิน\n2. Activity Log มีรายการใหม่หลังเพิ่ม/แก้/ลบ\n3. Rules ยังมี role admin และ systemSettings ถูกต้อง`;
  }

  return `🧠 WJB Brain ฟรี 100% ตรวจเว็บให้แล้วครับ\n\nสถานะรวม:\n- รายการทั้งหมด: ${stats.totalSeasonsOrItems ?? arr.length}\n- กลุ่มเรื่อง: ${stats.totalGroups ?? "ไม่ทราบ"}\n- สาธารณะ: ${stats.publicItems ?? 0}\n- ไม่มีรูป: ${stats.missingPoster ?? 0}\n- ยังไม่ใส่คะแนน: ${stats.missingScore ?? 0}\n\nจุดที่ควรดู:\n${healthIssues.length ? healthIssues.map((x,i)=>`${i+1}. ${x}`).join("\n") : "✅ ยังไม่พบจุดเสี่ยงใหญ่จากข้อมูลที่โหลดอยู่"}\n\nข้อแนะนำ:\n1. ใช้ Guardian AI ตรวจข้อมูลเป็นระยะ\n2. ใช้ Data Doctor ซ่อมเฉพาะข้อมูลที่ปลอดภัย\n3. ตรวจว่าไม่มี OpenAI API/Netlify AI Function ค้างอยู่ในโปรเจกต์\n4. เก็บ WJB Brain ฟรี 100%ไว้ตอบคำถามพื้นฐานแทน OpenAI\n\nหมายเหตุ: คำตอบนี้มาจากกฎวิเคราะห์ในเว็บ WJB เอง ไม่ได้เรียก OpenAI ไม่เรียก Netlify Function AI และไม่ใช้ API เสียเงินครับ`;
}

window.renderBrotherAIChat = function(){
  const box = $("brotherAIChat");
  if(!box) return;
  if(!brotherAIHistory.length){
    box.innerHTML = `<div class="brother-ai-msg system">สวัสดีครับพี่ชาย ผมคือ WJB Brain ฟรี 100% อยู่ในเว็บแล้วครับ โหมดนี้ไม่ใช้ OpenAI API ไม่เสียเครดิต และไม่เรียก API เสียเงิน ถามได้เรื่องตรวจเว็บ วิเคราะห์ลิสต์ Data Doctor หรือแผนพัฒนา</div>`;
    return;
  }
  box.innerHTML = brotherAIHistory.map(m => `<div class="brother-ai-msg ${m.role}">${escapeText(m.content)}</div>`).join("");
  box.scrollTop = box.scrollHeight;
};

window.openBrotherAI = function(){
  const modal = $("brotherAIModal");
  if(modal) modal.style.display = "flex";
  window.renderBrotherAIChat();
};

window.closeBrotherAI = function(){
  const modal = $("brotherAIModal");
  if(modal) modal.style.display = "none";
};

window.clearBrotherAIChat = function(){
  brotherAIHistory = [];
  window.renderBrotherAIChat();
};

window.askBrotherQuick = async function(text){
  const input = $("brotherAIInput");
  if(input) input.value = text;
  await window.sendBrotherAIMessage();
};

window.sendBrotherAIMessage = async function(){
  const input = $("brotherAIInput");
  const message = String(input?.value || "").trim();
  if(!message) return;
  if(input) input.value = "";

  brotherAIHistory.push({ role:"user", content: message });
  window.renderBrotherAIChat();

  try{
    if(isAdmin && typeof loadAdminData === "function" && (!adminUsers.length || !adminItems.length || !adminLogs.length)){
      try{ await loadAdminData(); }catch(_e){}
    }
    const reply = wjbLocalBrainBuildReport(message);
    brotherAIHistory.push({ role:"assistant", content: reply });
  }catch(e){
    brotherAIHistory.push({ role:"assistant", content:`WJB Brain ฟรี 100%ตรวจไม่สำเร็จครับ\nรายละเอียด: ${e.message}` });
  }
  window.renderBrotherAIChat();
};


// ===== WJB Free Only v3: Data Doctor v3 + Duplicate Finder + Smart Filter + Cost Guard =====
const WJB_FREE_V3 = "WJB Free Only v3";
const WJB_SMART_FILTER_KEY = "wjbSmartFiltersV3";

function getWJBSmartFilters(){
  return Object.assign({ hideAdded:false, onlyNoScore:false, onlyNoPoster:false }, wjbStorageGetJSON(WJB_SMART_FILTER_KEY, {}) || {});
}

function saveWJBSmartFilters(next){
  wjbStorageSetJSON(WJB_SMART_FILTER_KEY, Object.assign(getWJBSmartFilters(), next || {}));
}

window.toggleWJBSmartFilter = function(key){
  const sf = getWJBSmartFilters();
  sf[key] = !sf[key];
  saveWJBSmartFilters(sf);
  if(typeof renderTrendingExplorer === "function") renderTrendingExplorer();
  if(typeof showItems === "function" && (currentTab === "my" || !currentTab)) showItems();
  if(typeof showFilteredStatItems === "function" && window.currentStatFilter) showFilteredStatItems(window.currentStatFilter);
};

function wjbApplySmartFiltersToMyList(list){
  const sf = getWJBSmartFilters();
  let out = Array.isArray(list) ? [...list] : [];
  if(sf.onlyNoScore) out = out.filter(i => !i.score);
  if(sf.onlyNoPoster) out = out.filter(i => !i.poster);
  return out;
}

function wjbSmartFilterBarHTML(context = "my"){
  const sf = getWJBSmartFilters();
  const b = (key, label) => `<button class="gray ${sf[key] ? 'active-filter' : ''}" onclick="toggleWJBSmartFilter('${key}')">${sf[key] ? '✅' : '⬜'} ${label}</button>`;
  const trendBtn = context === "trend" ? b('hideAdded','ซ่อนเรื่องที่เพิ่มแล้ว') : "";
  return `<div class="wjb-smart-filter-bar">
    ${trendBtn}
    ${b('onlyNoScore','เฉพาะไม่มีคะแนน')}
    ${b('onlyNoPoster','เฉพาะไม่มีรูป')}
    <button class="gray" onclick="clearWJBSmartFilters()">ล้างฟิลเตอร์</button>
  </div>`;
}

window.clearWJBSmartFilters = function(){
  wjbStorageRemove(WJB_SMART_FILTER_KEY);
  if(typeof renderTrendingExplorer === "function") renderTrendingExplorer();
  if(typeof showItems === "function") showItems();
  if(typeof showFilteredStatItems === "function" && window.currentStatFilter) showFilteredStatItems(window.currentStatFilter);
};

const wjbOriginalShowItemsV3 = typeof showItems === "function" ? showItems : null;
showItems = function(){
  setBulkDeleteUI();
  const list = $("list");
  if(!list) return;
  const search = ($("search")?.value || "").toLowerCase();
  updateStats();
  const categories = ["กำลังดู", "ดูจบแล้ว", "ดองไว้", "อยากดู"];
  let fullHTML = "";

  // v15.0 fix (kept in sync with the base showItems definition above): group by
  // title first, THEN bucket each group into the category matching its current
  // season's status. Filtering by status before grouping is what caused the
  // same title to render as separate cards when its seasons had different
  // statuses.
  const searchedItems = (items || []).filter(item => String(item.title || "").toLowerCase().includes(search));
  const smartFiltered = wjbApplySmartFiltersToMyList(searchedItems);
  const allGroups = groupItemsByTitle(smartFiltered);

  categories.forEach(category => {
    let groupsInCategory = allGroups.filter(group => getSmartStatus(getCurrentSeason(group)) === category);
    groupsInCategory.sort((a, b) => Number(b.favorite) - Number(a.favorite));
    if(groupsInCategory.length === 0) return;
    let html = `<section class="category"><h2>${category}</h2>${wjbSmartFilterBarHTML('my')}<div class="grid">`;
    groupsInCategory.forEach(group => html += groupCardHTML(group, "my"));
    html += `</div></section>`;
    fullHTML += html;
  });
  // v14.9: เขียน DOM ครั้งเดียว (เดิม innerHTML += ในลูป ทำให้ parse DOM ทั้งก้อนซ้ำทุกหมวด
  // และหนักขึ้นเรื่อยๆ ตามจำนวนเรื่อง เพราะช่องค้นหาเรียกฟังก์ชันนี้ทุกตัวอักษรที่พิมพ์)
  list.innerHTML = fullHTML || `<section class="category">${wjbSmartFilterBarHTML('my')}<div class="empty">ยังไม่มีรายการในลิสต์ของคุณตามฟิลเตอร์นี้</div></section>`;
};

const wjbOriginalShowFilteredStatItemsV3 = typeof showFilteredStatItems === "function" ? showFilteredStatItems : null;
showFilteredStatItems = function(filter){
  window.currentStatFilter = filter;
  const list = $("list");
  if(!list) return;
  updateMyListCompactUI();
  const search = ($("search")?.value || "").toLowerCase();
  let filtered = (items || []).filter(item => String(item.title || "").toLowerCase().includes(search));
  if(filter !== "all"){
    if(filter === "favorite") filtered = filtered.filter(item => item.favorite);
    else filtered = filtered.filter(item => item.status === filter);
  }
  filtered = wjbApplySmartFiltersToMyList(filtered);
  const filteredBase = [...filtered];
  if((window.statTypeFilter || "all") !== "all") filtered = filtered.filter(item => item.type === window.statTypeFilter);
  filtered.sort((a, b) => (b.createdMs || 0) - (a.createdMs || 0));
  const titleEl = $("viewTitle");
  const title = titleEl ? titleEl.innerText : "รายการของฉัน";
  list.innerHTML = `<section class="category"><h2>${title}</h2>${wjbSmartFilterBarHTML('my')}${typeFilterBar(filter, filteredBase)}<div class="grid">${groupItemsByTitle(filtered).map(group => groupCardHTML(group, "my")).join("")}</div></section>`;
  if(filtered.length === 0){
    list.innerHTML = `<section class="category"><h2>${title}</h2>${wjbSmartFilterBarHTML('my')}${typeFilterBar(filter, filteredBase)}<div class="empty">ยังไม่มีรายการในหัวข้อนี้ตามฟิลเตอร์นี้</div></section>`;
  }
};

const wjbOriginalRenderTrendingExplorerV3 = typeof renderTrendingExplorer === "function" ? renderTrendingExplorer : null;
renderTrendingExplorer = function(){
  const content = $("trendingContent");
  if(!content || !wjbOriginalRenderTrendingExplorerV3) return;
  wjbOriginalRenderTrendingExplorerV3();
  if(content && !content.querySelector('.wjb-smart-filter-bar')){
    content.insertAdjacentHTML('afterbegin', wjbSmartFilterBarHTML('trend'));
  }
};

function wjbFixCandidatesV3(){
  const arr = Array.isArray(items) ? items : [];
  const out = [];
  arr.forEach(item => {
    if(!item || !item.id) return;
    const ep = Number(item.episode || 0);
    const total = Number(item.total || 0);
    const scoreNum = Number(item.score);
    if(item.score !== undefined && item.score !== "" && !Number.isNaN(scoreNum) && (scoreNum < 0 || scoreNum > 10)){
      out.push({ id:`score:${item.id}`, itemId:item.id, title:item.title || "ไม่ทราบชื่อ", issue:`คะแนนอยู่นอกช่วง (${item.score})`, patch:{ score:String(Math.max(0, Math.min(10, scoreNum))) } });
    }
    if(total > 0 && ep > total){
      out.push({ id:`episode:${item.id}`, itemId:item.id, title:item.title || "ไม่ทราบชื่อ", issue:`ตอนดูเกินจำนวนตอน (${item.episode}/${item.total})`, patch:{ episode:String(total) } });
    }
    if(item.status === "ดูจบแล้ว" && item.type !== "หนัง" && total > 0 && ep < total){
      out.push({ id:`done-episode:${item.id}`, itemId:item.id, title:item.title || "ไม่ทราบชื่อ", issue:`สถานะดูจบแล้ว แต่ตอนยังไม่เต็ม (${item.episode || 0}/${item.total})`, patch:{ episode:String(total) } });
    }
    if(item.status !== "ดูจบแล้ว" && typeof isSeasonCompleted === "function" && isSeasonCompleted(item)){
      out.push({ id:`status:${item.id}`, itemId:item.id, title:item.title || "ไม่ทราบชื่อ", issue:`progress ครบแล้ว แต่ status ยังเป็น ${item.status || "ว่าง"}`, patch:{ status:"ดูจบแล้ว" } });
    }
  });
  return out;
}

window.openDataDoctorV3 = function(){
  const content = $('guardianContent');
  const summary = $('guardianSummary');
  if(summary) summary.innerHTML = '🩺 Data Doctor v3 แบบเลือกยืนยัน';
  if(!content) return;
  const candidates = wjbFixCandidatesV3();
  const missingScore = (items || []).filter(i => !i.score).slice(0, 20);
  if(!candidates.length && !missingScore.length){
    content.innerHTML = `<div class="guardian-row ok"><div class="guardian-row-head"><b>✅ Data Doctor v3</b><span>ข้อมูลดี</span></div><p>ไม่พบ score/status/episode ที่ต้องซ่อมแบบปลอดภัย</p></div>`;
    return;
  }
  content.innerHTML = `<div class="guardian-row warn"><div class="guardian-row-head"><b>🩺 Data Doctor v3</b><span>เลือกก่อนซ่อม</span></div><p>ระบบจะแก้เฉพาะรายการที่พี่ชายติ๊กเลือก และจะถามยืนยันอีกครั้งก่อนบันทึก</p></div>
    ${candidates.length ? `<div class="wjb-doctor-list">${candidates.map(c => `<label class="wjb-doctor-item"><input type="checkbox" class="doctor-v3-check" value="${escapeText(c.id)}" checked><b>${escapeText(c.title)}</b><span>${escapeText(c.issue)}</span><small>แก้เป็น: ${escapeText(JSON.stringify(c.patch))}</small></label>`).join("")}</div><button onclick="applyDataDoctorV3Selected()">🔧 ซ่อมรายการที่เลือก</button>` : `<div class="guardian-row ok"><p>ไม่พบรายการที่ซ่อมอัตโนมัติได้อย่างปลอดภัย</p></div>`}
    ${missingScore.length ? `<div class="guardian-row warn"><div class="guardian-row-head"><b>⭐ รายการไม่มีคะแนน</b><span>${missingScore.length} ตัวอย่าง</span></div><p>${escapeText(missingScore.map(i => i.title || 'ไม่ทราบชื่อ').join(', '))}</p><div class="guardian-fix">คะแนนไม่ควรเติมอัตโนมัติแทนผู้ใช้ ให้ใช้ Smart Filter “เฉพาะไม่มีคะแนน” แล้วแก้เองทีละเรื่อง</div></div>` : ""}`;
};

window.applyDataDoctorV3Selected = async function(){
  if(!currentUser){ wjbToast('ต้องล็อกอินก่อนครับ'); return; }
  const selected = Array.from(document.querySelectorAll('.doctor-v3-check:checked')).map(x => x.value);
  if(!selected.length){ wjbToast('ยังไม่ได้เลือกรายการที่จะซ่อม'); return; }
  const map = new Map(wjbFixCandidatesV3().map(c => [c.id, c]));
  const targets = selected.map(id => map.get(id)).filter(Boolean);
  if(!targets.length){ wjbToast('ไม่พบรายการที่จะซ่อม'); return; }
  if(!(await wjbConfirm(`Data Doctor v3 จะซ่อม ${targets.length} จุดที่เลือก ต้องการดำเนินการไหม?`, {okText:"เริ่มซ่อม"}))) return;
  let fixed = 0;
  for(const c of targets){
    await setDoc(doc(db, 'watchItems', c.itemId), { ...c.patch, updatedAt: serverTimestamp() }, { merge:true });
    fixed++;
  }
  await logActivity('data_doctor_v3_fix', { count: fixed });
  await loadMyItems();
  wjbToast(`ซ่อมเสร็จ ${fixed} จุดครับ`);
  openDataDoctorV3();
};

function wjbDuplicateGroupsV3(){
  const source = (isAdmin && Array.isArray(adminItems) && adminItems.length) ? adminItems : (items || []);
  const map = new Map();
  source.forEach(i => {
    const key = `${String(i.title || '').trim().toLowerCase()}|${String(i.season || '').trim().toLowerCase()}|${String(i.type || '').trim().toLowerCase()}|${i.ownerId || ''}`;
    if(!String(i.title || '').trim()) return;
    if(!map.has(key)) map.set(key, []);
    map.get(key).push(i);
  });
  return Array.from(map.values()).filter(g => g.length > 1).map(g => g.sort((a,b)=>(a.createdMs || 0) - (b.createdMs || 0)));
}

window.openDuplicateFinder = function(){
  const content = $('guardianContent');
  const summary = $('guardianSummary');
  if(summary) summary.innerHTML = '🧩 Duplicate Finder';
  if(!content) return;
  const groups = wjbDuplicateGroupsV3();
  if(!groups.length){
    content.innerHTML = `<div class="guardian-row ok"><div class="guardian-row-head"><b>✅ Duplicate Finder</b><span>ไม่พบเรื่องซ้ำ</span></div><p>ยังไม่พบชื่อ/ซีซั่น/ประเภท/เจ้าของที่ซ้ำกัน</p></div>`;
    return;
  }
  content.innerHTML = `<div class="guardian-row warn"><div class="guardian-row-head"><b>🧩 พบเรื่องซ้ำ ${groups.length} กลุ่ม</b><span>เลือกเองก่อนลบ/รวม</span></div><p>ระบบจะไม่ลบอัตโนมัติ พี่ชายต้องเลือก checkbox แล้วกดยืนยันเอง</p></div>` +
    groups.map((g, gi) => {
      const base = g[0];
      return `<div class="guardian-row warn wjb-dup-group"><div class="guardian-row-head"><b>${escapeText(base.title || 'ไม่ทราบชื่อ')} ${escapeText(base.season || '')}</b><span>${g.length} รายการ</span></div>
      <p>รายการหลักที่จะเก็บ: ${escapeText(base.id || '')}</p>
      ${g.map((i, idx) => `<label class="wjb-doctor-item"><input type="checkbox" class="dup-v3-check" value="${escapeText(i.id)}" ${idx===0 ? 'disabled' : ''}><b>${idx===0 ? 'เก็บเป็นหลัก' : 'รวม/ลบรายการนี้'}</b><span>${escapeText(i.title || '')} · ${escapeText(i.status || '')} · ${escapeText(i.episode || '')}/${escapeText(i.total || '')} · score ${escapeText(i.score || '-')}</span><small>ID: ${escapeText(i.id || '')}</small></label>`).join('')}
      <button class="gray" onclick="mergeDuplicateGroupV3(${gi})">รวมข้อมูลเข้ารายการหลัก และลบที่เลือก</button>
      </div>`;
    }).join('');
};

window.mergeDuplicateGroupV3 = async function(groupIndex){
  const groups = wjbDuplicateGroupsV3();
  const group = groups[groupIndex];
  if(!group || group.length < 2) return;
  const selected = new Set(Array.from(document.querySelectorAll('.dup-v3-check:checked')).map(x => x.value));
  const base = group[0];
  const targets = group.slice(1).filter(i => selected.has(i.id));
  if(!targets.length){ wjbToast('ยังไม่ได้เลือกรายการซ้ำที่จะรวม/ลบ'); return; }
  if(!(await wjbConfirm(`จะรวมข้อมูลจาก ${targets.length} รายการเข้ารายการหลัก แล้วลบรายการซ้ำที่เลือก ต้องการดำเนินการไหม?`, {okText:"รวม/ลบ", danger:true}))) return;
  const patch = {};
  for(const dup of targets){
    ['poster','score','note','releaseInfo','total','episode','platform'].forEach(k => {
      if((!base[k] || base[k] === '') && dup[k]) patch[k] = dup[k];
    });
    if(dup.favorite) patch.favorite = true;
  }
  if(Object.keys(patch).length){
    await setDoc(doc(db, 'watchItems', base.id), { ...patch, updatedAt: serverTimestamp() }, { merge:true });
  }
  for(const dup of targets){
    await deleteDoc(doc(db, 'watchItems', dup.id));
  }
  await logActivity('duplicate_finder_merge_delete', { baseId: base.id, deleted: targets.map(x => x.id) });
  await loadMyItems();
  if(isAdmin && typeof loadAdminData === 'function') try{ await loadAdminData(); }catch(_e){}
  wjbToast('รวม/ลบรายการซ้ำที่เลือกเสร็จแล้วครับ');
  openDuplicateFinder();
};

// Upgrade Guardian buttons after page load
setTimeout(() => {
  const actions = document.querySelector('.guardian-actions');
  if(actions && !document.getElementById('dataDoctorV3Btn')){
    const btn = document.createElement('button');
    btn.id = 'dataDoctorV3Btn';
    btn.className = 'guardian-fix-main';
    btn.textContent = '🩺 Data Doctor v3';
    btn.onclick = () => openDataDoctorV3();
    actions.appendChild(btn);
    const dup = document.createElement('button');
    dup.id = 'duplicateFinderBtn';
    dup.className = 'gray';
    dup.textContent = '🧩 Duplicate Finder';
    dup.onclick = () => openDuplicateFinder();
    actions.appendChild(dup);
  }
}, 800);

// Offline/Local Brain richer answers
const wjbLocalBrainBuildReportV2 = typeof wjbLocalBrainBuildReport === 'function' ? wjbLocalBrainBuildReport : null;
wjbLocalBrainBuildReport = function(message = ''){
  const msg = String(message || '').toLowerCase();
  if(msg.includes('ซ้ำ') || msg.includes('duplicate')){
    const groups = wjbDuplicateGroupsV3();
    return `🧩 Duplicate Finder ตรวจแล้วครับ\n\nพบกลุ่มเรื่องซ้ำ: ${groups.length} กลุ่ม\n\nวิธีจัดการ:\n1. เปิด 🛡️ Guardian AI\n2. กด 🧩 Duplicate Finder\n3. ติ๊กเฉพาะรายการที่มั่นใจว่าเป็นตัวซ้ำ\n4. กด รวมข้อมูลเข้ารายการหลัก และลบที่เลือก\n\nระบบไม่ลบให้อัตโนมัติ เพื่อกันข้อมูลหายครับ`;
  }
  if(msg.includes('ค่าใช้จ่าย') || msg.includes('เสียเงิน') || msg.includes('openai') || msg.includes('เครดิต')){
    return `🛡️ Cost Guard เปิดอยู่ครับ\n\nสถานะ:\n- OpenAI API: ปิด\n- Netlify Function AI: ปิด\n- TMDB API Key: ปิด\n- WJB Brain: ใช้ Local Brain ฟรี\n\nคำแนะนำกันพลาด:\n1. ลบ OPENAI_API_KEY ออกจาก Netlify\n2. ใช้ไฟล์ Free Only v3 เป็นตัวหลัก\n3. อย่าเพิ่ม netlify/functions สำหรับ AI กลับเข้าไป\n4. ใช้ Free Search Hub เท่านั้น และไม่ใส่ API ที่เสียเครดิต`;
  }
  if(msg.includes('filter') || msg.includes('ฟิลเตอร์') || msg.includes('ไม่มีคะแนน') || msg.includes('ไม่มีรูป')){
    const sf = getWJBSmartFilters();
    return `🔎 Smart Filter พร้อมใช้งานแล้วครับ\n\nสถานะปัจจุบัน:\n- ซ่อนเรื่องที่เพิ่มแล้ว: ${sf.hideAdded ? 'เปิด' : 'ปิด'}\n- เฉพาะไม่มีคะแนน: ${sf.onlyNoScore ? 'เปิด' : 'ปิด'}\n- เฉพาะไม่มีรูป: ${sf.onlyNoPoster ? 'เปิด' : 'ปิด'}\n\nใช้ได้ทั้งหน้าลิสต์และหน้าเทรนด์ครับ`;
  }
  return wjbLocalBrainBuildReportV2 ? wjbLocalBrainBuildReportV2(message) : 'WJB Brain ฟรี 100% พร้อมใช้งานครับ';
};


// WJB v5.5: fallback listener สำหรับปุ่มที่บางเครื่องแตะแล้ว inline onclick ไม่ยิง
window.addEventListener('click', function(e){
  const btn = e.target.closest && e.target.closest('[data-wjb-scroll-top], .wjb-scroll-top-fix');
  if(btn){
    e.preventDefault();
    window.scrollMyListTop();
  }
}, true);


/* ===== WJB v5.9 Full UI Apply safety patch ===== */
window.WJB_VERSION = 'premium-ui-v6-0-no-launch';
window.scrollMyListTop = function(){
  try{
    const main = document.getElementById('mainApp');
    const view = document.getElementById('viewBar');
    const list = document.getElementById('list');
    const target = view || main || list || document.body;
    if(target && target.scrollIntoView){ target.scrollIntoView({behavior:'smooth', block:'start'}); }
    window.setTimeout(()=>window.scrollTo({top:0,behavior:'smooth'}),80);
  }catch(e){ window.scrollTo(0,0); }
};
document.addEventListener('click', function(e){
  const btn = e.target.closest && e.target.closest('[data-wjb-scroll-top="1"], .wjb-scroll-top-fix');
  if(btn){ e.preventDefault(); e.stopPropagation(); window.scrollMyListTop(); }
}, true);
window.useTitleAndContinue = window.useTitleAndContinue || function(){
  const title = document.getElementById('title');
  const box = document.getElementById('smartSuggestBox');
  const col = document.getElementById('smartSuggestCollapsed');
  const notice = document.getElementById('wjbTitleContinueNotice');
  if(box) box.style.display='none';
  if(col) col.style.display='grid';
  if(notice) notice.style.display='block';
  const next = document.getElementById('season') || document.getElementById('releaseInfo');
  if(next){ setTimeout(()=>{ next.scrollIntoView({behavior:'smooth', block:'center'}); try{next.focus({preventScroll:true});}catch(_e){} },80); }
  if(title && !title.value.trim()) title.focus();
};
window.searchTitleOnlineAgain = window.searchTitleOnlineAgain || function(){
  const box = document.getElementById('smartSuggestBox');
  const col = document.getElementById('smartSuggestCollapsed');
  const notice = document.getElementById('wjbTitleContinueNotice');
  if(col) col.style.display='none';
  if(notice) notice.style.display='none';
  if(box) box.style.display='block';
  const title = document.getElementById('title');
  if(title){ title.focus(); try{ if(typeof window.handleSmartSearchInput === 'function') window.handleSmartSearchInput(); }catch(_e){} }
};


// v6.4 clean menu drawer: close menu after selecting an item
document.addEventListener('DOMContentLoaded',()=>{
  const box=document.getElementById('userBox');
  if(!box) return;
  box.querySelectorAll('.premium-menu-item').forEach((btn)=>{
    btn.addEventListener('click',()=>{ setTimeout(()=> box.classList.remove('open'), 60); },{passive:true});
  });
});


// v6.5: Prevent unwanted iOS/Safari double-tap zoom while keeping normal taps working
(function(){
  let lastTouchEnd = 0;
  document.addEventListener('touchend', function(event){
    const now = Date.now();
    const target = event.target;
    const allowDefault = target && target.closest && target.closest('input, textarea, select, [contenteditable="true"]');
    if(!allowDefault && now - lastTouchEnd <= 320){
      event.preventDefault();
    }
    lastTouchEnd = now;
  }, { passive:false });

  // iOS Safari gesture zoom events
  ['gesturestart','gesturechange','gestureend'].forEach(function(type){
    document.addEventListener(type, function(event){
      event.preventDefault();
    }, { passive:false });
  });
})();


// v6.8 prevent horizontal drifting on iPhone/Safari
(function(){
  function clampHorizontalScroll(){
    // v12.5: never call window.scrollTo while the user is vertically scrolling.
    // Calling scrollTo(0, currentY) inside a scroll event caused micro-jumps on iPhone/Android.
    if(Math.abs(window.scrollX || 0) > 1){
      document.documentElement.scrollLeft = 0;
      if(document.body) document.body.scrollLeft = 0;
    }
  }
  ['load','resize','orientationchange','pageshow'].forEach((ev)=> window.addEventListener(ev, clampHorizontalScroll, {passive:true}));
  document.addEventListener('DOMContentLoaded', clampHorizontalScroll);
})();


// v6.9 modal scroll lock helpers
(function(){
  let wjbSavedScrollY = 0;
  function hasVisibleModal(){
    return Array.from(document.querySelectorAll('.settings-modal, .modal')).some((el)=> getComputedStyle(el).display !== 'none');
  }
  function lockPageForModal(){
    if(document.body.classList.contains('wjb-modal-open')) return;
    wjbSavedScrollY = window.scrollY || document.documentElement.scrollTop || 0;
    document.body.classList.add('wjb-modal-open');
    document.body.style.position = 'fixed';
    document.body.style.top = `-${wjbSavedScrollY}px`;
    document.body.style.left = '0';
    document.body.style.right = '0';
    document.body.style.width = '100%';
  }
  function unlockPageForModal(){
    if(hasVisibleModal()) return;
    const top = document.body.style.top;
    document.body.classList.remove('wjb-modal-open');
    document.body.style.position = '';
    document.body.style.top = '';
    document.body.style.left = '';
    document.body.style.right = '';
    document.body.style.width = '';
    const restoreY = top ? Math.abs(parseInt(top,10)) : wjbSavedScrollY || 0;
    window.scrollTo(0, restoreY);
  }
  function wrapModalPair(openName, closeName){
    const originalOpen = window[openName];
    const originalClose = window[closeName];
    if(typeof originalOpen === 'function'){
      window[openName] = async function(...args){
        const result = await originalOpen.apply(this,args);
        lockPageForModal();
        return result;
      };
    }
    if(typeof originalClose === 'function'){
      window[closeName] = function(...args){
        const result = originalClose.apply(this,args);
        setTimeout(unlockPageForModal, 10);
        return result;
      };
    }
  }
  document.addEventListener('DOMContentLoaded', ()=>{
    [['openTrendingExplorer','closeTrendingExplorer'],['openPersonalAI','closePersonalAI'],['openAdminPanel','closeAdminPanel'],['openHallOfFame','closeHallOfFame'],['openGuardianAI','closeGuardianAI'],['openBrotherAI','closeBrotherAI'],['openControlCenter','closeControlCenter'],['openSeasonDetail','closeSeasonDetail']].forEach(([o,c])=> wrapModalPair(o,c));
    document.querySelectorAll('.settings-modal, .modal').forEach((overlay)=>{
      overlay.addEventListener('click', (e)=>{
        if(e.target === overlay){
          overlay.style.display = 'none';
          setTimeout(unlockPageForModal, 10);
        }
      });
      overlay.addEventListener('touchmove', ()=>{}, {passive:true});
    });
  });
})();

// v7.5 auth email fallback init: hide email field in login mode
document.addEventListener("DOMContentLoaded", () => {
  try{ if(typeof window.setAuthMode === "function") window.setAuthMode(authMode || "login"); }catch(_e){}
});

// ===== WJB Bottom Nav Visibility Controller =====
// Removed duplicate v9-era controller here (dead code): it wrapped ~20
// navigation functions a 2nd/3rd time and ran its own MutationObserver,
// but window.wjbUpdateBottomNavVisibility was immediately overwritten by
// the newer controller further down this file, so all that wrapping and
// observing ran on every click for no effect. See the v11.5 controller
// below for the active implementation.

// v9.0: global watched-episode stepper. Script is type=module, so inline onclick needs window.*
window.wjbAdjustEpisode = function wjbAdjustEpisode(delta){
  const input = document.getElementById('episode');
  if(!input) return false;
  const currentRaw = String(input.value || '').trim();
  const current = currentRaw === '' ? 0 : Number(currentRaw);
  const safeCurrent = Number.isFinite(current) ? current : 0;
  let next = safeCurrent + Number(delta || 0);
  if(!Number.isFinite(next)) next = safeCurrent;
  next = Math.max(0, Math.round(next));
  input.value = String(next);
  input.dispatchEvent(new Event('input', { bubbles:true }));
  input.dispatchEvent(new Event('change', { bubbles:true }));
  try{ input.focus({ preventScroll:true }); }catch(_e){ input.focus(); }
  return false;
};



// ===== WJB Anime Airing Notify v1: แจ้งตอนใหม่วันนี้ + ดองไว้กี่ตอน (แจ้งในแอปเท่านั้น ฟรี 100% ไม่ใช้ push/บัตรเครดิต) =====
const WJB_AIRING_CACHE_KEY = "wjb_airing_cache_v1";
const WJB_AIRING_CACHE_TTL_MS = 12 * 60 * 60 * 1000; // เช็คซ้ำทุก 12 ชม.ต่อเรื่อง กันยิง API ถี่เกิน
const WJB_AIRING_CACHE_MAX_ENTRIES = 100; // กันข้อมูลบวมไม่จำกัดใน localStorage

function wjbGetAiringCache(){
  return wjbStorageGetJSON(WJB_AIRING_CACHE_KEY, {}) || {};
}
function wjbSaveAiringCache(cache){
  wjbStorageSetJSON(WJB_AIRING_CACHE_KEY, wjbCapObjectEntries(cache || {}, WJB_AIRING_CACHE_MAX_ENTRIES));
}
function wjbTodayKey(){
  return new Date().toISOString().slice(0, 10); // YYYY-MM-DD ตามเวลาเครื่องผู้ใช้
}

async function wjbFetchAnimeAiringInfo(title){
  try{
    const searchRes = await fetch(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(title)}&limit=1`, { cache:"no-store" });
    if(!searchRes.ok) return null;
    const searchData = await searchRes.json();
    const anime = searchData?.data?.[0];
    if(!anime?.mal_id) return null;

    const epRes = await fetch(`https://api.jikan.moe/v4/anime/${anime.mal_id}/episodes`, { cache:"no-store" });
    if(!epRes.ok) return { latestAired: 0, airingToday: false };

    const epData = await epRes.json();
    const episodes = Array.isArray(epData?.data) ? epData.data : [];
    const today = wjbTodayKey();
    let latestAired = 0;
    let airingToday = false;
    episodes.forEach(ep => {
      if(!ep.aired) return;
      const airedDate = String(ep.aired).slice(0, 10);
      if(airedDate <= today && ep.mal_id > latestAired) latestAired = ep.mal_id;
      if(airedDate === today) airingToday = true;
    });
    return { latestAired, airingToday };
  }catch(_e){ return null; }
}

async function wjbCheckAnimeAiringUpdates(force){
  if(!currentUser) return;
  const targets = (Array.isArray(items) ? items : []).filter(i =>
    i.type === "อนิเมะ" &&
    !isSeasonCompleted(i) &&
    (getSmartStatus(i) === "กำลังดู" || getSmartStatus(i) === "ดองไว้")
  );
  if(!targets.length){ wjbRenderAiringBanner([], false); return; }

  const cache = wjbGetAiringCache();
  const now = Date.now();
  const results = [];

  for(const item of targets){
    const key = (item.title || "").trim().toLowerCase();
    if(!key) continue;

    let info = cache[key];
    const isStale = force || !info || (now - (info.ts || 0)) > WJB_AIRING_CACHE_TTL_MS;
    if(isStale){
      const fresh = await wjbFetchAnimeAiringInfo(item.title);
      if(fresh){
        info = { ...fresh, ts: now };
        cache[key] = info;
        wjbSaveAiringCache(cache);
      }
      await new Promise(r => setTimeout(r, 400)); // กันโดน rate limit ฝั่ง Jikan (ฟรี ไม่มี API key)
    }
    if(!info) continue;

    const watched = Number(item.episode) || 0;
    const gap = Math.max(0, (info.latestAired || 0) - watched);
    if(info.airingToday || gap > 0){
      results.push({ title: item.title, airingToday: !!info.airingToday, gap });
    }
  }

  wjbRenderAiringBanner(results, true);
}

function wjbRenderAiringBanner(results, hasTargets){
  const list = $("list");
  if(!list || !list.parentNode) return;
  let banner = $("wjbAiringBanner");

  if(!hasTargets){
    if(banner) banner.remove();
    return;
  }
  if(!banner){
    banner = document.createElement("div");
    banner.id = "wjbAiringBanner";
    banner.className = "wjb-airing-banner";
    list.parentNode.insertBefore(banner, list);
  }

  const todayItems = results.filter(r => r.airingToday);
  const gapItems = results.filter(r => r.gap > 0);
  let html = `<div class="wjb-airing-row wjb-airing-controls">
    <span>🔔 แจ้งเตือนอนิเมะที่กำลังดู/ดองไว้</span>
    <button class="gray" onclick="wjbCheckAnimeAiringUpdates(true); this.innerText='กำลังเช็ค...'">🔄 เช็คตอนนี้</button>
  </div>`;
  if(todayItems.length){
    html += `<div class="wjb-airing-row wjb-airing-today"><b>🔔 มีตอนใหม่วันนี้:</b> ${todayItems.map(r => escapeText(r.title)).join(", ")}</div>`;
  }
  if(gapItems.length){
    html += `<div class="wjb-airing-row wjb-airing-gap"><b>🕒 ดองไว้:</b> ${gapItems.map(r => `${escapeText(r.title)} (ค้าง ${r.gap} ตอน)`).join(", ")}</div>`;
  }
  banner.innerHTML = html;
}

window.wjbCheckAnimeAiringUpdates = wjbCheckAnimeAiringUpdates;


// ===== WJB Airing Board v2: กระดานเตือนอนิเมะ (ตารางฉายกลาง บน Firestore) =====
// เปลี่ยนจาก "กระดานของฉัน" (เดิมเก็บ localStorage แยกเครื่อง ต่างคนต่างพิมพ์) เป็นกระดานเดียวที่ทุกคนเห็นร่วมกัน
// แก้ไข/เพิ่ม/ลบตารางได้เฉพาะแอดมิน (บังคับซ้ำอีกชั้นด้วย Firestore Rules) ส่วน "ดูแล้วกี่ตอน" ยังเป็นความคืบหน้าส่วนตัวของแต่ละคน (เก็บในเครื่อง)
const WJB_AIRING_SCHEDULE_COLLECTION = "airingSchedule";
const WJB_AIRING_PROGRESS_KEY = "wjb_airing_progress_v1"; // { [scheduleId]: { unwatchedCount, lastUpdateDate } }
const WJB_AIRING_PROGRESS_MAX_ENTRIES = 300;
const WJB_DAY_LABELS_TH = {
  monday:"จันทร์", tuesday:"อังคาร", wednesday:"พุธ", thursday:"พฤหัสบดี",
  friday:"ศุกร์", saturday:"เสาร์", sunday:"อาทิตย์", everyday:"ทุกวัน"
};
const WJB_DAY_ORDER = ["monday","tuesday","wednesday","thursday","friday","saturday","sunday"];
let wjbAiringBoardTab = "online";
let wjbAiringBoardLastDay = "";
let wjbAiringMinePosterData = "";
let wjbAiringMineDayFilter = "";
let wjbAiringScheduleCache = [];
let wjbAiringScheduleLoaded = false;
let wjbAiringOnlineResults = []; // เก็บรายการล่าสุดที่โหลดจาก Jikan (สำหรับเปิดแผ่นรายละเอียดตอนกดการ์ด)

function wjbGetAiringProgress(){
  return wjbStorageGetJSON(WJB_AIRING_PROGRESS_KEY, {}) || {};
}
function wjbSaveAiringProgress(map){
  wjbStorageSetJSON(WJB_AIRING_PROGRESS_KEY, wjbCapObjectEntries(map || {}, WJB_AIRING_PROGRESS_MAX_ENTRIES));
}
function wjbNormalizeDay(dayName){
  const raw = String(dayName || "").toLowerCase().replace(/s$/, ""); // "Mondays" -> "monday"
  return WJB_DAY_ORDER.includes(raw) ? raw : "";
}
function wjbJstTimeToThai(timeStr){
  // แปลงเวลาออกอากาศจากญี่ปุ่น (JST, UTC+9) เป็นเวลาไทย (UTC+7) ต่างกัน 2 ชม.
  const m = String(timeStr || "").match(/^(\d{1,2}):(\d{2})/);
  if(!m) return "";
  let h = (parseInt(m[1], 10) - 2 + 24) % 24;
  return `${String(h).padStart(2, "0")}:${m[2]}`;
}
function wjbTodayDayKey(){
  const days = ["sunday","monday","tuesday","wednesday","thursday","friday","saturday"];
  return days[new Date().getDay()];
}
const WJB_TH_MONTHS = ["มกราคม","กุมภาพันธ์","มีนาคม","เมษายน","พฤษภาคม","มิถุนายน","กรกฎาคม","สิงหาคม","กันยายน","ตุลาคม","พฤศจิกายน","ธันวาคม"];
function wjbFormatThaiDate(isoDateStr){
  if(!isoDateStr) return "";
  const d = new Date(isoDateStr + "T00:00:00");
  if(isNaN(d.getTime())) return "";
  return `${d.getDate()} ${WJB_TH_MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

// โหลดตารางฉายกลางจาก Firestore (ทุกคนอ่านได้ ไม่ต้องล็อกอิน) — cache ไว้ในหน่วยความจำระหว่างเปิดโมดัล
async function wjbFetchAiringSchedule(force){
  if(wjbAiringScheduleLoaded && !force) return wjbAiringScheduleCache;
  try{
    const snap = await getDocs(query(collection(db, WJB_AIRING_SCHEDULE_COLLECTION), orderBy("createdMs", "desc"), limit(300)));
    wjbAiringScheduleCache = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    wjbAiringScheduleLoaded = true;
  }catch(e){
    wjbAiringScheduleCache = [];
    if(typeof window.wjbToast === "function") window.wjbToast("โหลดกระดานเตือนไม่สำเร็จ: " + (e.message || e));
  }
  return wjbAiringScheduleCache;
}

// ตรวจว่าถึง "วันฉาย" ของแต่ละเรื่องในกระดานเตือนหรือยัง ถ้าถึง ให้นับตอนที่ค้างดูของฉันเพิ่มขึ้นทีละ 1 ทุกรอบฉาย
// (progress เป็นข้อมูลส่วนตัวต่อเครื่อง แยกจากตารางกลางที่แอดมินคุม)
function wjbCheckMyAiringUpdates(){
  const schedule = wjbAiringScheduleCache;
  if(!schedule.length) return { schedule, progress: {} };
  const progress = wjbGetAiringProgress();
  const today = wjbTodayKey();
  const todayDay = wjbTodayDayKey();
  let changed = false;
  schedule.forEach(entry => {
    const p = progress[entry.id] || { unwatchedCount: 0, lastUpdateDate: "" };
    const airsToday = entry.day === "everyday" || entry.day === todayDay;
    if(airsToday && p.lastUpdateDate !== today){
      p.unwatchedCount = Number(p.unwatchedCount || 0) + 1;
      p.lastUpdateDate = today;
      changed = true;
    }
    progress[entry.id] = p;
  });
  if(changed) wjbSaveAiringProgress(progress);
  return { schedule, progress };
}

// กดดูแล้ว 1 ตอน: ลดจำนวนตอนที่ค้างของฉันลงทีละ 1 (ความคืบหน้าส่วนตัว ไม่กระทบตารางกลาง ใครกดก็ได้)
window.markAiringEpisodeWatched = function(id){
  const progress = wjbGetAiringProgress();
  const p = progress[id] || { unwatchedCount: 0, lastUpdateDate: "" };
  p.unwatchedCount = Math.max(0, Number(p.unwatchedCount || 0) - 1);
  progress[id] = p;
  wjbSaveAiringProgress(progress);
  renderMyAiringBoard();
};
// กดดูทันแล้วทั้งหมด: เคลียร์ตอนที่ค้างของฉันทั้งหมดในครั้งเดียว
window.markAiringAllWatched = function(id){
  const progress = wjbGetAiringProgress();
  const p = progress[id] || { unwatchedCount: 0, lastUpdateDate: "" };
  p.unwatchedCount = 0;
  progress[id] = p;
  wjbSaveAiringProgress(progress);
  renderMyAiringBoard();
};

window.wjbPreviewAiringPoster = function(input){
  const file = input?.files?.[0];
  if(!file) return;
  resizeImage(file, (resizedImage) => {
    wjbAiringMinePosterData = resizedImage;
    const preview = $("airingMinePosterPreview");
    const hint = $("airingMinePosterHint");
    if(preview){ preview.src = resizedImage; preview.style.display = "block"; }
    if(hint) hint.style.display = "none";
  });
};

window.openAiringBoard = function(){
  const modal = $("airingBoardModal");
  if(modal) modal.style.display = "flex";
  const timeInput = $("airingMineTime");
  if(timeInput && !timeInput.value) timeInput.value = "20:00";
  wjbUpdateAiringAdminUI();
  setAiringBoardTab("online");
};
window.closeAiringBoard = function(){
  const modal = $("airingBoardModal");
  if(modal) modal.style.display = "none";
};

// ซ่อน/แสดงฟอร์มเพิ่มรายการด้วยมือ — เฉพาะแอดมินเท่านั้นที่แก้ไขกระดานเตือนได้ คนอื่นเห็นข้อความอธิบายแทน
function wjbUpdateAiringAdminUI(){
  const form = $("airingMineAdminForm");
  const hint = $("airingMineReadonlyHint");
  if(form) form.style.display = isAdmin ? "flex" : "none";
  if(hint) hint.style.display = isAdmin ? "none" : "block";
}

window.setAiringBoardTab = function(tab){
  wjbAiringBoardTab = tab;
  const onlineTab = $("airingOnlineTab"), mineTab = $("airingMineTab");
  const onlineBtn = $("airingTabOnlineBtn"), mineBtn = $("airingTabMineBtn");
  if(onlineTab) onlineTab.style.display = tab === "online" ? "block" : "none";
  if(mineTab) mineTab.style.display = tab === "mine" ? "block" : "none";
  if(onlineBtn) onlineBtn.className = tab === "online" ? "" : "gray";
  if(mineBtn) mineBtn.className = tab === "mine" ? "" : "gray";
  if(tab === "online" && !wjbAiringBoardLastDay){
    refreshAiringOnlineBoard(wjbTodayDayKey());
  } else if(tab === "mine"){
    renderMyAiringBoard();
    wjbFetchAiringSchedule().then(() => renderMyAiringBoard());
  }
};

window.refreshAiringOnlineBoard = async function(day){
  wjbAiringBoardLastDay = day;
  document.querySelectorAll("#airingDayControls button").forEach(btn => {
    btn.className = btn.dataset.day === day ? "" : "gray";
  });
  const box = $("airingOnlineContent");
  if(!box) return;
  box.innerHTML = `<div class="wjb-v12-loading">กำลังโหลดตารางออกอากาศวัน${escapeText(WJB_DAY_LABELS_TH[day] || day)}...</div>`;
  try{
    const res = await fetch(`https://api.jikan.moe/v4/schedules?filter=${encodeURIComponent(day)}&sfw=true`, { cache:"no-store" });
    if(!res.ok) throw new Error("โหลดไม่สำเร็จ");
    const data = await res.json();
    const list = (Array.isArray(data?.data) ? data.data : []).slice(0, 20);
    if(!list.length){ box.innerHTML = `<div class="muted">ไม่พบเรื่องที่ออกอากาศวันนี้จากฐานข้อมูลฟรี</div>`; return; }

    box.innerHTML = list.map((anime, index) => {
      const title = anime.title || "ไม่ทราบชื่อ";
      const poster = anime.images?.webp?.image_url || anime.images?.jpg?.image_url || "";
      const normDay = wjbNormalizeDay(anime.broadcast?.day) || day;
      const dayLabel = WJB_DAY_LABELS_TH[normDay] || normDay;
      const jstTime = anime.broadcast?.time || "";
      const thaiTime = wjbJstTimeToThai(jstTime);
      const timeDetail = jstTime
        ? `ทุกวัน${dayLabel} เวลา ${thaiTime || "?"} น. (เวลาไทย) — ${jstTime} น. เวลาญี่ปุ่น`
        : `ทุกวัน${dayLabel} (ยังไม่ทราบเวลาออกอากาศแน่ชัด)`;
      const score = anime.score ? `⭐ ${anime.score}` : "";
      const addBtn = isAdmin
        ? `<button class="gray" onclick="event.stopPropagation(); addToAiringSchedule('${encodeURIComponent(title)}','${escAttrJs(poster)}','${normDay}','${thaiTime}')">➕ เพิ่มเข้ากระดานเตือน</button>`
        : "";
      return `<div class="smart-result airing-online-card" role="button" tabindex="0" onclick="openAiringOnlineDetail(${index})" onkeydown="if(event.key==='Enter'){openAiringOnlineDetail(${index})}">
        ${poster ? `<img class="airing-card-poster" src="${escapeText(poster)}" alt="">` : ""}
        <div class="airing-card-info">
          <b>${escapeText(title)}</b>
          <div class="muted">📅 ${escapeText(timeDetail)} ${score}</div>
          ${addBtn}
        </div>
      </div>`;
    }).join("");

    // เก็บข้อมูลที่ normalize แล้วไว้ใช้เปิดแผ่นรายละเอียดตอนกดการ์ด (แยกจาก smartResults ของช่องค้นหา กันชนกัน)
    wjbAiringOnlineResults = list.map(anime => {
      const normDay = wjbNormalizeDay(anime.broadcast?.day) || day;
      const jstTime = anime.broadcast?.time || "";
      const thaiTime = wjbJstTimeToThai(jstTime);
      const dayLabel = WJB_DAY_LABELS_TH[normDay] || normDay;
      return {
        title: anime.title || "ไม่ทราบชื่อ",
        poster: anime.images?.webp?.image_url || anime.images?.jpg?.image_url || "",
        type: "อนิเมะ",
        format: anime.type || "",
        releaseInfo: anime.year || anime.aired?.prop?.from?.year || "",
        total: anime.episodes || "",
        score: anime.score || "",
        popularity: anime.members || anime.favorites || 0,
        rank: anime.rank || "",
        note: (anime.synopsis || `ออกอากาศทุกวัน${dayLabel}${thaiTime ? ` เวลา ${thaiTime} น. (เวลาไทย)` : ""}`),
        altTitle: anime.title_english && anime.title_english !== anime.title ? anime.title_english : "",
        source: "Jikan"
      };
    });
  }catch(_e){
    box.innerHTML = `<div class="muted">โหลดตารางออกอากาศไม่สำเร็จ ลองใหม่อีกครั้งครับ</div>`;
  }
};

// กดการ์ดในกระดานออนไลน์ -> เปิดแผ่นรายละเอียดแบบเดียวกับผลค้นหา Smart Search
window.openAiringOnlineDetail = function(index){
  const item = (wjbAiringOnlineResults || [])[index];
  if(!item) return;
  wjbBuildDetailSheet(
    item,
    `applyAiringItemToForm(${index}); closeSmartDetail();`,
    `addAiringItemToList(${index}); closeSmartDetail();`
  );
};
// onclick แบบ inline ทำงานใน global scope เท่านั้น จึงต้องห่อฟังก์ชัน module-scope (applySmartItemToForm/addSmartItemToList) ด้วย window.* แบบ index-based เหมือนที่ smartResults ใช้
window.applyAiringItemToForm = function(index){
  const item = (wjbAiringOnlineResults || [])[index];
  if(!item) return;
  closeAiringBoard();
  applySmartItemToForm(item);
};
window.addAiringItemToList = async function(index){
  const item = (wjbAiringOnlineResults || [])[index];
  if(!item) return;
  await addSmartItemToList(item);
  closeAiringBoard();
};

// แอดมินเพิ่มรายการจากกระดานออนไลน์ (Jikan) เข้ากระดานเตือนกลางบน Firestore
window.addToAiringSchedule = async function(encodedTitle, poster, day, time){
  if(!isAdmin) return wjbToast("เฉพาะแอดมินเท่านั้นที่แก้ไขกระดานเตือนได้");
  const title = decodeURIComponent(encodedTitle);
  try{
    await addDoc(collection(db, WJB_AIRING_SCHEDULE_COLLECTION), {
      title,
      poster: poster || "",
      day: wjbNormalizeDay(day) || "everyday",
      time: time || "",
      createdMs: Date.now(),
      createdBy: currentUser?.uid || ""
    });
    await wjbFetchAiringSchedule(true);
    wjbToast(`เพิ่ม "${title}" เข้ากระดานเตือนแล้ว`);
    setAiringBoardTab("mine");
  }catch(e){
    wjbToast("เพิ่มไม่สำเร็จ: " + (e.message || e));
  }
};

// แอดมินเพิ่มรายการเองด้วยฟอร์ม (ผู้ใช้ทั่วไปจะไม่เห็นฟอร์มนี้ — ซ่อนด้วย wjbUpdateAiringAdminUI)
window.submitMyAiringBoardForm = async function(){
  if(!isAdmin) return wjbToast("เฉพาะแอดมินเท่านั้นที่แก้ไขกระดานเตือนได้");
  const titleInput = $("airingMineTitle");
  const daySelect = $("airingMineDay");
  const timeInput = $("airingMineTime");
  const title = String(titleInput?.value || "").trim();
  if(!title) return wjbToast("กรอกชื่อเรื่องก่อนครับ");

  try{
    await addDoc(collection(db, WJB_AIRING_SCHEDULE_COLLECTION), {
      title,
      poster: wjbAiringMinePosterData || "",
      day: daySelect?.value || "everyday",
      time: String(timeInput?.value || "").trim(),
      createdMs: Date.now(),
      createdBy: currentUser?.uid || ""
    });

    if(titleInput) titleInput.value = "";
    wjbAiringMinePosterData = "";
    const preview = $("airingMinePosterPreview"), hint = $("airingMinePosterHint"), fileInput = $("airingMinePoster");
    if(preview){ preview.src = ""; preview.style.display = "none"; }
    if(hint) hint.style.display = "block";
    if(fileInput) fileInput.value = "";

    await wjbFetchAiringSchedule(true);
    renderMyAiringBoard();
    wjbToast(`เพิ่ม "${title}" เข้ากระดานเตือนแล้ว`);
  }catch(e){
    wjbToast("เพิ่มไม่สำเร็จ: " + (e.message || e));
  }
};

// แอดมินลบรายการออกจากกระดานเตือนกลาง (มีผลกับทุกคน จึงขอ confirm ก่อน)
window.deleteMyAiringBoardEntry = async function(id){
  if(!isAdmin) return wjbToast("เฉพาะแอดมินเท่านั้นที่แก้ไขกระดานเตือนได้");
  if(!(await wjbConfirm("ลบรายการนี้ออกจากกระดานเตือนใช่ไหม? ทุกคนจะไม่เห็นรายการนี้อีก", {okText:"ลบ", danger:true}))) return;
  try{
    await deleteDoc(doc(db, WJB_AIRING_SCHEDULE_COLLECTION, id));
    await wjbFetchAiringSchedule(true);
    renderMyAiringBoard();
    wjbToast("ลบเรียบร้อย");
  }catch(e){
    wjbToast("ลบไม่สำเร็จ: " + (e.message || e));
  }
};

window.setAiringMineDayFilter = function(day){
  wjbAiringMineDayFilter = day || "";
  document.querySelectorAll("#airingMineDayControls button").forEach(btn => {
    btn.className = btn.dataset.day === wjbAiringMineDayFilter ? "" : "gray";
  });
  renderMyAiringBoard();
};

function renderMyAiringBoard(){
  const box = $("airingMineContent");
  if(!box) return;
  wjbUpdateAiringAdminUI();
  const { schedule, progress } = wjbCheckMyAiringUpdates();
  if(!schedule.length){
    box.innerHTML = `<div class="muted">ยังไม่มีรายการในกระดานเตือน${isAdmin ? " ลองเพิ่มเองด้านบน หรือดึงจากกระดานออนไลน์ก็ได้" : " รอแอดมินเพิ่มตารางฉายนะครับ"}</div>`;
    return;
  }

  const filterDay = wjbAiringMineDayFilter;
  const filtered = filterDay
    ? schedule.filter(entry => entry.day === filterDay || entry.day === "everyday")
    : schedule;

  if(!filtered.length){
    box.innerHTML = `<div class="muted">ยังไม่มีเรื่องที่ฉายวัน${escapeText(WJB_DAY_LABELS_TH[filterDay] || filterDay)}</div>`;
    return;
  }

  const todayKey = wjbTodayDayKey();
  const sorted = [...filtered].sort((a, b) => {
    const ra = a.day === "everyday" ? -1 : WJB_DAY_ORDER.indexOf(a.day);
    const rb = b.day === "everyday" ? -1 : WJB_DAY_ORDER.indexOf(b.day);
    if(ra !== rb) return ra - rb;
    return String(a.time || "").localeCompare(String(b.time || ""));
  });

  box.innerHTML = sorted.map(entry => {
    const isToday = entry.day === "everyday" || entry.day === todayKey;
    const dayLabel = WJB_DAY_LABELS_TH[entry.day] || entry.day || "ไม่ระบุวัน";
    const timeLabel = entry.time ? `${escapeText(entry.time)} น.` : "ยังไม่ระบุเวลา";
    const p = progress[entry.id] || { unwatchedCount: 0, lastUpdateDate: "" };
    const lastUpdateLabel = wjbFormatThaiDate(p.lastUpdateDate) || "ยังไม่มีข้อมูล";
    const unwatchedCount = Number(p.unwatchedCount || 0);
    const statusHtml = unwatchedCount > 0
      ? `<span class="airing-watch-status airing-watch-pending">🕒 ยังไม่ได้ดู ${unwatchedCount} ตอน</span>`
      : `<span class="airing-watch-status airing-watch-done">✅ ดูทันแล้ว</span>`;
    const watchActionsHtml = unwatchedCount > 0
      ? `<button class="gray" onclick="markAiringEpisodeWatched('${entry.id}')">✅ ดูแล้ว 1 ตอน</button>
         ${unwatchedCount > 1 ? `<button class="gray" onclick="markAiringAllWatched('${entry.id}')">✅ ดูทันหมดเลย</button>` : ""}`
      : "";
    const adminActionsHtml = isAdmin
      ? `<button class="danger" onclick="deleteMyAiringBoardEntry('${entry.id}')">ลบออกจากกระดาน</button>`
      : "";
    return `<div class="smart-result airing-mine-card${isToday ? " airing-mine-today" : ""}">
      ${entry.poster ? `<img class="airing-card-poster" src="${escapeText(entry.poster)}" alt="">` : `<div class="airing-card-poster airing-card-poster-empty">🎬</div>`}
      <div class="airing-card-info">
        <b>${escapeText(entry.title)}</b>${isToday ? " <span class=\"new-item-badge\">วันนี้!</span>" : ""}
        <div class="muted">📅 ทุกวัน${escapeText(dayLabel)} · ⏰ เวลาไทย ${timeLabel}</div>
        <div class="muted">🗓️ อัพเดทล่าสุดของฉัน: ${escapeText(lastUpdateLabel)}</div>
        <div class="airing-watch-row">
          ${statusHtml}
        </div>
        <div class="airing-watch-actions">
          ${watchActionsHtml}
          ${adminActionsHtml}
        </div>
      </div>
    </div>`;
  }).join("");
}





// ===== WJB v13.4 Hall of Fame Preview Card =====
(function(){
  function safePoster(item){
    return item?.poster || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="160" height="160"><defs><linearGradient id="g" x1="0" x2="1"><stop stop-color="%230ea5e9"/><stop offset="1" stop-color="%237c3aed"/></linearGradient></defs><rect width="100%" height="100%" rx="24" fill="%23071426"/><circle cx="80" cy="70" r="42" fill="url(%23g)" opacity=".55"/><text x="50%" y="56%" dominant-baseline="middle" text-anchor="middle" fill="%23ffffff" font-size="30" font-family="Arial">WJB</text></svg>';
  }
  function buildPreviewHTML(){
    const arr = Array.isArray(window.items) ? window.items : (typeof items !== 'undefined' && Array.isArray(items) ? items : []);
    if(!arr.length){
      return `<section class="hall-preview-card hall-preview-card-empty">
        <div class="hall-preview-head"><div><h3>🏆 Hall of Fame</h3><p>สถิติการรับชมและความสำเร็จของคุณ</p></div><span>เปิดดู ›</span></div>
        <div class="hall-preview-empty-state">ยังไม่มีข้อมูลสะสม เพิ่มรายการแรกเพื่อเริ่มสร้าง Hall of Fame</div>
      </section>`;
    }
    const scored = arr.filter(i=>Number(i.score)>0).sort((a,b)=>Number(b.score||0)-Number(a.score||0));
    const totalEp = arr.reduce((s,i)=>s+(Number(i.episode)||0),0);
    const avg = scored.length ? (scored.reduce((s,i)=>s+Number(i.score||0),0)/scored.length).toFixed(1) : '0.0';
    const completed = arr.filter(i=>(i.status||'')==='ดูจบแล้ว').length;
    const favoriteCount = arr.filter(i=>!!i.favorite).length;
    const achievementCount = arr.length + completed + favoriteCount + scored.filter(i=>Number(i.score)>=9).length;
    const watchedTop = arr.filter(i=>Number(i.episode)>0).sort((a,b)=>Number(b.episode||0)-Number(a.episode||0));
    const topItem = watchedTop[0] || scored[0] || arr[0];
    const topName = typeof getHallDisplayName === 'function' ? getHallDisplayName(topItem) : escapeText(topItem?.title || 'ไม่ระบุชื่อ');
    const topScore = topItem && Number(topItem.score)>0 ? Number(topItem.score).toFixed(1) : avg;
    const ep = Number(topItem?.episode || 0);
    const pct = topItem && Number(topItem.totalEpisodes)>0 ? Math.min(100, Math.round((Number(topItem.episode||0)/Number(topItem.totalEpisodes||1))*100)) : (ep>0 ? 100 : 0);
    return `<section class="hall-preview-card">
      <div class="hall-preview-head">
        <div><h3>🏆 Hall of Fame</h3><p>สถิติการรับชมและความสำเร็จของคุณ</p></div>
        <span>ดูทั้งหมด ›</span>
      </div>
      <div class="hall-preview-feature">
        <div class="hall-preview-poster-wrap"><img src="${escapeText(safePoster(topItem))}" alt="" loading="lazy"><em>#1</em></div>
        <div class="hall-preview-feature-info">
          <b>👑 Top Item</b>
          <strong>${topName}</strong>
          <small>ดูแล้ว ${ep} ตอน</small>
          <div class="hall-preview-score">⭐ ${topScore} / 10</div>
          <div class="hall-preview-progress"><i style="width:${pct}%"></i></div>
        </div>
      </div>
      <div class="hall-preview-stats">
        <div><span>📺</span><b>${totalEp}</b><small>ตอนทั้งหมด</small></div>
        <div><span>⭐</span><b>${avg}</b><small>คะแนนเฉลี่ย</small></div>
        <div><span>🔥</span><b>${completed}</b><small>ดูจบแล้ว</small></div>
        <div><span>🏅</span><b>${achievementCount}</b><small>Achievement</small></div>
      </div>
      <button type="button" class="hall-preview-open" onclick="event.stopPropagation(); openHallOfFame();">เปิดดู Hall of Fame ทั้งหมด ›</button>
    </section>`;
  }
  window.renderHallOfFamePreview = function(){
    const target = document.getElementById('hallPreview');
    if(!target) return;
    target.innerHTML = buildPreviewHTML();
  };
  const oldShowItems = typeof showItems === 'function' ? showItems : null;
  if(oldShowItems){
    showItems = function(){
      const result = oldShowItems.apply(this, arguments);
      try{ window.renderHallOfFamePreview(); }catch(_e){}
      return result;
    };
  }
  ['DOMContentLoaded','load','pageshow'].forEach(ev=>{
    window.addEventListener(ev, ()=>setTimeout(()=>{ try{ window.renderHallOfFamePreview(); }catch(_e){} }, 120), {passive:true});
  });
  setTimeout(()=>{ try{ window.renderHallOfFamePreview(); }catch(_e){} }, 800);
})();

// WJB v11.5 Structure Polish Clean
// Consolidated legacy bottom-nav controllers into one final lightweight controller.
// WJB v11.5 Structure Polish Clean
// Final lightweight controller: keeps bottom nav stable, provides safe scroll padding,
// and makes cancel/save/edit returns update the nav after scroll focus.
(function(){
  const VERSION = 'v11.5-structure-polish-clean';
  const NAV_SELECTOR = '.wjb-v60-bottom-nav';
  let raf = 0;
  function isShown(el){
    if(!el) return false;
    const st = getComputedStyle(el);
    return st.display !== 'none' && st.visibility !== 'hidden' && st.opacity !== '0';
  }
  function apply(){
    raf = 0;
    const body = document.body;
    const nav = document.querySelector(NAV_SELECTOR);
    const app = document.querySelector('.app');
    const main = document.getElementById('mainApp');
    if(!body || !nav) return;
    const show = isShown(main) && !body.classList.contains('wjb-auth-only') && !body.classList.contains('wjb-v131-feature-surface-open');
    body.classList.remove('wjb-hide-bottom-nav','wjb-force-hide-nav','wjb-subscreen-open','wjb-edit-mode','wjb-real-edit-mode','wjb-v85-nav-hide','wjb-v86-nav-hide','wjb-v87-nav-hide','wjb-v84-auto-nav-off','wjb-v84-real-edit-open','wjb-v84-real-modal-open','wjb-real-modal-open','wjb-v87-nav-auth-hidden');
    body.classList.toggle('wjb-v115-nav-ready', show);
    body.dataset.wjbStableVersion = VERSION;
    if(show){
      nav.style.setProperty('display','grid','important');
      nav.style.setProperty('visibility','visible','important');
      nav.style.setProperty('opacity','1','important');
      nav.style.setProperty('pointer-events','auto','important');
      nav.style.setProperty('transform','translateX(-50%) translateY(0)','important');
      nav.style.setProperty('transition','none','important');
      if(app) app.style.setProperty('padding-bottom','calc(150px + env(safe-area-inset-bottom))','important');
    }else{
      nav.style.setProperty('display','none','important');
      nav.style.setProperty('visibility','hidden','important');
      nav.style.setProperty('opacity','0','important');
      nav.style.setProperty('pointer-events','none','important');
      nav.style.setProperty('transform','translateX(-50%) translateY(130%)','important');
    }
  }
  function schedule(){ if(!raf) raf = requestAnimationFrame(apply); }
  window.wjbUpdateBottomNavVisibility = schedule;
  window.wjbForceBottomNavAlways = schedule;
  window.wjbShowBottomNavAlways = schedule;
  window.wjbV115StableRefresh = schedule;
  window.wjbV114StableRefresh = schedule; // backward-compatible alias
  ['DOMContentLoaded','load','pageshow','resize','orientationchange','visibilitychange'].forEach(ev=>{
    window.addEventListener(ev, schedule, {passive:true});
    document.addEventListener(ev, schedule, {passive:true});
  });
  document.addEventListener('click', ()=>setTimeout(schedule, 60), {passive:true});
  // v12.5: do not recalculate bottom nav on every scroll; update on navigation/open/close only.
  setTimeout(schedule, 60); setTimeout(schedule, 450); setTimeout(schedule, 1200);
})();
