/* WJB v12.1 Safe Modular Bootstrap
   This file intentionally stays tiny. The original app is preserved as
   js/legacy-app.js, while new free/cross-platform helpers live in js/v12/*.
*/
const WJB_BOOT_VERSION = 'premium-ui-v15-4-sync-dashboard';
window.WJB_BOOT_VERSION = WJB_BOOT_VERSION;

// v14.9: menu accordion is now a plain div+button (no native <details>/<summary>)
// to test/rule out a WebKit-specific perf issue with <details> toggling inside
// this fixed/scrollable drawer. Toggling only flips one class, no re-render.
window.wjbToggleMenuGroup = function(btn){
  const group = btn.closest('.wjb-menu-group');
  if(!group) return;
  const isOpen = group.classList.toggle('open');
  btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
};

// v14.10: user-facing offline/online notice. Previously connection status was
// only visible in the hidden dev panel — normal users had no idea a save
// silently failed because the connection dropped.
window.addEventListener('offline', () => {
  if(typeof window.wjbToast === 'function'){
    window.wjbToast('การเชื่อมต่ออินเทอร์เน็ตหลุด ข้อมูลที่แก้ไขอาจไม่ถูกบันทึกจนกว่าจะเชื่อมต่อใหม่', 'error');
  }
});
window.addEventListener('online', () => {
  if(typeof window.wjbToast === 'function'){
    window.wjbToast('เชื่อมต่ออินเทอร์เน็ตกลับมาแล้ว', 'success');
  }
});

async function bootWJB(){
  try{
    await import(`./js/v14/pro-ui.js?v=${WJB_BOOT_VERSION}`);
  }catch(error){
    console.error('[WJB] v14 pro-ui boot failed', error);
  }

  try{
    await import(`./js/legacy-app.js?v=${WJB_BOOT_VERSION}`);
  }catch(error){
    console.error('[WJB] Legacy app boot failed', error);
    try{
      const log = JSON.parse(localStorage.getItem('wjb_v12_error_log') || '[]');
      log.push({type:'boot', message:String(error && (error.message || error)), at:new Date().toISOString(), url:location.pathname});
      localStorage.setItem('wjb_v12_error_log', JSON.stringify(log.slice(-40)));
    }catch(_e){}
  }

  try{
    await import(`./js/v12/index.js?v=${WJB_BOOT_VERSION}`);
  }catch(error){
    console.error('[WJB] v12 helper boot failed', error);
  }

  try{
    await import(`./js/v13/favorites.js?v=${WJB_BOOT_VERSION}`);
  }catch(error){
    console.error('[WJB] v13 favorites helper boot failed', error);
  }


  try{
    await import(`./js/v13/menu-drawer-stability.js?v=${WJB_BOOT_VERSION}`);
  }catch(error){
    console.error('[WJB] v13 menu drawer stability helper boot failed', error);
  }

  try{
    await import(`./js/v13/smart-target-scroll.js?v=${WJB_BOOT_VERSION}`);
  }catch(error){
    console.error('[WJB] v13 smart target scroll helper boot failed', error);
  }

  try{
    await import(`./js/v13/long-press-bulk-select.js?v=${WJB_BOOT_VERSION}`);
  }catch(error){
    console.error('[WJB] v13 long-press bulk select helper boot failed', error);
  }
}

bootWJB();
